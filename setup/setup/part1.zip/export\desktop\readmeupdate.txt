TILBUCI DESKTOP APP

This is the update package for your desktop app created in TilBuci. You just need to overwrite the files of your current app with these. Note that the package.json file is not in this package: any necessary updates to it must be made directly.