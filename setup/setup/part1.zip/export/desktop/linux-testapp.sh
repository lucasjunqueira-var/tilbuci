echo "Testing desktop app..."
npm run start