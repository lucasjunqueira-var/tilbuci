This is the update file for your Android/iOS app that you previously generated as an Apache Cordova project. If you haven't created this project yet, go back to the TilBuci interface and create a complete project.

To update its contents, simply copy the "www" folder to your Apache Cordova project and generate your new apps - remember to update the version data.