<?php
/*
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * TilBuci PDF importer - stage 1: initial PDF analysis.
 *
 * Requirements: PHP 8.0+ (zlib is strongly recommended for compressed PDFs).
 */

if (!defined('TBPDF_VERSION')) {
    define('TBPDF_VERSION', '26.0.0');
}
if (!defined('TBPDF_SCHEMA')) {
    define('TBPDF_SCHEMA', 'tbpdf.analysis');
}
if (!defined('TBPDF_SCHEMA_VERSION')) {
    define('TBPDF_SCHEMA_VERSION', 1);
}

/**
 * Analyzes a PDF file and returns the stage 1 report.
 *
 * Options (all optional):
 * - dpi: pixel density used for the point-to-pixel conversion (default 96).
 * - max_bytes: maximum accepted file size in bytes (default 256 MB).
 * - max_stream_bytes: maximum decoded stream size in bytes (default 64 MB).
 * - include_xmp: whether to include raw XMP metadata (default true).
 * - include_content: whether to analyze page content streams (default true).
 * - page_limit: analyze at most this many pages, 0 means all (default 0).
 * - hash: whether to compute the SHA-256 of the file (default true).
 */
function tbpdf_analyze(string $path, array $options = []): array
{
    $started = microtime(true);
    $opts = tbpdf_options($options);
    $report = tbpdf_report_skeleton($path, $opts);
    $doc = null;

    try {
        if ($path === '') {
            return tbpdf_fail_report($report, 'missing_path', 'No PDF path was provided.');
        }
        if (!is_file($path)) {
            return tbpdf_fail_report($report, 'file_not_found', 'The provided path is not a file: ' . $path);
        }
        if (!is_readable($path)) {
            return tbpdf_fail_report($report, 'file_not_readable', 'The PDF file cannot be read: ' . $path);
        }

        $size = @filesize($path);
        if ($size === false) {
            return tbpdf_fail_report($report, 'file_size_failed', 'The PDF file size could not be determined.');
        }
        if ($size > $opts['max_bytes']) {
            return tbpdf_fail_report(
                $report,
                'file_too_large',
                'The PDF exceeds the configured size limit of ' . $opts['max_bytes'] . ' bytes.'
            );
        }

        $raw = @file_get_contents($path);
        if ($raw === false) {
            return tbpdf_fail_report($report, 'file_read_failed', 'The PDF file could not be loaded into memory.');
        }
        if ($raw === '') {
            return tbpdf_fail_report($report, 'empty_file', 'The PDF file is empty.');
        }

        $report['source']['size_bytes'] = $size;
        $report['source']['sha256'] = $opts['hash'] ? (hash_file('sha256', $path) ?: null) : null;

        $doc = tbpdf_doc($path, $raw, $opts);
        $pages = tbpdf_parse_document($doc);

        $fonts = [];
        $imageFilters = [];
        $pageReports = [];
        $analyzable = count($pages);
        if ($opts['page_limit'] > 0 && $analyzable > $opts['page_limit']) {
            $analyzable = $opts['page_limit'];
            tbpdf_diag(
                $doc,
                'info',
                'page_limit_applied',
                'Only the first ' . $analyzable . ' page(s) were analyzed. The total page count is still reported.'
            );
        }

        for ($i = 0; $i < $analyzable; $i++) {
            $pageReports[] = tbpdf_analyze_page($doc, $pages[$i], $i + 1, $fonts, $imageFilters);
        }
        $doc['image_filters'] = $imageFilters;

        $report['source']['pdf_version'] = $doc['version'];
        $report['source']['linearized'] = $doc['linearized'];
        $report['source']['document_id'] = $doc['document_id'];
        $report['security'] = tbpdf_security_report($doc, $doc['catalog']);
        $report['document'] = [
            'page_count' => count($pages),
            'pages_analyzed' => count($pageReports),
            'xref_mode' => $doc['xref_mode'],
            'xref_sections' => $doc['xref_sections'],
            'eof_markers' => substr_count($doc['raw'], '%%EOF'),
            'object_count' => count($doc['xref']) > 0 ? count($doc['xref']) : count($doc['scan']),
            'encrypted' => $doc['encrypted'],
            'analysis_limited' => $doc['analysis_limited'],
        ];
        $report['pages'] = $pageReports;
        $report['screen'] = tbpdf_screen_summary($pageReports, $opts);
        $report['fonts'] = tbpdf_sorted_fonts($fonts);
        $report['fonts_summary'] = tbpdf_fonts_summary($report['fonts']);
        $report['content'] = tbpdf_content_summary($pageReports, $doc);
        $report['metadata'] = tbpdf_extract_metadata($doc, $doc['catalog'], $opts);
        $report['diagnostics'] = $doc['diagnostics'];
        $report['stats'] = [
            'duration_ms' => 0,
            'xref_entries' => count($doc['xref']),
            'scanned_objects' => count($doc['scan']),
            'cached_objects' => count($doc['cache']),
        ];
    } catch (Throwable $e) {
        $report['error'] = [
            'code' => 'internal_error',
            'message' => $e->getMessage(),
        ];
        $report['diagnostics'][] = [
            'level' => 'error',
            'code' => 'internal_error',
            'message' => $e->getMessage(),
            'page' => null,
        ];
    }

    $report['stats']['duration_ms'] = (int) round((microtime(true) - $started) * 1000);
    return $report;
}

/**
 * Analyzes a PDF and returns the definitive stage 1 JSON contract.
 */
function tbpdf_analyze_to_json(string $path, array $options = []): string
{
    return tbpdf_json_encode(tbpdf_summarize(tbpdf_analyze($path, $options)));
}

/**
 * Reduces the detailed analysis to the definitive stage 1 JSON contract.
 *
 * The detailed report returned by tbpdf_analyze() is kept for later stages.
 * This function produces the small, stable object exposed to consumers:
 * file, title, width, height, version, pages, classification, encrypted
 * and fonts. On failure an additional "error" object is included.
 *
 * $fileOverride allows a caller (for example the browser test page) to
 * present the original upload name instead of the PHP temporary path.
 */
function tbpdf_summarize(array $analysis, ?string $fileOverride = null): array
{
    $summary = [
        'file' => $fileOverride ?? ($analysis['source']['path'] ?? null),
        'title' => tbpdf_summary_title($analysis, $fileOverride),
        'width' => tbpdf_summary_dimension($analysis, 'width'),
        'height' => tbpdf_summary_dimension($analysis, 'height'),
        'version' => isset($analysis['source']['pdf_version'])
            ? (string) $analysis['source']['pdf_version']
            : null,
        'pages' => (int) ($analysis['document']['page_count'] ?? 0),
        'classification' => (string) ($analysis['content']['classification'] ?? 'unknown'),
        'encrypted' => (bool) ($analysis['security']['encrypted'] ?? false),
        'fonts' => tbpdf_summary_fonts($analysis),
    ];

    if (isset($analysis['error'])) {
        $summary['error'] = $analysis['error'];
    }

    return $summary;
}

/**
 * Returns the PDF title, falling back to the file name without extension.
 */
function tbpdf_summary_title(array $analysis, ?string $fileOverride = null): ?string
{
    $title = $analysis['metadata']['info']['title'] ?? null;
    if (is_string($title) && trim($title) !== '') {
        return trim($title);
    }

    $source = $fileOverride
        ?? ($analysis['source']['filename'] ?? null)
        ?? ($analysis['source']['path'] ?? null);
    if (is_string($source) && $source !== '') {
        $stem = pathinfo(basename($source), PATHINFO_FILENAME);
        if ($stem !== '') {
            return $stem;
        }
    }

    return null;
}

/**
 * Returns the dominant page dimension in pixels, preserving orientation.
 */
function tbpdf_summary_dimension(array $analysis, string $axis): int
{
    $key = $axis . '_px';
    $screen = $analysis['screen'] ?? null;
    if (is_array($screen) && isset($screen['page_size_mode'][$key])) {
        return (int) round((float) $screen['page_size_mode'][$key]);
    }

    $pages = $analysis['pages'] ?? null;
    if (is_array($pages) && isset($pages[0]['size'][$key])) {
        return (int) round((float) $pages[0]['size'][$key]);
    }

    return 0;
}

/**
 * Returns the unique names of used fonts. When usage could not be determined
 * (for example, encrypted content), every declared font is reported.
 */
function tbpdf_summary_fonts(array $analysis): array
{
    $fonts = $analysis['fonts'] ?? null;
    if (!is_array($fonts)) {
        return [];
    }

    $used = [];
    $all = [];
    foreach ($fonts as $font) {
        if (!is_array($font)) {
            continue;
        }
        $name = $font['name'] ?? null;
        if (!is_string($name) || trim($name) === '') {
            continue;
        }
        $name = trim($name);
        $all[$name] = true;
        if (!empty($font['used'])) {
            $used[$name] = true;
        }
    }

    $names = count($used) > 0 ? array_keys($used) : array_keys($all);
    $names = array_values(array_unique($names));
    sort($names, SORT_NATURAL | SORT_FLAG_CASE);
    return $names;
}

/**
 * Encodes the analysis report as UTF-8 JSON.
 */
function tbpdf_json_encode(array $data): string
{
    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($data, $flags);
    if ($json === false) {
        return '{"error":{"code":"json_encode_failed","message":"' .
            addslashes((string) json_last_error_msg()) . '"}}';
    }
    return $json;
}

function tbpdf_options(array $options): array
{
    return [
        'dpi' => max(36, (int) ($options['dpi'] ?? 96)),
        'max_bytes' => max(1, (int) ($options['max_bytes'] ?? 268435456)),
        'max_stream_bytes' => max(1024, (int) ($options['max_stream_bytes'] ?? 67108864)),
        'include_xmp' => (bool) ($options['include_xmp'] ?? true),
        'include_content' => (bool) ($options['include_content'] ?? true),
        'page_limit' => max(0, (int) ($options['page_limit'] ?? 0)),
        'hash' => (bool) ($options['hash'] ?? true),
    ];
}

function tbpdf_report_skeleton(string $path, array $opts): array
{
    return [
        'schema' => TBPDF_SCHEMA,
        'schema_version' => TBPDF_SCHEMA_VERSION,
        'generator' => [
            'name' => 'TilBuci PDF importer',
            'version' => TBPDF_VERSION,
            'license' => 'MPL-2.0',
        ],
        'source' => [
            'path' => $path,
            'filename' => basename($path),
            'size_bytes' => null,
            'sha256' => null,
            'pdf_version' => null,
            'linearized' => false,
            'document_id' => null,
        ],
        'units' => [
            'pdf' => 'point',
            'point_size_inch' => 1 / 72,
            'dpi' => $opts['dpi'],
            'pixels_per_point' => $opts['dpi'] / 72,
        ],
        'security' => [
            'encrypted' => false,
            'requires_password' => null,
            'permissions' => null,
            'digitally_signed' => false,
            'content_analysis_available' => true,
            'encryption' => null,
        ],
        'document' => [
            'page_count' => 0,
            'pages_analyzed' => 0,
            'xref_mode' => null,
            'xref_sections' => 0,
            'eof_markers' => 0,
            'object_count' => 0,
            'encrypted' => false,
            'analysis_limited' => false,
        ],
        'screen' => null,
        'pages' => [],
        'fonts' => [],
        'fonts_summary' => null,
        'content' => null,
        'metadata' => ['info' => [], 'xmp' => null, 'catalog' => []],
        'diagnostics' => [],
        'stats' => ['duration_ms' => 0],
    ];
}

function tbpdf_fail_report(array $report, string $code, string $message): array
{
    $report['error'] = ['code' => $code, 'message' => $message];
    $report['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    $report['stats']['duration_ms'] = 0;
    return $report;
}

function tbpdf_doc(string $path, string $raw, array $opts): array
{
    return [
        'path' => $path,
        'raw' => $raw,
        'len' => strlen($raw),
        'opts' => $opts,
        'xref' => [],
        'cache' => [],
        'loading' => [],
        'objstm' => [],
        'scan' => [],
        'scan_done' => false,
        'trailer' => null,
        'encrypted' => false,
        'encrypt' => null,
        'catalog' => null,
        'version' => null,
        'linearized' => false,
        'document_id' => null,
        'diagnostics' => [],
        'diag_keys' => [],
        'xref_mode' => null,
        'xref_sections' => 0,
        'analysis_limited' => false,
        'image_filters' => [],
    ];
}

function tbpdf_diag(array &$doc, string $level, string $code, string $message, ?int $page = null): void
{
    $key = $level . '|' . $code . '|' . ($page === null ? '-' : $page) . '|' . $message;
    if (isset($doc['diag_keys'][$key])) {
        $doc['diag_keys'][$key]++;
        return;
    }
    if (count($doc['diagnostics']) >= 250) {
        return;
    }
    $doc['diag_keys'][$key] = 1;
    $doc['diagnostics'][] = [
        'level' => $level,
        'code' => $code,
        'message' => $message,
        'page' => $page,
    ];
}

/* -------------------------------------------------------------------------
 * Document structure
 * ---------------------------------------------------------------------- */

function tbpdf_parse_document(array &$doc): array
{
    tbpdf_detect_header($doc);

    if (!tbpdf_load_xref($doc)) {
        tbpdf_diag($doc, 'warning', 'xref_missing', 'No usable cross-reference data was found; object scanning was used.');
        tbpdf_scan_objects($doc);
    }
    if (count($doc['xref']) === 0) {
        tbpdf_scan_objects($doc);
    }

    if ($doc['trailer'] !== null) {
        $encRef = tbpdf_dict_get($doc['trailer'], 'Encrypt');
        if ($encRef !== null) {
            $doc['encrypted'] = true;
            $doc['encrypt'] = tbpdf_as_dict(tbpdf_resolve($doc, $encRef));
            $doc['analysis_limited'] = true;
            tbpdf_diag(
                $doc,
                'warning',
                'pdf_encrypted',
                'The PDF is encrypted. Structural data is reported, but content streams were not analyzed.'
            );
        }

        $id = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($doc['trailer'], 'ID')));
        if ($id !== null && isset($id[0])) {
            $firstId = tbpdf_resolve($doc, $id[0]);
            if (is_array($firstId) && ($firstId['t'] ?? '') === 'str') {
                $doc['document_id'] = strtoupper(bin2hex($firstId['v']));
            }
        }
    }

    $rootRef = $doc['trailer'] !== null ? tbpdf_dict_get($doc['trailer'], 'Root') : null;
    $catalog = tbpdf_as_dict(tbpdf_resolve($doc, $rootRef));
    if ($catalog === null) {
        $catalog = tbpdf_find_catalog($doc);
    }
    $doc['catalog'] = $catalog;

    $pages = [];
    if ($catalog === null) {
        tbpdf_diag($doc, 'error', 'catalog_missing', 'The document catalog could not be located.');
        $doc['analysis_limited'] = true;
        return $pages;
    }

    $pagesRef = tbpdf_dict_get($catalog, 'Pages');
    if ($pagesRef === null) {
        tbpdf_diag($doc, 'error', 'pages_missing', 'The catalog does not reference a page tree.');
        $doc['analysis_limited'] = true;
        return $pages;
    }

    $visited = [];
    tbpdf_collect_pages($doc, $pagesRef, [], $pages, $visited);

    if (count($pages) === 0) {
        tbpdf_diag($doc, 'error', 'page_tree_empty', 'The page tree contains no pages.');
        $doc['analysis_limited'] = true;
    }

    return $pages;
}

function tbpdf_detect_header(array &$doc): void
{
    $head = substr($doc['raw'], 0, 1024);
    if (preg_match('/%PDF-(\d+\.\d+)/', $head, $m)) {
        $doc['version'] = $m[1];
    } else {
        tbpdf_diag($doc, 'warning', 'pdf_header_missing', 'No PDF header was found in the first 1024 bytes.');
    }
    $doc['linearized'] = strpos(substr($doc['raw'], 0, 2048), '/Linearized') !== false;
}

function tbpdf_load_xref(array &$doc): bool
{
    $raw = $doc['raw'];
    $sx = strrpos($raw, 'startxref');
    if ($sx === false) {
        tbpdf_diag($doc, 'warning', 'startxref_missing', 'The startxref marker is missing.');
        return false;
    }
    if (!preg_match('/startxref\s+(\d+)/A', $raw, $m, 0, $sx)) {
        tbpdf_diag($doc, 'warning', 'startxref_invalid', 'The startxref offset could not be parsed.');
        return false;
    }

    $offset = (int) $m[1];
    $seen = [];
    $trailers = [];
    $sections = 0;
    $depth = 0;

    while ($offset >= 0 && $offset < $doc['len'] && !isset($seen[$offset]) && $depth < 128) {
        $seen[$offset] = true;
        $depth++;

        $trailer = tbpdf_parse_xref_table($doc, $offset);
        if ($trailer !== null) {
            if ($doc['xref_mode'] === null) {
                $doc['xref_mode'] = 'classic';
            }
            $sections++;
            $trailers[] = $trailer;

            $xrefStm = tbpdf_dict_get($trailer, 'XRefStm');
            if (is_int($xrefStm) || is_float($xrefStm)) {
                tbpdf_parse_xref_stream_at($doc, (int) $xrefStm);
            }

            $prev = tbpdf_dict_get($trailer, 'Prev');
            if (is_int($prev) || is_float($prev)) {
                $offset = (int) $prev;
                continue;
            }
            break;
        }

        $trailer = tbpdf_parse_xref_stream_at($doc, $offset);
        if ($trailer !== null) {
            if ($doc['xref_mode'] === null) {
                $doc['xref_mode'] = 'stream';
            }
            $sections++;
            $trailers[] = $trailer;

            $prev = tbpdf_dict_get($trailer, 'Prev');
            if (is_int($prev) || is_float($prev)) {
                $offset = (int) $prev;
                continue;
            }
            break;
        }

        break;
    }

    $doc['xref_sections'] = $sections;
    foreach ($trailers as $trailer) {
        tbpdf_merge_trailer($doc, $trailer);
    }

    return $sections > 0;
}

function tbpdf_parse_xref_table(array &$doc, int $offset): ?array
{
    $raw = $doc['raw'];
    $len = $doc['len'];
    $pos = $offset;

    tbpdf_skip_ws($raw, $pos);
    if (!tbpdf_starts($raw, $pos, 'xref')) {
        return null;
    }
    $pos += 4;

    while (true) {
        tbpdf_skip_ws($raw, $pos);
        if ($pos >= $len) {
            return null;
        }
        if (tbpdf_starts($raw, $pos, 'trailer')) {
            $pos += 7;
            $trailer = tbpdf_parse_value($raw, $pos);
            return tbpdf_as_dict($trailer);
        }
        if (!preg_match('/(\d+)\s+(\d+)/A', $raw, $m, 0, $pos)) {
            return null;
        }
        $start = (int) $m[1];
        $count = (int) $m[2];
        $pos += strlen($m[0]);

        for ($i = 0; $i < $count; $i++) {
            tbpdf_skip_ws($raw, $pos);
            if (!preg_match('/(\d+)\s+(\d+)\s+([nf])/A', $raw, $m2, 0, $pos)) {
                return null;
            }
            $pos += strlen($m2[0]);
            $num = $start + $i;
            if (!isset($doc['xref'][$num])) {
                if ($m2[3] === 'n') {
                    $doc['xref'][$num] = ['t' => 1, 'off' => (int) $m2[1], 'gen' => (int) $m2[2]];
                } else {
                    $doc['xref'][$num] = ['t' => 0];
                }
            }
            while ($pos < $len && $raw[$pos] !== "\n" && $raw[$pos] !== "\r") {
                $pos++;
            }
        }
    }
}

function tbpdf_parse_xref_stream_at(array &$doc, int $offset): ?array
{
    $parsed = tbpdf_parse_indirect_at($doc, $offset);
    if ($parsed === null) {
        return null;
    }
    $obj = $parsed['value'];
    if (!is_array($obj) || ($obj['t'] ?? '') !== 'stream') {
        return null;
    }

    $dict = ['t' => 'dict', 'v' => $obj['v']];
    if (tbpdf_name_value(tbpdf_dict_get($dict, 'Type')) !== 'XRef') {
        return null;
    }

    $data = tbpdf_decode_stream($doc, $obj);
    if ($data === null) {
        tbpdf_diag($doc, 'warning', 'xref_stream_undecodable', 'An xref stream could not be decoded.', null);
        return null;
    }

    $w = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'W')));
    if ($w === null || count($w) < 3) {
        tbpdf_diag($doc, 'warning', 'xref_w_invalid', 'An xref stream has an invalid W array.');
        return null;
    }
    $widths = [];
    foreach (array_slice($w, 0, 3) as $item) {
        $n = tbpdf_num(tbpdf_resolve($doc, $item));
        if ($n === null) {
            tbpdf_diag($doc, 'warning', 'xref_w_invalid', 'An xref stream has non-numeric W values.');
            return null;
        }
        $widths[] = (int) $n;
    }
    $rowLen = $widths[0] + $widths[1] + $widths[2];
    if ($rowLen <= 0) {
        return null;
    }

    $size = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'Size')) ?? 0;
    $index = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Index')));
    $ranges = [];
    if ($index !== null && count($index) >= 2) {
        for ($i = 0; $i + 1 < count($index); $i += 2) {
            $start = tbpdf_num(tbpdf_resolve($doc, $index[$i]));
            $count = tbpdf_num(tbpdf_resolve($doc, $index[$i + 1]));
            if ($start !== null && $count !== null) {
                $ranges[] = [(int) $start, (int) $count];
            }
        }
    }
    if (count($ranges) === 0 && $size > 0) {
        $ranges[] = [0, $size];
    }

    $pos = 0;
    $dataLen = strlen($data);
    foreach ($ranges as [$start, $count]) {
        for ($i = 0; $i < $count; $i++) {
            if ($pos + $rowLen > $dataLen) {
                break 2;
            }
            $type = $widths[0] === 0 ? 1 : tbpdf_read_uint($data, $pos, $widths[0]);
            $field2 = tbpdf_read_uint($data, $pos + $widths[0], $widths[1]);
            $field3 = tbpdf_read_uint($data, $pos + $widths[0] + $widths[1], $widths[2]);
            $pos += $rowLen;
            $num = $start + $i;
            if (isset($doc['xref'][$num])) {
                continue;
            }
            if ($type === 0) {
                $doc['xref'][$num] = ['t' => 0];
            } elseif ($type === 1) {
                $doc['xref'][$num] = ['t' => 1, 'off' => $field2, 'gen' => $field3];
            } elseif ($type === 2) {
                $doc['xref'][$num] = ['t' => 2, 'stm' => $field2, 'idx' => $field3];
            }
        }
    }

    return $dict;
}

function tbpdf_read_uint(string $data, int $pos, int $width): int
{
    $value = 0;
    for ($i = 0; $i < $width; $i++) {
        $value = ($value << 8) | ord($data[$pos + $i]);
    }
    return $value;
}

function tbpdf_scan_objects(array &$doc): void
{
    if ($doc['scan_done']) {
        return;
    }
    $doc['scan_done'] = true;
    $raw = $doc['raw'];

    if (preg_match_all('/(?<!\d)(\d+)\s+(\d+)\s+obj\b/', $raw, $matches, PREG_OFFSET_CAPTURE)) {
        foreach ($matches[0] as $i => $match) {
            $num = (int) $matches[1][$i][0];
            $offset = $match[1];
            if (!isset($doc['scan'][$num])) {
                $doc['scan'][$num] = $offset;
            }
        }
    }

    if (preg_match_all('/\btrailer\b/', $raw, $trMatches, PREG_OFFSET_CAPTURE)) {
        foreach ($trMatches[0] as $match) {
            $pos = $match[1] + 7;
            $trailer = tbpdf_as_dict(tbpdf_parse_value($raw, $pos));
            if ($trailer !== null) {
                tbpdf_merge_trailer($doc, $trailer);
            }
        }
    }

    if (count($doc['scan']) > 0) {
        tbpdf_diag($doc, 'info', 'objects_scanned', count($doc['scan']) . ' object(s) were located by scanning.');
    }
}

function tbpdf_merge_trailer(array &$doc, array $trailer): void
{
    if ($doc['trailer'] === null) {
        $doc['trailer'] = $trailer;
        return;
    }
    foreach ($trailer['v'] as $key => $value) {
        if (!array_key_exists($key, $doc['trailer']['v'])) {
            $doc['trailer']['v'][$key] = $value;
        }
    }
}

function tbpdf_find_catalog(array &$doc): ?array
{
    foreach (array_keys($doc['xref']) as $num) {
        if ($num < 1) {
            continue;
        }
        $dict = tbpdf_object_dict(tbpdf_get_object($doc, (int) $num));
        if ($dict !== null && tbpdf_name_value(tbpdf_dict_get($dict, 'Type')) === 'Catalog') {
            return $dict;
        }
    }

    if (count($doc['scan']) === 0 && !$doc['scan_done']) {
        tbpdf_scan_objects($doc);
    }
    foreach (array_keys($doc['scan']) as $num) {
        $dict = tbpdf_object_dict(tbpdf_get_object($doc, (int) $num));
        if ($dict !== null && tbpdf_name_value(tbpdf_dict_get($dict, 'Type')) === 'Catalog') {
            return $dict;
        }
    }

    return null;
}

function tbpdf_get_object(array &$doc, int $num, int $gen = 0)
{
    if (array_key_exists($num, $doc['cache'])) {
        return $doc['cache'][$num];
    }
    if (!empty($doc['loading'][$num])) {
        return null;
    }

    $doc['loading'][$num] = true;
    $result = null;

    if (isset($doc['xref'][$num])) {
        $entry = $doc['xref'][$num];
        if (($entry['t'] ?? 0) === 1) {
            $parsed = tbpdf_parse_indirect_at($doc, (int) $entry['off']);
            if ($parsed !== null) {
                if ($parsed['num'] !== $num) {
                    tbpdf_diag(
                        $doc,
                        'warning',
                        'object_number_mismatch',
                        'Object ' . $num . ' was expected at the xref offset, but object ' . $parsed['num'] . ' was found.'
                    );
                }
                $result = $parsed['value'];
            }
        } elseif (($entry['t'] ?? 0) === 2) {
            $objStm = tbpdf_load_objstm($doc, (int) $entry['stm']);
            if ($objStm !== null && isset($objStm['pairs'][$num])) {
                $pos = $objStm['first'] + $objStm['pairs'][$num];
                $result = tbpdf_parse_value($objStm['data'], $pos);
            }
        }
    }

    if ($result === null && !isset($doc['scan'][$num]) && !$doc['scan_done']) {
        tbpdf_scan_objects($doc);
    }
    if ($result === null && isset($doc['scan'][$num])) {
        $parsed = tbpdf_parse_indirect_at($doc, (int) $doc['scan'][$num]);
        if ($parsed !== null) {
            $result = $parsed['value'];
        }
    }

    $doc['loading'][$num] = false;
    $doc['cache'][$num] = $result;
    return $result;
}

function tbpdf_load_objstm(array &$doc, int $stmNum): ?array
{
    if (array_key_exists($stmNum, $doc['objstm'])) {
        return $doc['objstm'][$stmNum];
    }

    $stream = tbpdf_get_object($doc, $stmNum);
    if (!is_array($stream) || ($stream['t'] ?? '') !== 'stream') {
        $doc['objstm'][$stmNum] = null;
        return null;
    }

    $dict = ['t' => 'dict', 'v' => $stream['v']];
    $data = tbpdf_decode_stream($doc, $stream);
    if ($data === null) {
        tbpdf_diag($doc, 'warning', 'object_stream_undecodable', 'Object stream ' . $stmNum . ' could not be decoded.');
        $doc['objstm'][$stmNum] = null;
        return null;
    }

    $count = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'N')) ?? 0;
    $first = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'First')) ?? 0;

    $pairs = [];
    $header = substr($data, 0, max(0, $first));
    if (preg_match_all('/(\d+)\s+(\d+)/', $header, $matches, PREG_SET_ORDER)) {
        $i = 0;
        foreach ($matches as $match) {
            if ($count > 0 && $i >= $count) {
                break;
            }
            $pairs[(int) $match[1]] = (int) $match[2];
            $i++;
        }
    }

    $result = ['data' => $data, 'first' => $first, 'pairs' => $pairs];
    $doc['objstm'][$stmNum] = $result;
    return $result;
}

function tbpdf_parse_indirect_at(array &$doc, int $offset): ?array
{
    if ($offset < 0 || $offset >= $doc['len']) {
        return null;
    }
    $raw = $doc['raw'];
    $pos = $offset;

    tbpdf_skip_ws($raw, $pos);
    if (!preg_match('/(\d+)\s+(\d+)\s+obj\b/A', $raw, $m, 0, $pos)) {
        return null;
    }
    $num = (int) $m[1];
    $gen = (int) $m[2];
    $pos += strlen($m[0]);

    $value = tbpdf_parse_value($raw, $pos);
    if ($value === null) {
        return null;
    }

    $save = $pos;
    tbpdf_skip_ws($raw, $pos);
    if (!tbpdf_starts($raw, $pos, 'stream')) {
        $pos = $save;
        return ['num' => $num, 'gen' => $gen, 'value' => $value];
    }

    $dict = tbpdf_as_dict($value);
    if ($dict === null) {
        return ['num' => $num, 'gen' => $gen, 'value' => $value];
    }

    $pos += 6;
    if ($pos < $doc['len'] && $raw[$pos] === "\r") {
        $pos++;
        if ($pos < $doc['len'] && $raw[$pos] === "\n") {
            $pos++;
        }
    } elseif ($pos < $doc['len'] && $raw[$pos] === "\n") {
        $pos++;
    }

    $lengthVal = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Length'));
    $length = tbpdf_num($lengthVal);
    $data = null;

    if ($length !== null && $length >= 0) {
        $data = substr($raw, $pos, (int) $length);
        if (strlen($data) !== (int) $length) {
            tbpdf_diag($doc, 'warning', 'stream_length_short', 'Stream ' . $num . ' is shorter than its declared Length.');
            $data = substr($raw, $pos);
        }
        $pos += (int) $length;
    }

    if ($data === null) {
        $end = strpos($raw, 'endstream', $pos);
        if ($end === false) {
            tbpdf_diag($doc, 'warning', 'stream_end_missing', 'Stream ' . $num . ' has no endstream marker.');
            $data = substr($raw, $pos);
            $pos = $doc['len'];
        } else {
            $data = substr($raw, $pos, $end - $pos);
            $pos = $end;
        }
    }

    $search = strpos($raw, 'endstream', $pos);
    if ($search !== false && $search - $pos <= 64) {
        $pos = $search + 9;
    }

    $stream = ['t' => 'stream', 'v' => $dict['v'], 'raw' => $data, 'num' => $num, 'gen' => $gen];
    return ['num' => $num, 'gen' => $gen, 'value' => $stream];
}

/* -------------------------------------------------------------------------
 * Object lexer/parser
 * ---------------------------------------------------------------------- */

function tbpdf_parse_value(string $buf, int &$pos, int $depth = 0)
{
    if ($depth > 64) {
        return null;
    }

    tbpdf_skip_ws($buf, $pos);
    $len = strlen($buf);
    if ($pos >= $len) {
        return null;
    }

    $c = $buf[$pos];

    if ($c === "'" || $c === '"') {
        $pos++;
        return ['t' => 'kw', 'v' => $c];
    }

    if ($c === '<' && $pos + 1 < $len && $buf[$pos + 1] === '<') {
        $pos += 2;
        $out = [];
        while (true) {
            tbpdf_skip_ws($buf, $pos);
            if ($pos + 1 < $len && $buf[$pos] === '>' && $buf[$pos + 1] === '>') {
                $pos += 2;
                break;
            }
            if ($pos >= $len) {
                break;
            }
            $before = $pos;
            if ($buf[$pos] !== '/') {
                $skipped = tbpdf_parse_value($buf, $pos, $depth + 1);
                if ($skipped === null) {
                    $pos++;
                }
                continue;
            }
            $keyTok = tbpdf_parse_value($buf, $pos, $depth + 1);
            $key = is_array($keyTok) && ($keyTok['t'] ?? '') === 'name' ? $keyTok['v'] : null;
            $val = tbpdf_parse_value($buf, $pos, $depth + 1);
            if ($key !== null) {
                $out[$key] = $val;
            }
            if ($pos === $before) {
                $pos++;
            }
        }
        return ['t' => 'dict', 'v' => $out];
    }

    if ($c === '<') {
        $end = strpos($buf, '>', $pos + 1);
        if ($end === false) {
            $pos = $len;
            return ['t' => 'str', 'v' => ''];
        }
        $hex = preg_replace('/\s+/', '', substr($buf, $pos + 1, $end - $pos - 1));
        $pos = $end + 1;
        if (strlen($hex) % 2 === 1) {
            $hex .= '0';
        }
        $bin = $hex === '' ? '' : @hex2bin($hex);
        return ['t' => 'str', 'v' => $bin === false ? '' : $bin];
    }

    if ($c === '(') {
        $pos++;
        $parens = 1;
        $out = '';
        while ($pos < $len) {
            $ch = $buf[$pos];
            if ($ch === '\\') {
                $pos++;
                if ($pos >= $len) {
                    break;
                }
                $esc = $buf[$pos];
                $map = [
                    'n' => "\n",
                    'r' => "\r",
                    't' => "\t",
                    'b' => "\x08",
                    'f' => "\x0C",
                    '(' => '(',
                    ')' => ')',
                    '\\' => '\\',
                ];
                if (isset($map[$esc])) {
                    $out .= $map[$esc];
                    $pos++;
                } elseif ($esc === "\r") {
                    $pos++;
                    if ($pos < $len && $buf[$pos] === "\n") {
                        $pos++;
                    }
                } elseif ($esc === "\n") {
                    $pos++;
                } elseif ($esc >= '0' && $esc <= '7') {
                    $oct = '';
                    for ($i = 0; $i < 3 && $pos < $len && $buf[$pos] >= '0' && $buf[$pos] <= '7'; $i++) {
                        $oct .= $buf[$pos];
                        $pos++;
                    }
                    $out .= chr(octdec($oct) & 0xFF);
                } else {
                    $out .= $esc;
                    $pos++;
                }
                continue;
            }
            if ($ch === '(') {
                $parens++;
                $out .= $ch;
                $pos++;
                continue;
            }
            if ($ch === ')') {
                $parens--;
                $pos++;
                if ($parens === 0) {
                    break;
                }
                $out .= ')';
                continue;
            }
            $out .= $ch;
            $pos++;
        }
        return ['t' => 'str', 'v' => $out];
    }

    if ($c === '/') {
        $pos++;
        $start = $pos;
        while ($pos < $len && !tbpdf_is_ws($buf[$pos]) && !tbpdf_is_delim($buf[$pos])) {
            $pos++;
        }
        $name = substr($buf, $start, $pos - $start);
        if (strpos($name, '#') !== false) {
            $name = preg_replace_callback('/#([0-9A-Fa-f]{2})/', static function (array $m): string {
                return chr(hexdec($m[1]));
            }, $name);
        }
        return ['t' => 'name', 'v' => $name];
    }

    if ($c === '[') {
        $pos++;
        $arr = [];
        while (true) {
            tbpdf_skip_ws($buf, $pos);
            if ($pos >= $len) {
                break;
            }
            if ($buf[$pos] === ']') {
                $pos++;
                break;
            }
            $before = $pos;
            $value = tbpdf_parse_value($buf, $pos, $depth + 1);
            if ($value !== null) {
                $arr[] = $value;
            }
            if ($pos === $before) {
                $pos++;
            }
        }
        return ['t' => 'arr', 'v' => $arr];
    }

    if (preg_match('/[+-]?(?:\d+(?:\.\d*)?|\.\d+)/A', $buf, $m, 0, $pos)) {
        $numStr = $m[0];
        $pos += strlen($numStr);
        $isInt = strpos($numStr, '.') === false;
        $num = $isInt ? (int) $numStr : (float) $numStr;

        if ($isInt) {
            $save = $pos;
            tbpdf_skip_ws($buf, $pos);
            if (preg_match('/(\d+)/A', $buf, $m2, 0, $pos)) {
                $genStr = $m2[1];
                $endPos = $pos + strlen($genStr);
                $probe = $endPos;
                tbpdf_skip_ws($buf, $probe);
                if (
                    $probe < $len && $buf[$probe] === 'R' &&
                    ($probe + 1 >= $len || tbpdf_is_ws($buf[$probe + 1]) || tbpdf_is_delim($buf[$probe + 1]))
                ) {
                    $pos = $probe + 1;
                    return ['t' => 'ref', 'v' => [$num, (int) $genStr]];
                }
            }
            $pos = $save;
        }

        return $num;
    }

    if (preg_match('/[A-Za-z][A-Za-z0-9_*]*/A', $buf, $m, 0, $pos)) {
        $word = $m[0];
        $pos += strlen($word);
        if ($word === 'true') {
            return true;
        }
        if ($word === 'false') {
            return false;
        }
        if ($word === 'null') {
            return null;
        }
        return ['t' => 'kw', 'v' => $word];
    }

    $pos++;
    return ['t' => 'kw', 'v' => $c];
}

function tbpdf_skip_ws(string $buf, int &$pos): void
{
    $len = strlen($buf);
    while ($pos < $len) {
        $c = $buf[$pos];
        if (tbpdf_is_ws($c)) {
            $pos++;
            continue;
        }
        if ($c === '%') {
            while ($pos < $len && $buf[$pos] !== "\n" && $buf[$pos] !== "\r") {
                $pos++;
            }
            continue;
        }
        break;
    }
}

function tbpdf_is_ws(string $c): bool
{
    return $c === ' ' || $c === "\n" || $c === "\r" || $c === "\t" || $c === "\f" || $c === "\x00";
}

function tbpdf_is_delim(string $c): bool
{
    return $c !== '' && strpos('()<>[]{}/%', $c) !== false;
}

function tbpdf_starts(string $buf, int $pos, string $needle): bool
{
    if ($pos < 0 || $pos + strlen($needle) > strlen($buf)) {
        return false;
    }
    return substr_compare($buf, $needle, $pos, strlen($needle)) === 0;
}

function tbpdf_name_value($value): ?string
{
    return is_array($value) && ($value['t'] ?? '') === 'name' ? (string) $value['v'] : null;
}

function tbpdf_as_dict($value): ?array
{
    return is_array($value) && ($value['t'] ?? '') === 'dict' ? $value : null;
}

function tbpdf_array_values($value): ?array
{
    return is_array($value) && ($value['t'] ?? '') === 'arr' ? $value['v'] : null;
}

function tbpdf_dict_get($dict, string $key)
{
    if (!is_array($dict) || ($dict['t'] ?? '') !== 'dict') {
        return null;
    }
    return array_key_exists($key, $dict['v']) ? $dict['v'][$key] : null;
}

function tbpdf_resolve(array &$doc, $value, int $depth = 0)
{
    if ($depth > 32) {
        return null;
    }
    if (is_array($value) && ($value['t'] ?? '') === 'ref') {
        $ref = $value['v'];
        return tbpdf_get_object($doc, (int) $ref[0], (int) ($ref[1] ?? 0));
    }
    return $value;
}

function tbpdf_object_dict($object): ?array
{
    if (!is_array($object)) {
        return null;
    }
    if (($object['t'] ?? '') === 'dict') {
        return $object;
    }
    if (($object['t'] ?? '') === 'stream') {
        return ['t' => 'dict', 'v' => $object['v']];
    }
    return null;
}

function tbpdf_num($value)
{
    if (is_int($value) || is_float($value)) {
        return $value;
    }
    return null;
}

function tbpdf_resolve_num(array &$doc, $value)
{
    return tbpdf_num(tbpdf_resolve($doc, $value));
}

function tbpdf_resolve_int(array &$doc, $value): ?int
{
    $num = tbpdf_num(tbpdf_resolve($doc, $value));
    return $num === null ? null : (int) $num;
}

function tbpdf_resolve_name(array &$doc, $value): ?string
{
    return tbpdf_name_value(tbpdf_resolve($doc, $value));
}

/* -------------------------------------------------------------------------
 * Stream filters
 * ---------------------------------------------------------------------- */

function tbpdf_decode_stream(array &$doc, array $stream): ?string
{
    $dict = ['t' => 'dict', 'v' => $stream['v']];
    $filterValue = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Filter'));
    $parmsValue = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'DecodeParms'));

    $filters = [];
    $filterArray = tbpdf_array_values($filterValue);
    if ($filterArray !== null) {
        foreach ($filterArray as $item) {
            $filters[] = tbpdf_resolve($doc, $item);
        }
    } elseif ($filterValue !== null) {
        $filters[] = $filterValue;
    }

    $parms = [];
    $parmsArray = tbpdf_array_values($parmsValue);
    if ($parmsArray !== null) {
        foreach ($parmsArray as $item) {
            $parms[] = tbpdf_resolve($doc, $item);
        }
    } else {
        $parms[] = $parmsValue;
    }

    $data = $stream['raw'];
    foreach ($filters as $i => $filter) {
        $name = tbpdf_name_value($filter);
        if ($name === null) {
            tbpdf_diag($doc, 'warning', 'filter_name_invalid', 'A stream filter entry is not a name.');
            return null;
        }
        $data = tbpdf_apply_filter($doc, $data, $name, $parms[$i] ?? null);
        if ($data === null) {
            return null;
        }
    }

    return $data;
}

function tbpdf_apply_filter(array &$doc, string $data, string $name, $parms): ?string
{
    $max = (int) $doc['opts']['max_stream_bytes'];

    switch ($name) {
        case 'FlateDecode':
        case 'Fl':
            $out = tbpdf_flate($data);
            if ($out === null) {
                tbpdf_diag($doc, 'warning', 'flate_decode_failed', 'A FlateDecode stream could not be decompressed.');
                return null;
            }
            if (strlen($out) > $max) {
                tbpdf_diag($doc, 'warning', 'stream_too_large', 'A decoded stream exceeded the configured limit and was truncated.');
                $out = substr($out, 0, $max);
            }
            return tbpdf_apply_predictor($out, $parms);

        case 'LZWDecode':
        case 'LZW':
            $early = 1;
            $parmsDict = tbpdf_as_dict($parms);
            if ($parmsDict !== null) {
                $ec = tbpdf_num($parmsDict['v']['EarlyChange'] ?? null);
                if ($ec !== null) {
                    $early = (int) $ec;
                }
            }
            $out = tbpdf_lzw_decode($data, $early);
            if (strlen($out) > $max) {
                tbpdf_diag($doc, 'warning', 'stream_too_large', 'A decoded stream exceeded the configured limit and was truncated.');
                $out = substr($out, 0, $max);
            }
            return tbpdf_apply_predictor($out, $parms);

        case 'ASCIIHexDecode':
        case 'AHx':
            return tbpdf_asciihex_decode($data);

        case 'ASCII85Decode':
        case 'A85':
            return tbpdf_ascii85_decode($data);

        case 'RunLengthDecode':
        case 'RL':
            return tbpdf_runlength_decode($data);

        case 'Crypt':
            $parmsDict = tbpdf_as_dict($parms);
            if ($parmsDict !== null && tbpdf_name_value($parmsDict['v']['Name'] ?? null) === 'Identity') {
                return $data;
            }
            tbpdf_diag($doc, 'warning', 'crypt_filter', 'A Crypt stream filter cannot be decoded.');
            return null;

        case 'DCTDecode':
        case 'DCT':
        case 'JPXDecode':
        case 'CCITTFaxDecode':
        case 'CCF':
        case 'JBIG2Decode':
            return null;

        default:
            tbpdf_diag($doc, 'warning', 'filter_unsupported', 'Unsupported stream filter: ' . $name);
            return null;
    }
}

function tbpdf_flate(string $data): ?string
{
    if ($data === '') {
        return '';
    }
    if (!function_exists('gzuncompress')) {
        return null;
    }
    $out = @gzuncompress($data);
    if ($out === false) {
        $out = @gzinflate($data);
    }
    if ($out === false && strlen($data) > 6) {
        $out = @gzinflate(substr($data, 2, -4));
    }
    return $out === false ? null : $out;
}

function tbpdf_apply_predictor(string $data, $parms): ?string
{
    $parmsDict = tbpdf_as_dict($parms);
    if ($parmsDict === null) {
        return $data;
    }
    $pd = $parmsDict['v'];

    $predictor = tbpdf_num($pd['Predictor'] ?? null);
    if ($predictor === null || (int) $predictor < 2) {
        return $data;
    }
    $predictor = (int) $predictor;

    $colors = (int) (tbpdf_num($pd['Colors'] ?? null) ?? 1);
    $bpc = (int) (tbpdf_num($pd['BitsPerComponent'] ?? null) ?? 8);
    $columns = (int) (tbpdf_num($pd['Columns'] ?? null) ?? 1);
    if ($colors < 1) {
        $colors = 1;
    }
    if ($bpc < 1) {
        $bpc = 8;
    }
    if ($columns < 1) {
        $columns = 1;
    }

    $rowLen = (int) ceil(($columns * $colors * $bpc) / 8);
    $bpp = max(1, (int) ceil(($colors * $bpc) / 8));

    if ($predictor === 2) {
        if ($bpc !== 8) {
            return null;
        }
        $out = '';
        $offset = 0;
        $len = strlen($data);
        while ($offset < $len) {
            $row = substr($data, $offset, $rowLen);
            $offset += strlen($row);
            if ($row === '') {
                break;
            }
            $bytes = array_values(unpack('C*', $row));
            for ($i = $bpp; $i < count($bytes); $i++) {
                $bytes[$i] = ($bytes[$i] + $bytes[$i - $bpp]) & 0xFF;
            }
            $out .= pack('C*', ...$bytes);
        }
        return $out;
    }

    if ($predictor < 10) {
        return $data;
    }

    $out = '';
    $prev = str_repeat("\x00", $rowLen);
    $offset = 0;
    $len = strlen($data);

    while ($offset < $len) {
        $type = ord($data[$offset]);
        $offset++;
        $row = substr($data, $offset, $rowLen);
        $offset += strlen($row);
        if (strlen($row) < $rowLen) {
            $row = str_pad($row, $rowLen, "\x00");
        }
        $cur = '';
        for ($i = 0; $i < $rowLen; $i++) {
            $x = ord($row[$i]);
            $a = $i >= $bpp ? ord($cur[$i - $bpp]) : 0;
            $b = ord($prev[$i]);
            $c = $i >= $bpp ? ord($prev[$i - $bpp]) : 0;
            switch ($type) {
                case 1:
                    $value = $x + $a;
                    break;
                case 2:
                    $value = $x + $b;
                    break;
                case 3:
                    $value = $x + (int) floor(($a + $b) / 2);
                    break;
                case 4:
                    $p = $a + $b - $c;
                    $pa = abs($p - $a);
                    $pb = abs($p - $b);
                    $pc = abs($p - $c);
                    $value = $x + ($pa <= $pb && $pa <= $pc ? $a : ($pb <= $pc ? $b : $c));
                    break;
                default:
                    $value = $x;
            }
            $cur .= chr($value & 0xFF);
        }
        $out .= $cur;
        $prev = $cur;
    }

    return $out;
}

function tbpdf_asciihex_decode(string $data): string
{
    $end = strpos($data, '>');
    if ($end !== false) {
        $data = substr($data, 0, $end);
    }
    $hex = preg_replace('/[^0-9A-Fa-f]/', '', $data);
    if (strlen($hex) % 2 === 1) {
        $hex .= '0';
    }
    $bin = $hex === '' ? '' : @hex2bin($hex);
    return $bin === false ? '' : $bin;
}

function tbpdf_ascii85_decode(string $data): string
{
    $data = preg_replace('/\s+/', '', $data);
    if (substr($data, -2) === '~>') {
        $data = substr($data, 0, -2);
    }
    $out = '';
    $group = [];
    $len = strlen($data);
    for ($i = 0; $i < $len; $i++) {
        $ch = $data[$i];
        if ($ch === '~') {
            break;
        }
        if ($ch === 'z' && count($group) === 0) {
            $out .= "\x00\x00\x00\x00";
            continue;
        }
        $code = ord($ch) - 33;
        if ($code < 0 || $code > 84) {
            continue;
        }
        $group[] = $code;
        if (count($group) === 5) {
            $value = 0;
            foreach ($group as $g) {
                $value = $value * 85 + $g;
            }
            $out .= pack('N', $value & 0xFFFFFFFF);
            $group = [];
        }
    }
    if (count($group) > 0) {
        $n = count($group);
        while (count($group) < 5) {
            $group[] = 84;
        }
        $value = 0;
        foreach ($group as $g) {
            $value = $value * 85 + $g;
        }
        $out .= substr(pack('N', $value & 0xFFFFFFFF), 0, $n - 1);
    }
    return $out;
}

function tbpdf_runlength_decode(string $data): string
{
    $out = '';
    $i = 0;
    $len = strlen($data);
    while ($i < $len) {
        $n = ord($data[$i]);
        $i++;
        if ($n === 128) {
            break;
        }
        if ($n < 128) {
            $chunk = substr($data, $i, $n + 1);
            $i += $n + 1;
            $out .= $chunk;
        } else {
            if ($i >= $len) {
                break;
            }
            $byte = $data[$i];
            $i++;
            $out .= str_repeat($byte, 257 - $n);
        }
    }
    return $out;
}

function tbpdf_lzw_decode(string $data, int $earlyChange = 1): string
{
    $out = '';
    $dict = [];
    for ($i = 0; $i < 256; $i++) {
        $dict[$i] = chr($i);
    }
    $nextCode = 258;
    $codeLen = 9;
    $prev = null;
    $bitBuf = 0;
    $bitCount = 0;
    $pos = 0;
    $len = strlen($data);

    while (true) {
        while ($bitCount < $codeLen && $pos < $len) {
            $bitBuf = ($bitBuf << 8) | ord($data[$pos]);
            $pos++;
            $bitCount += 8;
        }
        if ($bitCount < $codeLen) {
            break;
        }
        $code = ($bitBuf >> ($bitCount - $codeLen)) & ((1 << $codeLen) - 1);
        $bitCount -= $codeLen;

        if ($code === 256) {
            $dict = [];
            for ($i = 0; $i < 256; $i++) {
                $dict[$i] = chr($i);
            }
            $nextCode = 258;
            $codeLen = 9;
            $prev = null;
            continue;
        }
        if ($code === 257) {
            break;
        }

        if ($prev === null) {
            if (!isset($dict[$code])) {
                break;
            }
            $entry = $dict[$code];
            $out .= $entry;
            $prev = $entry;
            continue;
        }

        if (isset($dict[$code])) {
            $entry = $dict[$code];
        } elseif ($code === $nextCode) {
            $entry = $prev . $prev[0];
        } else {
            break;
        }

        $out .= $entry;
        if ($nextCode < 4096) {
            $dict[$nextCode] = $prev . $entry[0];
            $nextCode++;
        }
        $prev = $entry;

        if ($nextCode + $earlyChange >= (1 << $codeLen) && $codeLen < 12) {
            $codeLen++;
        }
        if (strlen($out) > 67108864) {
            break;
        }
    }

    return $out;
}

/* -------------------------------------------------------------------------
 * Page tree and page analysis
 * ---------------------------------------------------------------------- */

function tbpdf_collect_pages(
    array &$doc,
    $nodeRef,
    array $inherited,
    array &$pages,
    array &$visited,
    int $depth = 0
): void {
    if ($depth > 64) {
        tbpdf_diag($doc, 'error', 'page_tree_depth', 'The page tree exceeds the maximum supported depth.');
        return;
    }

    $refNum = null;
    if (is_array($nodeRef) && ($nodeRef['t'] ?? '') === 'ref') {
        $refNum = (int) ($nodeRef['v'][0] ?? -1);
    }
    if ($refNum !== null) {
        if (isset($visited[$refNum])) {
            tbpdf_diag($doc, 'error', 'page_tree_cycle', 'A cycle was found in the page tree.');
            return;
        }
        $visited[$refNum] = true;
    }

    $node = tbpdf_resolve($doc, $nodeRef);
    $dict = tbpdf_as_dict($node);
    if ($dict === null) {
        tbpdf_diag($doc, 'warning', 'page_node_invalid', 'A page tree node is not a dictionary.');
        return;
    }

    foreach (['Resources', 'MediaBox', 'CropBox', 'Rotate', 'UserUnit'] as $key) {
        $value = tbpdf_dict_get($dict, $key);
        if ($value !== null) {
            $inherited[$key] = $value;
        }
    }

    $type = tbpdf_resolve_name($doc, tbpdf_dict_get($dict, 'Type'));
    $kids = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Kids')));

    if ($type === 'Pages' || ($type === null && $kids !== null)) {
        if ($kids === null) {
            tbpdf_diag($doc, 'warning', 'page_kids_invalid', 'A Pages node has no valid Kids array.');
            return;
        }
        foreach ($kids as $kid) {
            tbpdf_collect_pages($doc, $kid, $inherited, $pages, $visited, $depth + 1);
        }
        return;
    }

    $pages[] = ['dict' => $dict, 'inherited' => $inherited];
}

function tbpdf_page_attr(array $pageDict, array $inherited, string $key)
{
    $value = tbpdf_dict_get($pageDict, $key);
    return $value !== null ? $value : ($inherited[$key] ?? null);
}

function tbpdf_box(array &$doc, $value): ?array
{
    $values = tbpdf_array_values(tbpdf_resolve($doc, $value));
    if ($values === null || count($values) < 4) {
        return null;
    }
    $numbers = [];
    foreach (array_slice($values, 0, 4) as $item) {
        $number = tbpdf_num(tbpdf_resolve($doc, $item));
        if ($number === null) {
            return null;
        }
        $numbers[] = (float) $number;
    }
    $x1 = min($numbers[0], $numbers[2]);
    $y1 = min($numbers[1], $numbers[3]);
    $x2 = max($numbers[0], $numbers[2]);
    $y2 = max($numbers[1], $numbers[3]);
    return [
        'llx' => $x1,
        'lly' => $y1,
        'urx' => $x2,
        'ury' => $y2,
        'width' => $x2 - $x1,
        'height' => $y2 - $y1,
    ];
}

function tbpdf_analyze_page(
    array &$doc,
    array $pageEntry,
    int $number,
    array &$fonts,
    array &$imageFilterCounts
): array {
    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];

    $mediaBox = tbpdf_box($doc, tbpdf_page_attr($dict, $inherited, 'MediaBox'));
    if ($mediaBox === null) {
        $mediaBox = ['llx' => 0.0, 'lly' => 0.0, 'urx' => 612.0, 'ury' => 792.0, 'width' => 612.0, 'height' => 792.0];
        tbpdf_diag($doc, 'warning', 'mediabox_missing', 'Page ' . $number . ' has no valid MediaBox; US Letter was assumed.', $number);
    }
    $cropBox = tbpdf_box($doc, tbpdf_page_attr($dict, $inherited, 'CropBox')) ?? $mediaBox;

    $rotation = tbpdf_resolve_int($doc, tbpdf_page_attr($dict, $inherited, 'Rotate')) ?? 0;
    $rotation = (($rotation % 360) + 360) % 360;
    if (!in_array($rotation, [0, 90, 180, 270], true)) {
        $rotation = ((int) round($rotation / 90) * 90) % 360;
        tbpdf_diag($doc, 'warning', 'page_rotation_invalid', 'Page ' . $number . ' has an unusual rotation; it was normalized.', $number);
    }

    $userUnit = tbpdf_resolve_num($doc, tbpdf_page_attr($dict, $inherited, 'UserUnit'));
    $userUnit = $userUnit === null || (float) $userUnit <= 0 ? 1.0 : (float) $userUnit;

    $widthPt = $cropBox['width'] * $userUnit;
    $heightPt = $cropBox['height'] * $userUnit;
    $displayWidth = ($rotation === 90 || $rotation === 270) ? $heightPt : $widthPt;
    $displayHeight = ($rotation === 90 || $rotation === 270) ? $widthPt : $heightPt;

    $dpi = (int) $doc['opts']['dpi'];
    $factor = $dpi / 72;

    $resources = tbpdf_as_dict(
        tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources'))
    );
    $fontDict = $resources !== null
        ? tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'Font')))
        : null;
    $xObjectDict = $resources !== null
        ? tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')))
        : null;

    $stats = tbpdf_stats_init();
    $content = ['content' => '', 'failed' => 0, 'streams' => 0];
    $decoded = false;
    $contentAnalyzed = false;

    if ($doc['encrypted']) {
        $decoded = false;
    } elseif ($doc['opts']['include_content']) {
        $contentAnalyzed = true;
        $content = tbpdf_page_content($doc, $dict);
        $decoded = $content['failed'] === 0;
        if ($content['failed'] > 0) {
            $doc['analysis_limited'] = true;
            tbpdf_diag(
                $doc,
                'warning',
                'content_stream_undecodable',
                'Page ' . $number . ' has one or more content streams that could not be decoded.',
                $number
            );
        }
        if ($content['content'] !== '') {
            tbpdf_scan_content(
                $doc,
                $content['content'],
                $resources,
                $mediaBox['width'] * $mediaBox['height'],
                $stats
            );
        }
    }

    $imageInventory = tbpdf_image_inventory($doc, $xObjectDict, $imageFilterCounts);
    $usedFontNames = array_keys($stats['fonts_used']);
    $pageFontNames = tbpdf_extract_fonts($doc, $fontDict, $number, $fonts, $usedFontNames);

    $classification = ($contentAnalyzed && $decoded) ? tbpdf_classify_page($stats) : 'unknown';

    return [
        'number' => $number,
        'index' => $number - 1,
        'size' => [
            'width_pt' => round($displayWidth, 2),
            'height_pt' => round($displayHeight, 2),
            'width_px' => round($displayWidth * $factor, 2),
            'height_px' => round($displayHeight * $factor, 2),
            'standard' => tbpdf_standard_size($displayWidth, $displayHeight),
            'orientation' => tbpdf_orientation($displayWidth, $displayHeight),
            'rotation' => $rotation,
            'user_unit' => $userUnit,
        ],
        'boxes' => [
            'media' => [
                'llx' => round($mediaBox['llx'], 2),
                'lly' => round($mediaBox['lly'], 2),
                'urx' => round($mediaBox['urx'], 2),
                'ury' => round($mediaBox['ury'], 2),
            ],
            'crop' => [
                'llx' => round($cropBox['llx'], 2),
                'lly' => round($cropBox['lly'], 2),
                'urx' => round($cropBox['urx'], 2),
                'ury' => round($cropBox['ury'], 2),
            ],
        ],
        'resources' => [
            'fonts' => $fontDict !== null ? count($fontDict['v']) : 0,
            'xobjects' => $xObjectDict !== null ? count($xObjectDict['v']) : 0,
            'images' => $imageInventory['total'],
        ],
        'content' => [
            'classification' => $classification,
            'decoded' => $decoded,
            'streams' => $content['streams'],
            'bytes' => strlen($content['content']),
            'text_ops_visible' => $stats['text_ops_visible'],
            'text_ops_invisible' => $stats['text_ops_invisible'],
            'fonts' => $pageFontNames,
            'images' => $stats['images'],
            'image_area_ratio' => round(min(1.0, $stats['image_area']), 3),
            'inline_images' => $stats['inline_images'],
            'forms' => $stats['forms'],
            'vector_ops' => $stats['vector_ops'],
            'image_filters' => $imageInventory['filters'],
            'token_limit_reached' => $stats['token_limit_reached'],
        ],
        'annotations' => tbpdf_page_annotation_count($doc, $dict),
    ];
}

function tbpdf_page_content(array &$doc, array $pageDict): array
{
    $contents = tbpdf_dict_get($pageDict, 'Contents');
    if ($contents === null) {
        return ['content' => '', 'failed' => 0, 'streams' => 0];
    }

    $resolved = tbpdf_resolve($doc, $contents);
    $items = [];
    $array = tbpdf_array_values($resolved);
    if ($array !== null) {
        foreach ($array as $item) {
            $items[] = tbpdf_resolve($doc, $item);
        }
    } else {
        $items[] = $resolved;
    }

    $out = '';
    $failed = 0;
    $streams = 0;
    foreach ($items as $item) {
        if (!is_array($item) || ($item['t'] ?? '') !== 'stream') {
            continue;
        }
        $streams++;
        $data = tbpdf_decode_stream($doc, $item);
        if ($data === null) {
            $failed++;
            continue;
        }
        $out .= $data . "\n";
    }

    return ['content' => $out, 'failed' => $failed, 'streams' => $streams];
}

function tbpdf_page_annotation_count(array &$doc, array $pageDict): int
{
    $annots = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($pageDict, 'Annots')));
    return $annots === null ? 0 : count($annots);
}

function tbpdf_stats_init(): array
{
    return [
        'text_ops_visible' => 0,
        'text_ops_invisible' => 0,
        'fonts_used' => [],
        'images' => 0,
        'image_area' => 0.0,
        'inline_images' => 0,
        'forms' => 0,
        'vector_ops' => 0,
        'token_limit_reached' => false,
    ];
}

function tbpdf_scan_content(
    array &$doc,
    string $content,
    ?array $resources,
    float $pageArea,
    array &$stats,
    int $depth = 0,
    ?array $ctm = null
): void {
    $ctm = $ctm ?? [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
    $gsStack = [];
    $renderMode = 0;
    $operands = [];
    $pos = 0;
    $len = strlen($content);
    $tokens = 0;
    $maxTokens = 2000000;

    static $vectorOps = null;
    if ($vectorOps === null) {
        $vectorOps = array_flip([
            're', 'm', 'l', 'c', 'v', 'y', 'f', 'F', 'f*', 'B', 'B*', 'b', 'b*',
            'S', 's', 'n', 'W', 'W*', 'sh',
        ]);
    }

    while ($pos < $len) {
        $tokens++;
        if ($tokens > $maxTokens) {
            $stats['token_limit_reached'] = true;
            tbpdf_diag($doc, 'warning', 'content_token_limit', 'A content stream exceeded the token limit and was partially analyzed.');
            break;
        }

        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (is_array($token) && ($token['t'] ?? '') === 'kw') {
            $op = (string) $token['v'];

            if ($op === 'BI') {
                $stats['inline_images']++;
                $stats['images']++;
                $idPos = strpos($content, 'ID', $pos);
                if ($idPos === false) {
                    break;
                }
                $eiPos = strpos($content, 'EI', $idPos + 2);
                if ($eiPos === false) {
                    break;
                }
                $pos = $eiPos + 2;
                $operands = [];
                continue;
            }

            switch ($op) {
                case 'q':
                    $gsStack[] = ['ctm' => $ctm, 'tr' => $renderMode];
                    break;
                case 'Q':
                    if (count($gsStack) > 0) {
                        $state = array_pop($gsStack);
                        $ctm = $state['ctm'];
                        $renderMode = $state['tr'];
                    }
                    break;
                case 'cm':
                    $matrix = tbpdf_last_numbers($operands, 6);
                    if ($matrix !== null) {
                        $ctm = tbpdf_matrix_mult($matrix, $ctm);
                    }
                    break;
                case 'Tf':
                    $fontName = tbpdf_last_name($operands, 2);
                    if ($fontName !== null) {
                        $stats['fonts_used'][$fontName] = true;
                    }
                    break;
                case 'Tr':
                    $mode = tbpdf_last_int($operands, 1);
                    if ($mode !== null) {
                        $renderMode = $mode;
                    }
                    break;
                case 'Tj':
                case 'TJ':
                case "'":
                case '"':
                    if ($renderMode === 3) {
                        $stats['text_ops_invisible']++;
                    } else {
                        $stats['text_ops_visible']++;
                    }
                    break;
                case 'Do':
                    $name = tbpdf_last_name($operands, 1);
                    if ($name !== null) {
                        tbpdf_handle_xobject($doc, $resources, $name, $pageArea, $stats, $ctm, $depth);
                    }
                    break;
                default:
                    if (isset($vectorOps[$op])) {
                        $stats['vector_ops']++;
                    }
            }

            $operands = [];
            continue;
        }

        $operands[] = $token;
        if (count($operands) > 32) {
            array_shift($operands);
        }
    }
}

function tbpdf_handle_xobject(
    array &$doc,
    ?array $resources,
    string $name,
    float $pageArea,
    array &$stats,
    array $ctm,
    int $depth
): void {
    if ($resources === null || $depth > 4) {
        return;
    }

    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
    if ($xObjects === null || !isset($xObjects['v'][$name])) {
        return;
    }

    $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
    if (!is_array($xObject)) {
        return;
    }

    if (($xObject['t'] ?? '') === 'stream') {
        $dict = ['t' => 'dict', 'v' => $xObject['v']];
    } elseif (($xObject['t'] ?? '') === 'dict') {
        $dict = $xObject;
    } else {
        return;
    }

    $subtype = tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype'));

    if ($subtype === 'Image') {
        $stats['images']++;
        $corners = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
        $points = [];
        foreach ($corners as [$x, $y]) {
            $points[] = tbpdf_apply_matrix($ctm, $x, $y);
        }
        $area = tbpdf_polygon_area($points);
        if ($pageArea > 0) {
            $stats['image_area'] += min(1.0, $area / $pageArea);
        }
        return;
    }

    if ($subtype === 'Form' && ($xObject['t'] ?? '') === 'stream') {
        $stats['forms']++;
        if ($depth >= 4) {
            return;
        }

        $formCtm = $ctm;
        $matrix = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Matrix')));
        if ($matrix !== null && count($matrix) >= 6) {
            $numbers = [];
            $valid = true;
            foreach (array_slice($matrix, 0, 6) as $item) {
                $number = tbpdf_num(tbpdf_resolve($doc, $item));
                if ($number === null) {
                    $valid = false;
                    break;
                }
                $numbers[] = (float) $number;
            }
            if ($valid) {
                $formCtm = tbpdf_matrix_mult($numbers, $ctm);
            }
        }

        $data = tbpdf_decode_stream($doc, $xObject);
        if ($data === null) {
            return;
        }
        $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources')));
        tbpdf_scan_content($doc, $data, $formResources ?? $resources, $pageArea, $stats, $depth + 1, $formCtm);
    }
}

function tbpdf_last_numbers(array $operands, int $count): ?array
{
    if (count($operands) < $count) {
        return null;
    }
    $slice = array_slice($operands, -$count);
    $out = [];
    foreach ($slice as $value) {
        $number = tbpdf_num($value);
        if ($number === null) {
            return null;
        }
        $out[] = (float) $number;
    }
    return $out;
}

function tbpdf_last_name(array $operands, int $offsetFromEnd): ?string
{
    $index = count($operands) - $offsetFromEnd;
    if ($index < 0) {
        return null;
    }
    return tbpdf_name_value($operands[$index]);
}

function tbpdf_last_int(array $operands, int $offsetFromEnd): ?int
{
    $index = count($operands) - $offsetFromEnd;
    if ($index < 0) {
        return null;
    }
    $number = tbpdf_num($operands[$index]);
    return $number === null ? null : (int) $number;
}

function tbpdf_matrix_mult(array $m1, array $m2): array
{
    return [
        $m1[0] * $m2[0] + $m1[1] * $m2[2],
        $m1[0] * $m2[1] + $m1[1] * $m2[3],
        $m1[2] * $m2[0] + $m1[3] * $m2[2],
        $m1[2] * $m2[1] + $m1[3] * $m2[3],
        $m1[4] * $m2[0] + $m1[5] * $m2[2] + $m2[4],
        $m1[4] * $m2[1] + $m1[5] * $m2[3] + $m2[5],
    ];
}

function tbpdf_apply_matrix(array $m, float $x, float $y): array
{
    return [
        $m[0] * $x + $m[2] * $y + $m[4],
        $m[1] * $x + $m[3] * $y + $m[5],
    ];
}

function tbpdf_polygon_area(array $points): float
{
    $count = count($points);
    if ($count < 3) {
        return 0.0;
    }
    $sum = 0.0;
    for ($i = 0; $i < $count; $i++) {
        $j = ($i + 1) % $count;
        $sum += $points[$i][0] * $points[$j][1] - $points[$j][0] * $points[$i][1];
    }
    return abs($sum) / 2;
}

function tbpdf_classify_page(array $stats): string
{
    if ($stats['text_ops_visible'] > 0) {
        return $stats['image_area'] >= 0.35 ? 'mixed' : 'text';
    }
    if ($stats['text_ops_invisible'] > 0) {
        return $stats['images'] > 0 ? 'image-only-ocr' : 'text-invisible';
    }
    if ($stats['images'] > 0) {
        return 'image-only';
    }
    if ($stats['vector_ops'] > 0) {
        return 'vector';
    }
    return 'empty';
}

function tbpdf_image_inventory(array &$doc, ?array $xObjects, array &$filterCounts): array
{
    if ($xObjects === null) {
        return ['total' => 0, 'filters' => []];
    }

    $total = 0;
    $local = [];
    foreach ($xObjects['v'] as $item) {
        $xObject = tbpdf_resolve($doc, $item);
        if (!is_array($xObject) || ($xObject['t'] ?? '') !== 'stream') {
            continue;
        }
        $dict = ['t' => 'dict', 'v' => $xObject['v']];
        if (tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype')) !== 'Image') {
            continue;
        }
        $total++;
        $filters = tbpdf_filter_names($doc, $dict);
        foreach ($filters as $filter) {
            $local[$filter] = ($local[$filter] ?? 0) + 1;
            $filterCounts[$filter] = ($filterCounts[$filter] ?? 0) + 1;
        }
    }

    return ['total' => $total, 'filters' => $local];
}

function tbpdf_filter_names(array &$doc, array $dict): array
{
    $filter = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Filter'));
    $names = [];
    $array = tbpdf_array_values($filter);
    if ($array !== null) {
        foreach ($array as $item) {
            $name = tbpdf_name_value(tbpdf_resolve($doc, $item));
            if ($name !== null) {
                $names[] = $name;
            }
        }
    } else {
        $name = tbpdf_name_value($filter);
        if ($name !== null) {
            $names[] = $name;
        }
    }
    return $names === [] ? ['none'] : $names;
}

function tbpdf_extract_fonts(
    array &$doc,
    ?array $fontDict,
    int $pageNumber,
    array &$fonts,
    array $usedResourceNames
): array {
    if ($fontDict === null) {
        return [];
    }

    $pageFonts = [];
    foreach ($fontDict['v'] as $resourceName => $fontRef) {
        $font = tbpdf_as_dict(tbpdf_resolve($doc, $fontRef));
        if ($font === null) {
            tbpdf_diag($doc, 'warning', 'font_invalid', 'A font resource on page ' . $pageNumber . ' is not a dictionary.', $pageNumber);
            continue;
        }

        $subtype = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'Subtype')) ?? 'unknown';
        $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'BaseFont'));
        $descriptor = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($font, 'FontDescriptor')));
        $ordering = null;
        $composite = $subtype === 'Type0';

        if ($composite) {
            $descendants = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($font, 'DescendantFonts')));
            if ($descendants !== null && isset($descendants[0])) {
                $cidFont = tbpdf_as_dict(tbpdf_resolve($doc, $descendants[0]));
                if ($cidFont !== null) {
                    if ($baseFont === null) {
                        $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($cidFont, 'BaseFont'));
                    }
                    if ($descriptor === null) {
                        $descriptor = tbpdf_as_dict(
                            tbpdf_resolve($doc, tbpdf_dict_get($cidFont, 'FontDescriptor'))
                        );
                    }
                    $cidInfo = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($cidFont, 'CIDSystemInfo')));
                    if ($cidInfo !== null) {
                        $ordering = tbpdf_decode_text_value($doc, tbpdf_dict_get($cidInfo, 'Ordering'));
                    }
                }
            }
        }

        $cleanName = tbpdf_font_name_clean($baseFont) ?? (string) $resourceName;
        $key = strtolower($cleanName) . '|' . strtolower($subtype);

        if (!isset($fonts[$key])) {
            $weight = tbpdf_font_weight($cleanName, $descriptor !== null ? tbpdf_num($descriptor['v']['FontWeight'] ?? null) : null);
            $italicAngle = 0.0;
            if ($descriptor !== null) {
                $angle = tbpdf_num($descriptor['v']['ItalicAngle'] ?? null);
                $italicAngle = $angle === null ? 0.0 : (float) $angle;
            }
            $fonts[$key] = [
                'name' => $cleanName,
                'base_name' => $baseFont,
                'family' => tbpdf_font_family_guess($cleanName),
                'subtype' => $subtype,
                'composite' => $composite,
                'cid_ordering' => $ordering,
                'encoding' => tbpdf_font_encoding($doc, $font),
                'embedded' => false,
                'embedded_format' => null,
                'to_unicode' => tbpdf_dict_get($font, 'ToUnicode') !== null,
                'weight' => $weight[0],
                'weight_source' => $weight[1],
                'style' => tbpdf_font_style($cleanName, $italicAngle),
                'flags' => $descriptor !== null ? tbpdf_num($descriptor['v']['Flags'] ?? null) : null,
                'pages' => [],
                'used' => false,
                'resource_names' => [],
            ];
        }

        if (!in_array($pageNumber, $fonts[$key]['pages'], true)) {
            $fonts[$key]['pages'][] = $pageNumber;
        }
        if (in_array($resourceName, $usedResourceNames, true)) {
            $fonts[$key]['used'] = true;
        }
        $fonts[$key]['resource_names'][$resourceName] = true;

        if ($descriptor !== null) {
            foreach (['FontFile' => 'Type1', 'FontFile2' => 'TrueType', 'FontFile3' => 'CFF/OpenType'] as $field => $label) {
                if (tbpdf_dict_get($descriptor, $field) !== null) {
                    $fonts[$key]['embedded'] = true;
                    $fonts[$key]['embedded_format'] = $label;
                    break;
                }
            }
            $weight = tbpdf_num($descriptor['v']['FontWeight'] ?? null);
            if ($weight !== null) {
                $fonts[$key]['weight'] = (int) $weight;
                $fonts[$key]['weight_source'] = 'declared';
            }
        }

        $pageFonts[] = $cleanName;
    }

    return array_values(array_unique($pageFonts));
}

function tbpdf_font_encoding(array &$doc, array $font): ?string
{
    $encoding = tbpdf_resolve($doc, tbpdf_dict_get($font, 'Encoding'));
    $name = tbpdf_name_value($encoding);
    if ($name !== null) {
        return $name;
    }
    $dict = tbpdf_as_dict($encoding);
    if ($dict !== null) {
        $base = tbpdf_name_value(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'BaseEncoding')));
        $hasDifferences = tbpdf_dict_get($dict, 'Differences') !== null;
        return ($base ?? 'custom') . ($hasDifferences ? '+differences' : '');
    }
    return null;
}

function tbpdf_font_name_clean(?string $name): ?string
{
    if ($name === null || $name === '') {
        return null;
    }
    return preg_replace('/^[A-Z]{6}\+/', '', $name);
}

function tbpdf_font_family_guess(string $name): string
{
    $guess = preg_replace('/[-,].*$/', '', $name);
    return $guess === '' ? $name : $guess;
}

function tbpdf_font_weight(string $name, $declared): array
{
    if ($declared !== null) {
        return [(int) $declared, 'declared'];
    }

    $lower = strtolower($name);
    $rules = [
        ['black', 900],
        ['heavy', 900],
        ['extrabold', 800],
        ['ultrabold', 800],
        ['semibold', 600],
        ['demibold', 600],
        ['bold', 700],
        ['medium', 500],
        ['extralight', 200],
        ['ultralight', 200],
        ['light', 300],
        ['thin', 100],
        ['hairline', 100],
    ];
    foreach ($rules as [$needle, $weight]) {
        if (strpos($lower, $needle) !== false) {
            return [$weight, 'inferred'];
        }
    }
    return [null, 'unknown'];
}

function tbpdf_font_style(string $name, float $italicAngle): array
{
    $lower = strtolower($name);
    return [
        'bold' => strpos($lower, 'bold') !== false || strpos($lower, 'black') !== false,
        'italic' => strpos($lower, 'italic') !== false || strpos($lower, 'oblique') !== false || abs($italicAngle) > 0.5,
    ];
}

function tbpdf_sorted_fonts(array $fonts): array
{
    $list = array_values($fonts);
    usort($list, static function (array $a, array $b): int {
        return strcmp(strtolower($a['name']), strtolower($b['name']));
    });
    foreach ($list as &$font) {
        $font['resource_names'] = array_keys($font['resource_names']);
    }
    unset($font);
    return $list;
}

function tbpdf_fonts_summary(array $fonts): array
{
    $types = [];
    $embedded = 0;
    $toUnicode = 0;
    $used = 0;
    $bold = 0;
    $italic = 0;
    $unknownWeight = 0;

    foreach ($fonts as $font) {
        $subtype = (string) $font['subtype'];
        $types[$subtype] = ($types[$subtype] ?? 0) + 1;
        if ($font['embedded']) {
            $embedded++;
        }
        if ($font['to_unicode']) {
            $toUnicode++;
        }
        if ($font['used']) {
            $used++;
        }
        if ($font['style']['bold']) {
            $bold++;
        }
        if ($font['style']['italic']) {
            $italic++;
        }
        if ($font['weight_source'] === 'unknown') {
            $unknownWeight++;
        }
    }

    return [
        'count' => count($fonts),
        'used' => $used,
        'embedded' => $embedded,
        'with_to_unicode' => $toUnicode,
        'bold' => $bold,
        'italic' => $italic,
        'unknown_weight' => $unknownWeight,
        'types' => $types,
    ];
}

function tbpdf_standard_size(float $width, float $height): ?string
{
    $sizes = [
        'A0' => [2383.94, 3370.39],
        'A1' => [1683.78, 2383.94],
        'A2' => [1190.55, 1683.78],
        'A3' => [841.89, 1190.55],
        'A4' => [595.28, 841.89],
        'A5' => [419.53, 595.28],
        'A6' => [297.64, 419.53],
        'Letter' => [612.0, 792.0],
        'Legal' => [612.0, 1008.0],
        'Tabloid' => [792.0, 1224.0],
        'Executive' => [522.0, 756.0],
    ];
    $sorted = [$width, $height];
    sort($sorted);

    foreach ($sizes as $name => [$w, $h]) {
        $target = [$w, $h];
        sort($target);
        if (abs($sorted[0] - $target[0]) <= 3.0 && abs($sorted[1] - $target[1]) <= 3.0) {
            return $name;
        }
    }
    return null;
}

function tbpdf_orientation(float $width, float $height): string
{
    if (abs($width - $height) < 0.5) {
        return 'square';
    }
    return $width > $height ? 'landscape' : 'portrait';
}

function tbpdf_screen_summary(array $pages, array $opts): ?array
{
    if (count($pages) === 0) {
        return null;
    }

    $modeCounts = [];
    $modeSizes = [];
    foreach ($pages as $page) {
        $width = (int) round($page['size']['width_px']);
        $height = (int) round($page['size']['height_px']);
        if ($width <= 0 || $height <= 0) {
            continue;
        }
        $key = $width . 'x' . $height;
        $modeCounts[$key] = ($modeCounts[$key] ?? 0) + 1;
        $modeSizes[$key] = [$width, $height];
    }
    if (count($modeCounts) === 0) {
        return null;
    }

    arsort($modeCounts);
    $modeKey = (string) array_key_first($modeCounts);
    [$modeWidth, $modeHeight] = $modeSizes[$modeKey];

    $orientations = [];
    foreach ($pages as $page) {
        $orientations[$page['size']['orientation']] = true;
    }
    $type = count($orientations) === 1 ? (string) array_key_first($orientations) : 'both';
    if ($type === 'square') {
        $type = 'both';
    }

    return [
        'big' => max($modeWidth, $modeHeight),
        'small' => min($modeWidth, $modeHeight),
        'type' => $type,
        'bgcolor' => '0xFFFFFF',
        'bgcolor_assumed' => true,
        'dpi' => $opts['dpi'],
        'page_size_mode' => [
            'width_px' => $modeWidth,
            'height_px' => $modeHeight,
            'pages' => $modeCounts[$modeKey],
        ],
    ];
}

function tbpdf_content_summary(array $pages, array $doc): array
{
    $counts = [];
    $visible = 0;
    $invisible = 0;
    $images = 0;
    $imagesUsed = 0;
    $vector = 0;
    $undecoded = 0;

    foreach ($pages as $page) {
        $classification = (string) ($page['content']['classification'] ?? 'unknown');
        $counts[$classification] = ($counts[$classification] ?? 0) + 1;
        $visible += (int) ($page['content']['text_ops_visible'] ?? 0);
        $invisible += (int) ($page['content']['text_ops_invisible'] ?? 0);
        $images += (int) ($page['resources']['images'] ?? 0);
        $imagesUsed += (int) ($page['content']['images'] ?? 0);
        $vector += (int) ($page['content']['vector_ops'] ?? 0);
        if (!($page['content']['decoded'] ?? false)) {
            $undecoded++;
        }
    }

    $total = count($pages);
    $textLike = ($counts['text'] ?? 0) + ($counts['mixed'] ?? 0) + ($counts['text-invisible'] ?? 0);
    $imageLike = ($counts['image-only'] ?? 0) + ($counts['image-only-ocr'] ?? 0);
    $unknown = ($counts['unknown'] ?? 0);
    $vectorOnly = ($counts['vector'] ?? 0);

    if ($total === 0) {
        $classification = 'empty';
    } elseif ($doc['encrypted'] && $unknown === $total) {
        $classification = 'unknown';
    } elseif ($imageLike === $total) {
        $classification = 'image-only';
    } elseif ($textLike === $total) {
        $classification = 'text';
    } elseif ($vectorOnly === $total) {
        $classification = 'vector';
    } elseif ($unknown === $total) {
        $classification = 'unknown';
    } else {
        $classification = 'mixed';
    }

    return [
        'classification' => $classification,
        'classification_counts' => $counts,
        'pages_with_visible_text' => $visible > 0 ? $counts['text'] ?? 0 : 0,
        'has_visible_text' => $visible > 0,
        'has_selectable_text' => $visible > 0 || $invisible > 0,
        'text_layer_present' => $invisible > 0,
        'needs_ocr' => ($counts['image-only'] ?? 0) > 0,
        'text_ops_visible' => $visible,
        'text_ops_invisible' => $invisible,
        'images_total' => $images,
        'images_used' => $imagesUsed,
        'image_filters' => $doc['image_filters'],
        'vector_ops' => $vector,
        'pages_undecoded' => $undecoded,
        'encrypted' => $doc['encrypted'],
    ];
}

/* -------------------------------------------------------------------------
 * Metadata and security
 * ---------------------------------------------------------------------- */

function tbpdf_extract_metadata(array &$doc, ?array $catalog, array $opts): array
{
    $out = ['info' => [], 'xmp' => null, 'catalog' => []];
    $map = [
        'Title' => 'title',
        'Author' => 'author',
        'Subject' => 'subject',
        'Keywords' => 'keywords',
        'Creator' => 'creator',
        'Producer' => 'producer',
        'CreationDate' => 'creation_date',
        'ModDate' => 'modification_date',
        'Trapped' => 'trapped',
    ];
    $dateKeys = ['creation_date', 'modification_date'];

    if ($doc['trailer'] !== null) {
        $info = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($doc['trailer'], 'Info')));
        if ($info !== null) {
            foreach ($map as $pdfKey => $outputKey) {
                $value = tbpdf_decode_text_value($doc, tbpdf_dict_get($info, $pdfKey));
                if ($value === null || $value === '') {
                    continue;
                }
                $out['info'][$outputKey] = in_array($outputKey, $dateKeys, true)
                    ? tbpdf_normalize_date($value)
                    : $value;
            }
        }
    }

    if ($catalog !== null) {
        $out['catalog'] = [
            'lang' => tbpdf_decode_text_value($doc, tbpdf_dict_get($catalog, 'Lang')),
            'version' => tbpdf_resolve_name($doc, tbpdf_dict_get($catalog, 'Version')),
            'acro_form' => tbpdf_dict_get($catalog, 'AcroForm') !== null,
            'optional_content' => tbpdf_dict_get($catalog, 'OCProperties') !== null,
            'outlines' => tbpdf_dict_get($catalog, 'Outlines') !== null,
            'names' => tbpdf_dict_get($catalog, 'Names') !== null,
            'page_labels' => tbpdf_dict_get($catalog, 'PageLabels') !== null,
            'embedded_files' => tbpdf_dict_get($catalog, 'EmbeddedFiles') !== null,
            'output_intents' => tbpdf_dict_get($catalog, 'OutputIntents') !== null,
        ];

        if ($opts['include_xmp'] && !$doc['encrypted']) {
            $metadataStream = tbpdf_resolve($doc, tbpdf_dict_get($catalog, 'Metadata'));
            if (is_array($metadataStream) && ($metadataStream['t'] ?? '') === 'stream') {
                $xmp = tbpdf_decode_stream($doc, $metadataStream);
                if ($xmp !== null) {
                    if (strlen($xmp) > 1048576) {
                        $xmp = substr($xmp, 0, 1048576);
                        tbpdf_diag($doc, 'info', 'xmp_truncated', 'The XMP metadata was truncated to 1 MB.');
                    }
                    $out['xmp'] = $xmp;
                }
            }
        }
    }

    return $out;
}

function tbpdf_decode_text_value(array &$doc, $value): ?string
{
    $resolved = tbpdf_resolve($doc, $value);
    if (!is_array($resolved) || ($resolved['t'] ?? '') !== 'str') {
        return null;
    }
    return tbpdf_decode_pdf_string($resolved['v']);
}

function tbpdf_decode_pdf_string(string $raw): string
{
    if ($raw === '') {
        return '';
    }
    if (str_starts_with($raw, "\xFE\xFF")) {
        return tbpdf_to_utf8(substr($raw, 2), 'UTF-16BE');
    }
    if (str_starts_with($raw, "\xFF\xFE")) {
        return tbpdf_to_utf8(substr($raw, 2), 'UTF-16LE');
    }
    return tbpdf_to_utf8($raw, 'Windows-1252');
}

function tbpdf_to_utf8(string $value, string $from): string
{
    if (function_exists('mb_convert_encoding')) {
        $converted = @mb_convert_encoding($value, 'UTF-8', $from);
        if (is_string($converted)) {
            return $converted;
        }
    }
    if (function_exists('iconv')) {
        $converted = @iconv($from, 'UTF-8//IGNORE', $value);
        if (is_string($converted)) {
            return $converted;
        }
    }
    return $value;
}

function tbpdf_normalize_date(?string $value): ?string
{
    if ($value === null || $value === '') {
        return null;
    }
    if (preg_match('/^D:(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?([Zz+\-])?(?:(\d{2})\'?)?(?:(\d{2})\'?)?/', $value, $m)) {
        $year = $m[1];
        $month = ($m[2] ?? '') !== '' ? $m[2] : '01';
        $day = ($m[3] ?? '') !== '' ? $m[3] : '01';
        $hour = ($m[4] ?? '') !== '' ? $m[4] : '00';
        $minute = ($m[5] ?? '') !== '' ? $m[5] : '00';
        $second = ($m[6] ?? '') !== '' ? $m[6] : '00';
        $timezone = '';
        if (!empty($m[7])) {
            if ($m[7] === 'Z' || $m[7] === 'z') {
                $timezone = 'Z';
            } else {
                $sign = $m[7] === '-' ? '-' : '+';
                $offsetHours = ($m[8] ?? '') !== '' ? $m[8] : '00';
                $offsetMinutes = ($m[9] ?? '') !== '' ? $m[9] : '00';
                $timezone = $sign . $offsetHours . ':' . $offsetMinutes;
            }
        }
        return $year . '-' . $month . '-' . $day . 'T' . $hour . ':' . $minute . ':' . $second . $timezone;
    }
    return $value;
}

function tbpdf_security_report(array &$doc, ?array $catalog): array
{
    $encrypt = $doc['encrypt'];
    $handler = null;
    $version = null;
    $revision = null;
    $permissions = null;

    if ($encrypt !== null) {
        $handler = tbpdf_name_value($encrypt['v']['Filter'] ?? null);
        $v = tbpdf_num($encrypt['v']['V'] ?? null);
        $r = tbpdf_num($encrypt['v']['R'] ?? null);
        $version = $v === null ? null : (int) $v;
        $revision = $r === null ? null : (int) $r;
        $permissions = tbpdf_permission_flags($encrypt['v']['P'] ?? null);
    }

    $signed = false;
    if ($catalog !== null) {
        $acroForm = tbpdf_as_dict(tbpdf_resolve($doc, $catalog['v']['AcroForm'] ?? null));
        if ($acroForm !== null) {
            $sigFlags = tbpdf_num($acroForm['v']['SigFlags'] ?? null);
            $signed = $sigFlags !== null && ((int) $sigFlags & 1) === 1;
        }
        if (isset($catalog['v']['Perms'])) {
            $signed = true;
        }
    }

    return [
        'encrypted' => $doc['encrypted'],
        'requires_password' => null,
        'permissions' => $permissions,
        'digitally_signed' => $signed,
        'content_analysis_available' => !$doc['encrypted'],
        'encryption' => $doc['encrypted'] ? [
            'handler' => $handler,
            'version' => $version,
            'revision' => $revision,
            'note' => 'Encrypted streams were not decrypted by this analysis stage.',
        ] : null,
    ];
}

function tbpdf_permission_flags($value): ?array
{
    $number = tbpdf_num($value);
    if ($number === null) {
        return null;
    }
    $p = (int) $number;
    return [
        'raw' => $p,
        'print' => (bool) (($p >> 2) & 1),
        'modify' => (bool) (($p >> 3) & 1),
        'copy' => (bool) (($p >> 4) & 1),
        'annotate' => (bool) (($p >> 5) & 1),
        'fill_forms' => (bool) (($p >> 8) & 1),
        'accessibility' => (bool) (($p >> 9) & 1),
        'assemble' => (bool) (($p >> 10) & 1),
        'high_quality_print' => (bool) (($p >> 11) & 1),
    ];
}

/* -------------------------------------------------------------------------
 * Page range selection (stages 2 to 7)
 * ---------------------------------------------------------------------- */

function tbpdf_page_selection(array $data, array $options = []): array
{
    $total = isset($data['pages']) && is_numeric($data['pages']) ? (int) $data['pages'] : 0;
    if ($total <= 0) {
        return [
            'from' => 1,
            'to' => 0,
            'count' => 0,
            'total' => 0,
            'error' => ['code' => 'invalid_pages', 'message' => 'The analysis JSON must contain a positive page count.'],
        ];
    }

    $from = isset($options['page_from']) && is_numeric($options['page_from']) ? (int) $options['page_from'] : 1;
    $to = isset($options['page_to']) && is_numeric($options['page_to']) && (int) $options['page_to'] > 0
        ? (int) $options['page_to']
        : $total;

    if ($from < 1) {
        $from = 1;
    }
    if ($from > $total) {
        return [
            'from' => $from,
            'to' => $to,
            'count' => 0,
            'total' => $total,
            'error' => [
                'code' => 'invalid_page_range',
                'message' => 'The first page of the range (' . $from . ') is beyond the last page (' . $total . ').',
            ],
        ];
    }
    if ($to > $total) {
        $to = $total;
    }
    if ($to < $from) {
        return [
            'from' => $from,
            'to' => $to,
            'count' => 0,
            'total' => $total,
            'error' => [
                'code' => 'invalid_page_range',
                'message' => 'The last page of the range (' . $to . ') is before the first page (' . $from . ').',
            ],
        ];
    }

    return [
        'from' => $from,
        'to' => $to,
        'count' => $to - $from + 1,
        'total' => $total,
        'error' => null,
    ];
}

/**
 * Maps a PDF page number to its sequential movie page number.
 */
function tbpdf_movie_page(int $pdfPage, array $selection): int
{
    return $pdfPage - $selection['from'] + 1;
}

/* -------------------------------------------------------------------------
 * Stage 2: media recovery
 * ---------------------------------------------------------------------- */

/**
 * Extracts the images found in a PDF into a TilBuci movie structure.
 *
 * The first parameter is the definitive JSON string produced by stage 1.
 * The second is the movie ID. The optional third parameter is the directory
 * where "[ID].movie" is created; it defaults to the PDF directory.
 *
 * Structure created:
 *   [ID].movie/media/picture/<page number>/image-NN.<ext>
 *
 * Images that cannot be converted to a portable format (CCITT, JBIG2,
 * encrypted content, and so on) are reported in the result instead of being
 * written as unusable files.
 */
function tbpdf_extract_media(string $analysisJson, string $movieId, ?string $baseDir = null, array $options = []): array
{
    $options = array_merge([
        'vector' => true,
        'vector_dpi' => 96,
        'vector_max_pixels' => 4000000,
        'vector_max_objects' => 250,
        'vector_aa' => 2,
    ], $options);

    $result = [
        'movie' => null,
        'id' => $movieId,
        'created' => false,
        'page_from' => 1,
        'page_to' => 0,
        'page_count' => 0,
        'pages' => [],
        'images_extracted' => 0,
        'images_skipped' => 0,
        'vectors_extracted' => 0,
        'vectors_skipped' => 0,
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_media_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }

    $file = $data['file'] ?? null;
    if (!is_string($file) || $file === '' || !is_file($file) || !is_readable($file)) {
        return tbpdf_media_fail($result, 'file_not_readable', 'The PDF path in the analysis JSON is not a readable file.');
    }
    $fileSize = @filesize($file);
    if ($fileSize !== false && $fileSize > 268435456) {
        return tbpdf_media_fail($result, 'file_too_large', 'The PDF exceeds the 256 MB limit for media extraction.');
    }

    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_media_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }

    $raw = @file_get_contents($file);
    if ($raw === false) {
        return tbpdf_media_fail($result, 'file_read_failed', 'The PDF file could not be loaded into memory.');
    }

    $doc = tbpdf_doc($file, $raw, tbpdf_options([]));
    $pages = tbpdf_parse_document($doc);
    foreach ($doc['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }

    if ($doc['encrypted']) {
        return tbpdf_media_fail($result, 'encrypted_pdf', 'Encrypted PDF streams cannot be extracted by stage 2.');
    }
    if (count($pages) === 0) {
        return tbpdf_media_fail($result, 'no_pages', 'The PDF contains no pages to extract.');
    }

    $selection = tbpdf_page_selection(['pages' => count($pages)], $options);
    if ($selection['error'] !== null) {
        return tbpdf_media_fail($result, $selection['error']['code'], $selection['error']['message']);
    }
    $result['page_from'] = $selection['from'];
    $result['page_to'] = $selection['to'];
    $result['page_count'] = $selection['count'];
    if ($selection['count'] < count($pages)) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'page_range_applied',
            'message' => 'Only pages ' . $selection['from'] . ' to ' . $selection['to'] . ' will be converted.',
            'page' => null,
        ];
    }

    $declaredPages = isset($data['pages']) ? (int) $data['pages'] : null;
    if ($declaredPages !== null && $declaredPages !== count($pages)) {
        $result['diagnostics'][] = [
            'level' => 'warning',
            'code' => 'page_count_mismatch',
            'message' => 'The analysis JSON declares ' . $declaredPages . ' page(s), but the PDF has ' . count($pages) . '.',
            'page' => null,
        ];
    }

    $baseDir = $baseDir !== null ? rtrim($baseDir, '/\\') : rtrim(dirname($file), '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_media_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }
    if (!is_writable($baseDir)) {
        return tbpdf_media_fail($result, 'base_dir_not_writable', 'The output base directory is not writable.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    $result['created'] = !is_dir($moviePath);
    if (!is_dir($moviePath) && !mkdir($moviePath, 0777, true) && !is_dir($moviePath)) {
        return tbpdf_media_fail($result, 'movie_create_failed', 'The movie folder could not be created: ' . $moviePath);
    }
    $result['movie'] = $moviePath;

    if (!$result['created']) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'movie_exists',
            'message' => 'The movie folder already existed; extracted files may overwrite previous ones.',
            'page' => null,
        ];
    }

    $mediaDir = $moviePath . DIRECTORY_SEPARATOR . 'media';
    $pictureDir = $mediaDir . DIRECTORY_SEPARATOR . 'picture';
    foreach ([$mediaDir, $pictureDir] as $directory) {
        if (!is_dir($directory) && !mkdir($directory, 0777, true) && !is_dir($directory)) {
            return tbpdf_media_fail($result, 'media_dir_create_failed', 'The media folder could not be created: ' . $directory);
        }
    }

    foreach ($pages as $index => $pageEntry) {
        $pdfPageNumber = $index + 1;
        if ($pdfPageNumber < $selection['from'] || $pdfPageNumber > $selection['to']) {
            continue;
        }
        $pageNumber = tbpdf_movie_page($pdfPageNumber, $selection);
        $pageDir = $pictureDir . DIRECTORY_SEPARATOR . $pageNumber;
        if (!is_dir($pageDir) && !mkdir($pageDir, 0777, true) && !is_dir($pageDir)) {
            $result['diagnostics'][] = [
                'level' => 'error',
                'code' => 'page_dir_create_failed',
                'message' => 'The folder for page ' . $pageNumber . ' could not be created.',
                'page' => $pageNumber,
            ];
            continue;
        }

        $collected = tbpdf_collect_page_images($doc, $pageEntry, $pageNumber);
        foreach ($collected['diagnostics'] as $diagnostic) {
            $result['diagnostics'][] = $diagnostic;
        }

        $pageImages = [];
        foreach ($collected['images'] as $imageIndex => $image) {
            $targetBase = $pageDir . DIRECTORY_SEPARATOR .
                'image-' . str_pad((string) ($imageIndex + 1), 2, '0', STR_PAD_LEFT);
            $extracted = tbpdf_extract_image($doc, $image, $targetBase);
            if (!empty($extracted['ok'])) {
                $result['images_extracted']++;
            } else {
                $result['images_skipped']++;
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => (string) ($extracted['code'] ?? 'image_skipped'),
                    'message' => (string) ($extracted['message'] ?? 'An image could not be extracted.'),
                    'page' => $pageNumber,
                ];
            }
            $pageImages[] = $extracted;
        }

        $pageVectors = [];
        if (!empty($options['vector'])) {
            $vectorResult = tbpdf_extract_page_vectors($doc, $pageEntry, $pageNumber, $pageDir, $options);
            foreach ($vectorResult['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            foreach ($vectorResult['vectors'] as $vector) {
                if (!empty($vector['ok'])) {
                    $result['vectors_extracted']++;
                } else {
                    $result['vectors_skipped']++;
                }
            }
            $pageVectors = $vectorResult['vectors'];
        }

        $result['pages'][] = [
            'page' => $pageNumber,
            'folder' => $pageDir,
            'images' => $pageImages,
            'vectors' => $pageVectors,
        ];
    }

    return $result;
}

/**
 * Convenience wrapper that returns the stage 2 result as JSON.
 */
function tbpdf_extract_media_to_json(string $analysisJson, string $movieId, ?string $baseDir = null, array $options = []): string
{
    return tbpdf_json_encode(tbpdf_extract_media($analysisJson, $movieId, $baseDir, $options));
}

function tbpdf_media_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

function tbpdf_collect_page_images(array &$doc, array $pageEntry, int $pageNumber): array
{
    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];
    $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));

    $images = [];
    $seen = [];
    $visitedForms = [];
    $diagnostics = [];

    $content = tbpdf_page_content($doc, $dict);
    if ($content['failed'] > 0) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'content_stream_undecodable',
            'message' => 'Page ' . $pageNumber . ' has content streams that could not be decoded; some images may be missing.',
            'page' => $pageNumber,
        ];
    }
    if ($content['content'] !== '') {
        tbpdf_collect_images_from_content(
            $doc,
            $content['content'],
            $resources,
            $pageNumber,
            $images,
            $seen,
            $visitedForms,
            0,
            $diagnostics
        );
    }

    // Include image XObjects declared in the page resources even when the
    // content stream does not reference them explicitly.
    if ($resources !== null) {
        $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
        if ($xObjects !== null) {
            foreach ($xObjects['v'] as $name => $reference) {
                $xObject = tbpdf_resolve($doc, $reference);
                if (!is_array($xObject) || ($xObject['t'] ?? '') !== 'stream') {
                    continue;
                }
                $xDict = ['t' => 'dict', 'v' => $xObject['v']];
                if (tbpdf_name_value(tbpdf_dict_get($xDict, 'Subtype')) === 'Image') {
                    tbpdf_register_image($images, $seen, $xObject, (string) $name);
                }
            }
        }
    }

    return ['images' => $images, 'diagnostics' => $diagnostics];
}

function tbpdf_collect_images_from_content(
    array &$doc,
    string $content,
    ?array $resources,
    int $pageNumber,
    array &$images,
    array &$seen,
    array &$visitedForms,
    int $depth,
    array &$diagnostics
): void {
    $pos = 0;
    $len = strlen($content);
    $operands = [];
    $tokens = 0;

    while ($pos < $len) {
        $tokens++;
        if ($tokens > 2000000) {
            $diagnostics[] = [
                'level' => 'warning',
                'code' => 'content_token_limit',
                'message' => 'Page ' . $pageNumber . ' content exceeded the token limit during image collection.',
                'page' => $pageNumber,
            ];
            break;
        }

        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (is_array($token) && ($token['t'] ?? '') === 'kw') {
            $operator = (string) $token['v'];

            if ($operator === 'BI') {
                tbpdf_collect_inline_image($doc, $content, $pos, $pageNumber, $images, $seen, $diagnostics);
                $operands = [];
                continue;
            }

            if ($operator === 'Do') {
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    tbpdf_collect_xobject_image(
                        $doc,
                        $resources,
                        $name,
                        $pageNumber,
                        $images,
                        $seen,
                        $visitedForms,
                        $depth,
                        $diagnostics
                    );
                }
            }

            $operands = [];
            continue;
        }

        $operands[] = $token;
        if (count($operands) > 32) {
            array_shift($operands);
        }
    }
}

function tbpdf_collect_xobject_image(
    array &$doc,
    ?array $resources,
    string $name,
    int $pageNumber,
    array &$images,
    array &$seen,
    array &$visitedForms,
    int $depth,
    array &$diagnostics
): void {
    if ($resources === null || $depth > 8) {
        return;
    }

    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
    if ($xObjects === null || !isset($xObjects['v'][$name])) {
        return;
    }

    $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
    if (!is_array($xObject) || ($xObject['t'] ?? '') !== 'stream') {
        return;
    }

    $dict = ['t' => 'dict', 'v' => $xObject['v']];
    $subtype = tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype'));

    if ($subtype === 'Image') {
        tbpdf_register_image($images, $seen, $xObject, $name);
        return;
    }

    if ($subtype !== 'Form') {
        return;
    }

    $objectNumber = $xObject['num'] ?? null;
    if ($objectNumber !== null) {
        if (isset($visitedForms[$objectNumber])) {
            return;
        }
        $visitedForms[$objectNumber] = true;
    }
    if ($depth >= 8) {
        return;
    }

    $data = tbpdf_decode_stream($doc, $xObject);
    if ($data === null) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'form_stream_undecodable',
            'message' => 'A Form XObject on page ' . $pageNumber . ' could not be decoded.',
            'page' => $pageNumber,
        ];
        return;
    }

    $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources'))) ?? $resources;
    tbpdf_collect_images_from_content(
        $doc,
        $data,
        $formResources,
        $pageNumber,
        $images,
        $seen,
        $visitedForms,
        $depth + 1,
        $diagnostics
    );
}

function tbpdf_collect_inline_image(
    array &$doc,
    string $content,
    int &$pos,
    int $pageNumber,
    array &$images,
    array &$seen,
    array &$diagnostics
): void {
    $len = strlen($content);
    $dict = [];
    $idPos = null;
    $probe = $pos;

    while ($probe < $len) {
        $token = tbpdf_parse_value($content, $probe);
        if ($token === null) {
            break;
        }
        if (is_array($token) && ($token['t'] ?? '') === 'kw') {
            if ($token['v'] === 'ID') {
                $idPos = $probe;
                break;
            }
            continue;
        }
        if (is_array($token) && ($token['t'] ?? '') === 'name') {
            $key = (string) $token['v'];
            $dict[$key] = tbpdf_parse_value($content, $probe);
        }
    }

    if ($idPos === null) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'inline_image_invalid',
            'message' => 'An inline image on page ' . $pageNumber . ' has no ID marker.',
            'page' => $pageNumber,
        ];
        $pos = $len;
        return;
    }

    $dataStart = $idPos;
    if ($dataStart < $len && tbpdf_is_ws($content[$dataStart])) {
        $dataStart++;
    }

    if (!preg_match('/\sEI(?=[\s]|$)/', $content, $match, PREG_OFFSET_CAPTURE, $dataStart)) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'inline_image_end_missing',
            'message' => 'An inline image on page ' . $pageNumber . ' has no EI marker.',
            'page' => $pageNumber,
        ];
        $pos = $len;
        return;
    }

    $dataEnd = $match[0][1];
    $data = substr($content, $dataStart, $dataEnd - $dataStart);
    $pos = $dataEnd + strlen($match[0][0]);

    $keyMap = [
        'W' => 'Width',
        'H' => 'Height',
        'BPC' => 'BitsPerComponent',
        'CS' => 'ColorSpace',
        'F' => 'Filter',
        'DP' => 'DecodeParms',
        'IM' => 'ImageMask',
        'D' => 'Decode',
        'I' => 'Interpolate',
    ];
    $mapped = [];
    foreach ($dict as $key => $value) {
        if (isset($keyMap[$key])) {
            $mapped[$keyMap[$key]] = $value;
        }
    }

    $stream = ['t' => 'stream', 'v' => $mapped, 'raw' => $data, 'num' => null];
    tbpdf_register_image($images, $seen, $stream, 'inline');
}

function tbpdf_register_image(array &$images, array &$seen, array $stream, ?string $resource): void
{
    $objectNumber = $stream['num'] ?? null;
    $key = $objectNumber !== null
        ? 'obj:' . $objectNumber
        : 'raw:' . md5(serialize([$stream['v'] ?? [], $stream['raw'] ?? '']));

    if (isset($seen[$key])) {
        return;
    }
    $seen[$key] = true;
    $images[] = [
        'stream' => $stream,
        'resource' => $resource,
        'object' => $objectNumber,
    ];
}

function tbpdf_image_filters_and_parms(array &$doc, array $dict): array
{
    $filterValue = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Filter'));
    $parmsValue = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'DecodeParms'));

    $filters = [];
    $filterArray = tbpdf_array_values($filterValue);
    if ($filterArray !== null) {
        foreach ($filterArray as $item) {
            $name = tbpdf_name_value(tbpdf_resolve($doc, $item));
            if ($name !== null) {
                $filters[] = $name;
            }
        }
    } else {
        $name = tbpdf_name_value($filterValue);
        if ($name !== null) {
            $filters[] = $name;
        }
    }

    $parms = [];
    $parmsArray = tbpdf_array_values($parmsValue);
    if ($parmsArray !== null) {
        foreach ($parmsArray as $item) {
            $parms[] = tbpdf_resolve($doc, $item);
        }
    } else {
        $parms[] = $parmsValue;
    }

    return [$filters, $parms];
}

function tbpdf_extract_image(array &$doc, array $image, string $targetBase): array
{
    $stream = $image['stream'];
    $dict = ['t' => 'dict', 'v' => $stream['v']];
    $resource = $image['resource'] ?? null;

    $width = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'Width')) ?? 0;
    $height = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'Height')) ?? 0;
    if ($width <= 0 || $height <= 0) {
        return [
            'ok' => false,
            'code' => 'image_dimensions_missing',
            'message' => 'An image has no valid Width or Height.',
            'resource' => $resource,
        ];
    }

    [$filters, $parms] = tbpdf_image_filters_and_parms($doc, $dict);
    $data = $stream['raw'] ?? '';
    $terminal = null;

    foreach ($filters as $index => $filter) {
        $filter = (string) $filter;
        if ($filter === 'DCTDecode' || $filter === 'DCT') {
            $terminal = 'jpg';
            break;
        }
        if ($filter === 'JPXDecode') {
            $terminal = 'jp2';
            break;
        }
        if ($filter === 'CCITTFaxDecode' || $filter === 'CCF' || $filter === 'JBIG2Decode') {
            return [
                'ok' => false,
                'code' => 'unsupported_image_codec',
                'message' => 'Image codec ' . $filter . ' cannot be converted without an external library.',
                'resource' => $resource,
            ];
        }

        $decoded = tbpdf_apply_filter($doc, $data, $filter, $parms[$index] ?? null);
        if ($decoded === null) {
            return [
                'ok' => false,
                'code' => 'image_decode_failed',
                'message' => 'Image data could not be decoded by filter ' . $filter . '.',
                'resource' => $resource,
            ];
        }
        $data = $decoded;
    }

    if ($terminal === 'jpg' || $terminal === 'jp2') {
        $path = $targetBase . '.' . $terminal;
        if (!tbpdf_write_bytes($path, $data)) {
            return [
                'ok' => false,
                'code' => 'image_write_failed',
                'message' => 'The extracted image could not be written: ' . $path,
                'resource' => $resource,
            ];
        }
        return [
            'ok' => true,
            'file' => $path,
            'format' => $terminal,
            'width' => $width,
            'height' => $height,
            'alpha' => false,
            'resource' => $resource,
        ];
    }

    $bitsPerComponent = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'BitsPerComponent')) ?? 8;
    if ($bitsPerComponent < 1 || $bitsPerComponent > 16) {
        $bitsPerComponent = 8;
    }
    $imageMask = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'ImageMask'));
    if ($imageMask === true && tbpdf_dict_get($dict, 'BitsPerComponent') === null) {
        $bitsPerComponent = 1;
    }

    $colorSpace = tbpdf_image_colorspace($doc, tbpdf_dict_get($dict, 'ColorSpace'));
    if ($colorSpace['type'] === 'unsupported') {
        return [
            'ok' => false,
            'code' => 'unsupported_color_space',
            'message' => 'Color space ' . ($colorSpace['reason'] ?? 'unknown') . ' is not supported.',
            'resource' => $resource,
        ];
    }

    if ($colorSpace['type'] === 'unknown') {
        $dataLength = strlen($data);
        $components = 3;
        foreach ([1, 3, 4] as $candidate) {
            $expected = ((int) ceil($width * $candidate * $bitsPerComponent / 8)) * $height;
            if ($expected === $dataLength) {
                $components = $candidate;
                break;
            }
        }
        if ($components === 1) {
            $colorSpace = ['type' => 'gray', 'components' => 1];
        } elseif ($components === 4) {
            $colorSpace = ['type' => 'cmyk', 'components' => 4];
        } else {
            $colorSpace = ['type' => 'rgb', 'components' => 3];
        }
    }

    $maskInfo = null;
    $maskValue = tbpdf_dict_get($dict, 'SMask');
    if ($maskValue === null) {
        $candidate = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Mask'));
        if (is_array($candidate) && ($candidate['t'] ?? '') === 'stream') {
            $maskValue = $candidate;
        }
    }
    if ($maskValue !== null) {
        $maskInfo = tbpdf_decode_mask_info($doc, $maskValue);
    }

    $png = tbpdf_image_to_png(
        $doc,
        $dict,
        $data,
        $width,
        $height,
        $bitsPerComponent,
        $colorSpace,
        $maskInfo
    );
    if ($png === null) {
        return [
            'ok' => false,
            'code' => 'png_conversion_failed',
            'message' => 'Image pixels could not be converted to PNG.',
            'resource' => $resource,
        ];
    }

    $path = $targetBase . '.png';
    if (!tbpdf_write_bytes($path, $png)) {
        return [
            'ok' => false,
            'code' => 'image_write_failed',
            'message' => 'The extracted image could not be written: ' . $path,
            'resource' => $resource,
        ];
    }

    return [
        'ok' => true,
        'file' => $path,
        'format' => 'png',
        'width' => $width,
        'height' => $height,
        'alpha' => $maskInfo !== null,
        'resource' => $resource,
    ];
}

function tbpdf_decode_mask_info(array &$doc, $value): ?array
{
    $mask = tbpdf_resolve($doc, $value);
    if (!is_array($mask) || ($mask['t'] ?? '') !== 'stream') {
        return null;
    }
    $dict = ['t' => 'dict', 'v' => $mask['v']];
    $width = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'Width')) ?? 0;
    $height = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'Height')) ?? 0;
    if ($width <= 0 || $height <= 0) {
        return null;
    }
    $bitsPerComponent = tbpdf_resolve_int($doc, tbpdf_dict_get($dict, 'BitsPerComponent')) ?? 8;
    if ($bitsPerComponent < 1 || $bitsPerComponent > 16) {
        $bitsPerComponent = 8;
    }
    $imageMask = tbpdf_resolve($doc, tbpdf_dict_get($dict, 'ImageMask'));
    if ($imageMask === true && tbpdf_dict_get($dict, 'BitsPerComponent') === null) {
        $bitsPerComponent = 1;
    }

    $data = tbpdf_decode_stream($doc, $mask);
    if ($data === null) {
        return null;
    }

    $invert = false;
    $decode = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Decode')));
    if ($decode !== null && count($decode) >= 2) {
        $first = tbpdf_num(tbpdf_resolve($doc, $decode[0]));
        $second = tbpdf_num(tbpdf_resolve($doc, $decode[1]));
        if ($first !== null && $second !== null && $first > $second) {
            $invert = true;
        }
    }

    return [
        'data' => $data,
        'width' => $width,
        'height' => $height,
        'bpc' => $bitsPerComponent,
        'invert' => $invert,
    ];
}

function tbpdf_image_colorspace(array &$doc, $value): array
{
    $value = tbpdf_resolve($doc, $value);
    $name = tbpdf_name_value($value);
    if ($name !== null) {
        return tbpdf_colorspace_from_name($name);
    }

    $array = tbpdf_array_values($value);
    if ($array !== null && count($array) > 0) {
        $family = tbpdf_name_value(tbpdf_resolve($doc, $array[0]));

        if ($family === 'ICCBased') {
            // ICC profiles are streams, so tbpdf_object_dict() is required to
            // read /N. With /N 1 the space is one-component (gray): a value
            // of 1 means white, not RGB red.
            $profile = tbpdf_object_dict(tbpdf_resolve($doc, $array[1] ?? null));
            $components = $profile !== null
                ? tbpdf_resolve_int($doc, tbpdf_dict_get($profile, 'N'))
                : 3;
            if ($components === 1) {
                return ['type' => 'gray', 'components' => 1];
            }
            if ($components === 4) {
                return ['type' => 'cmyk', 'components' => 4];
            }
            if ($components === 3) {
                return ['type' => 'rgb', 'components' => 3];
            }
            return ['type' => 'unsupported', 'components' => 3, 'reason' => 'ICCBased'];
        }

        if ($family === 'Indexed') {
            $base = tbpdf_image_colorspace($doc, $array[1] ?? null);
            if ($base['type'] === 'unsupported' || $base['type'] === 'indexed') {
                return ['type' => 'unsupported', 'components' => 1, 'reason' => 'Indexed'];
            }
            $hival = tbpdf_resolve_int($doc, $array[2] ?? null) ?? 255;
            $lookupValue = tbpdf_resolve($doc, $array[3] ?? null);
            $lookup = is_array($lookupValue) && ($lookupValue['t'] ?? '') === 'str'
                ? $lookupValue['v']
                : '';
            return [
                'type' => 'indexed',
                'components' => 1,
                'base' => $base,
                'hival' => $hival,
                'lookup' => $lookup,
            ];
        }

        if ($family === 'CalRGB' || $family === 'DeviceRGB') {
            return ['type' => 'rgb', 'components' => 3];
        }
        if ($family === 'CalGray' || $family === 'DeviceGray') {
            return ['type' => 'gray', 'components' => 1];
        }
        if ($family === 'DeviceCMYK') {
            return ['type' => 'cmyk', 'components' => 4];
        }
        if ($family === 'Separation' || $family === 'DeviceN' || $family === 'Lab') {
            return ['type' => 'unsupported', 'components' => 1, 'reason' => (string) $family];
        }
    }

    return ['type' => 'unknown', 'components' => 3];
}

function tbpdf_colorspace_from_name(string $name): array
{
    switch (strtolower($name)) {
        case 'devicergb':
        case 'rgb':
            return ['type' => 'rgb', 'components' => 3];
        case 'devicegray':
        case 'calgray':
        case 'g':
            return ['type' => 'gray', 'components' => 1];
        case 'devicecmyk':
        case 'cmyk':
            return ['type' => 'cmyk', 'components' => 4];
        default:
            return ['type' => 'unknown', 'components' => 3];
    }
}

function tbpdf_palette_entry(array $colorSpace, int $index): array
{
    $base = $colorSpace['base'] ?? ['type' => 'rgb', 'components' => 3];
    $lookup = $colorSpace['lookup'] ?? '';
    $bytesPerEntry = $base['type'] === 'gray' ? 1 : ($base['type'] === 'cmyk' ? 4 : 3);
    $offset = $index * $bytesPerEntry;

    $b0 = ord($lookup[$offset] ?? "\x00");
    $b1 = ord($lookup[$offset + 1] ?? "\x00");
    $b2 = ord($lookup[$offset + 2] ?? "\x00");
    $b3 = ord($lookup[$offset + 3] ?? "\x00");

    if ($base['type'] === 'gray') {
        return [$b0, $b0, $b0];
    }
    if ($base['type'] === 'cmyk') {
        return tbpdf_cmyk_to_rgb($b0, $b1, $b2, $b3);
    }
    return [$b0, $b1, $b2];
}

function tbpdf_cmyk_to_rgb(int $c, int $m, int $y, int $k): array
{
    return [
        max(0, 255 - min(255, $c + $k)),
        max(0, 255 - min(255, $m + $k)),
        max(0, 255 - min(255, $y + $k)),
    ];
}

function tbpdf_image_to_png(
    array &$doc,
    array $dict,
    string $data,
    int $width,
    int $height,
    int $bitsPerComponent,
    array $colorSpace,
    ?array $maskInfo
): ?string {
    if (!function_exists('gzcompress')) {
        return null;
    }

    $components = (int) ($colorSpace['components'] ?? 1);
    if ($colorSpace['type'] === 'indexed') {
        $components = 1;
    }
    if ($components < 1 || $components > 4) {
        return null;
    }

    $rowBytes = (int) ceil($width * $components * $bitsPerComponent / 8);
    if ($rowBytes <= 0) {
        return null;
    }

    $decode = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Decode')));
    $decodeValues = [];
    if ($decode !== null) {
        foreach ($decode as $item) {
            $number = tbpdf_num(tbpdf_resolve($doc, $item));
            if ($number !== null) {
                $decodeValues[] = (float) $number;
            }
        }
    }

    $maxValue = $bitsPerComponent >= 16 ? 65535 : (1 << $bitsPerComponent) - 1;
    if ($maxValue < 1) {
        $maxValue = 255;
    }

    $hasAlpha = $maskInfo !== null;
    $maskRowBytes = 0;
    if ($hasAlpha) {
        $maskRowBytes = (int) ceil($maskInfo['width'] * $maskInfo['bpc'] / 8);
        if ($maskRowBytes <= 0) {
            $hasAlpha = false;
            $maskInfo = null;
        }
    }

    $raw = '';
    for ($y = 0; $y < $height; $y++) {
        $row = substr($data, $y * $rowBytes, $rowBytes);
        $samples = tbpdf_unpack_row($row, $width * $components, $bitsPerComponent);

        $maskSamples = [];
        $maskMax = 1;
        if ($hasAlpha) {
            $maskHeight = max(1, (int) $maskInfo['height']);
            $maskY = (int) floor($y * $maskHeight / $height);
            if ($maskY >= $maskHeight) {
                $maskY = $maskHeight - 1;
            }
            $maskRow = substr($maskInfo['data'], $maskY * $maskRowBytes, $maskRowBytes);
            $maskSamples = tbpdf_unpack_row($maskRow, (int) $maskInfo['width'], (int) $maskInfo['bpc']);
            $maskMax = $maskInfo['bpc'] >= 16 ? 65535 : (1 << $maskInfo['bpc']) - 1;
            if ($maskMax < 1) {
                $maskMax = 1;
            }
        }

        $line = '';
        for ($x = 0; $x < $width; $x++) {
            $offset = $x * $components;

            if ($colorSpace['type'] === 'indexed') {
                $index = $samples[$offset] ?? 0;
                $hival = max(0, (int) ($colorSpace['hival'] ?? 255));
                $index = max(0, min($hival, (int) $index));
                [$red, $green, $blue] = tbpdf_palette_entry($colorSpace, $index);
            } else {
                $values = [];
                for ($component = 0; $component < $components; $component++) {
                    $sample = $samples[$offset + $component] ?? 0;
                    $minimum = $decodeValues[$component * 2] ?? 0.0;
                    $maximum = $decodeValues[$component * 2 + 1] ?? 1.0;
                    $values[] = tbpdf_scale_sample((int) $sample, $maxValue, $minimum, $maximum);
                }

                if ($components === 1) {
                    $red = $green = $blue = $values[0];
                } elseif ($components === 3) {
                    [$red, $green, $blue] = $values;
                } else {
                    [$red, $green, $blue] = tbpdf_cmyk_to_rgb($values[0], $values[1], $values[2], $values[3]);
                }
            }

            $line .= chr($red) . chr($green) . chr($blue);

            if ($hasAlpha) {
                $maskWidth = max(1, (int) $maskInfo['width']);
                $maskX = (int) floor($x * $maskWidth / $width);
                if ($maskX >= $maskWidth) {
                    $maskX = $maskWidth - 1;
                }
                $alpha = (int) round((($maskSamples[$maskX] ?? 0) / $maskMax) * 255);
                if (!empty($maskInfo['invert'])) {
                    $alpha = 255 - $alpha;
                }
                $line .= chr(max(0, min(255, $alpha)));
            }
        }

        $raw .= "\x00" . $line;
    }

    $colorType = $hasAlpha ? 6 : 2;
    $png = "\x89PNG\r\n\x1a\n";
    $png .= tbpdf_png_chunk('IHDR', pack('NN', $width, $height) . chr(8) . chr($colorType) . chr(0) . chr(0) . chr(0));
    $png .= tbpdf_png_chunk('IDAT', gzcompress($raw, 9));
    $png .= tbpdf_png_chunk('IEND', '');
    return $png;
}

function tbpdf_unpack_row(string $row, int $count, int $bitsPerComponent): array
{
    $out = [];
    if ($bitsPerComponent === 8) {
        for ($i = 0; $i < $count; $i++) {
            $out[] = ord($row[$i] ?? "\x00");
        }
        return $out;
    }

    if ($bitsPerComponent === 16) {
        for ($i = 0; $i < $count; $i++) {
            $offset = $i * 2;
            $out[] = (ord($row[$offset] ?? "\x00") << 8) | ord($row[$offset + 1] ?? "\x00");
        }
        return $out;
    }

    if ($bitsPerComponent === 1 || $bitsPerComponent === 2 || $bitsPerComponent === 4) {
        $mask = (1 << $bitsPerComponent) - 1;
        $bit = 0;
        for ($i = 0; $i < $count; $i++) {
            $byteIndex = intdiv($bit, 8);
            $shift = 8 - $bitsPerComponent - ($bit % 8);
            $out[] = (ord($row[$byteIndex] ?? "\x00") >> $shift) & $mask;
            $bit += $bitsPerComponent;
        }
        return $out;
    }

    for ($i = 0; $i < $count; $i++) {
        $out[] = 0;
    }
    return $out;
}

function tbpdf_scale_sample(int $sample, int $maxValue, float $minimum, float $maximum): int
{
    if ($maxValue < 1) {
        return 0;
    }
    $normalized = $sample / $maxValue;
    $mapped = $minimum + $normalized * ($maximum - $minimum);
    if ($mapped < 0) {
        $mapped = 0;
    } elseif ($mapped > 1) {
        $mapped = 1;
    }
    return (int) round($mapped * 255);
}

function tbpdf_png_chunk(string $type, string $data): string
{
    return pack('N', strlen($data)) . $type . $data . pack('N', crc32($type . $data));
}

function tbpdf_write_bytes(string $path, string $bytes): bool
{
    $directory = dirname($path);
    if (!is_dir($directory) && !mkdir($directory, 0777, true) && !is_dir($directory)) {
        return false;
    }
    return @file_put_contents($path, $bytes) !== false;
}

/* -------------------------------------------------------------------------
 * Stage 2: vector and color-area recovery
 * ---------------------------------------------------------------------- */

/**
 * Rasterizes the vector content of one page into transparent PNG files.
 *
 * Best-effort renderer: solid fills, strokes, paths, curves, transforms,
 * alpha, clipping and Form XObjects are supported. Text, images, shadings,
 * patterns, dashes and blend modes are handled elsewhere or reported.
 */
function tbpdf_extract_page_vectors(
    array &$doc,
    array $pageEntry,
    int $pageNumber,
    string $pageDir,
    array $options
): array {
    $options = array_merge([
        'vector_dpi' => 96,
        'vector_max_pixels' => 4000000,
        'vector_max_objects' => 250,
        'vector_aa' => 2,
    ], $options);

    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];
    $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));
    $mediaBox = tbpdf_box($doc, tbpdf_page_attr($dict, $inherited, 'MediaBox'));
    $cropBox = tbpdf_box($doc, tbpdf_page_attr($dict, $inherited, 'CropBox')) ?? $mediaBox;

    if ($cropBox === null) {
        return ['vectors' => [], 'diagnostics' => []];
    }

    $pageBox = [
        'llx' => $cropBox['llx'],
        'lly' => $cropBox['lly'],
        'urx' => $cropBox['urx'],
        'ury' => $cropBox['ury'],
        'width' => $cropBox['width'],
        'height' => $cropBox['height'],
    ];

    $rotation = tbpdf_resolve_int($doc, tbpdf_page_attr($dict, $inherited, 'Rotate')) ?? 0;
    $rotation = (($rotation % 360) + 360) % 360;
    $options['page_rotation'] = $rotation;

    $content = tbpdf_page_content($doc, $dict);
    $diagnostics = [];
    if ($content['failed'] > 0) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'vector_content_undecodable',
            'message' => 'Page ' . $pageNumber . ' has content streams that could not be decoded; vector recovery was skipped.',
            'page' => $pageNumber,
        ];
        return ['vectors' => [], 'diagnostics' => $diagnostics];
    }
    if ($content['content'] === '') {
        return ['vectors' => [], 'diagnostics' => $diagnostics];
    }

    $vectors = [];
    $counter = ['count' => 0, 'skipped' => 0];
    $state = tbpdf_vector_state_init($resources);
    $path = tbpdf_vector_path_init();

    tbpdf_vector_scan_content(
        $doc,
        $content['content'],
        $resources,
        $pageBox,
        $state,
        $path,
        $options,
        $pageNumber,
        $pageDir,
        $vectors,
        $diagnostics,
        $counter,
        0,
        []
    );

    return ['vectors' => $vectors, 'diagnostics' => $diagnostics];
}

function tbpdf_vector_state_init(?array $resources): array
{
    return [
        'ctm' => [1.0, 0.0, 0.0, 1.0, 0.0, 0.0],
        'fill' => [0, 0, 0],
        'stroke' => [0, 0, 0],
        'fill_alpha' => 1.0,
        'stroke_alpha' => 1.0,
        'parent_fill_alpha' => 1.0,
        'parent_stroke_alpha' => 1.0,
        'line_width' => 1.0,
        'line_cap' => 0,
        'line_join' => 0,
        'miter' => 10.0,
        'dash' => null,
        'clip' => [],
        'clip_bbox' => null,
        'pending_clip' => null,
        'fill_cs' => ['type' => 'gray', 'components' => 1],
        'stroke_cs' => ['type' => 'gray', 'components' => 1],
        'fill_pattern' => false,
        'stroke_pattern' => false,
        'resources' => $resources,
    ];
}

function tbpdf_vector_path_init(): array
{
    return ['subpaths' => [], 'current' => null];
}

function tbpdf_vector_transform_point(array $state, float $x, float $y): array
{
    return tbpdf_apply_matrix($state['ctm'], $x, $y);
}

function tbpdf_vector_path_move(array &$path, array $state, float $x, float $y): void
{
    $point = tbpdf_vector_transform_point($state, $x, $y);
    $path['subpaths'][] = ['points' => [$point], 'closed' => false];
    $path['current'] = count($path['subpaths']) - 1;
}

function tbpdf_vector_path_line(array &$path, array $state, float $x, float $y): void
{
    $point = tbpdf_vector_transform_point($state, $x, $y);
    if ($path['current'] === null || !isset($path['subpaths'][$path['current']])) {
        $path['subpaths'][] = ['points' => [$point], 'closed' => false];
        $path['current'] = count($path['subpaths']) - 1;
        return;
    }
    $path['subpaths'][$path['current']]['points'][] = $point;
}

function tbpdf_vector_path_close(array &$path): void
{
    if ($path['current'] !== null && isset($path['subpaths'][$path['current']])) {
        $path['subpaths'][$path['current']]['closed'] = true;
    }
    $path['current'] = null;
}

function tbpdf_vector_path_rect(array &$path, array $state, float $x, float $y, float $w, float $h): void
{
    $corners = [
        [$x, $y],
        [$x + $w, $y],
        [$x + $w, $y + $h],
        [$x, $y + $h],
    ];
    $points = [];
    foreach ($corners as [$cx, $cy]) {
        $points[] = tbpdf_vector_transform_point($state, $cx, $cy);
    }
    $path['subpaths'][] = ['points' => $points, 'closed' => true];
    $path['current'] = null;
}

function tbpdf_vector_path_curve(
    array &$path,
    array $state,
    float $x1,
    float $y1,
    float $x2,
    float $y2,
    float $x3,
    float $y3,
    string $kind
): void {
    if ($path['current'] === null || !isset($path['subpaths'][$path['current']])) {
        $p0 = tbpdf_vector_transform_point($state, $x1, $y1);
        $path['subpaths'][] = ['points' => [$p0], 'closed' => false];
        $path['current'] = count($path['subpaths']) - 1;
    }

    $subpath = &$path['subpaths'][$path['current']];
    $points = $subpath['points'];
    $p0 = $points[count($points) - 1];
    $p1 = tbpdf_vector_transform_point($state, $x1, $y1);
    $p2 = tbpdf_vector_transform_point($state, $x2, $y2);
    $p3 = tbpdf_vector_transform_point($state, $x3, $y3);

    if ($kind === 'v') {
        $p1 = $p0;
        $p2 = tbpdf_vector_transform_point($state, $x1, $y1);
        $p3 = tbpdf_vector_transform_point($state, $x2, $y2);
    } elseif ($kind === 'y') {
        $p1 = tbpdf_vector_transform_point($state, $x1, $y1);
        $p2 = tbpdf_vector_transform_point($state, $x2, $y2);
        $p3 = $p2;
    }

    $flat = tbpdf_vector_flatten_cubic($p0, $p1, $p2, $p3);
    foreach ($flat as $point) {
        $points[] = $point;
    }
    $subpath['points'] = $points;
    unset($subpath);
}

function tbpdf_vector_flatten_cubic(array $p0, array $p1, array $p2, array $p3): array
{
    $length = tbpdf_vector_distance($p0, $p1) +
        tbpdf_vector_distance($p1, $p2) +
        tbpdf_vector_distance($p2, $p3);
    $steps = max(4, min(48, (int) ceil($length / 2)));
    $out = [];
    for ($i = 1; $i <= $steps; $i++) {
        $t = $i / $steps;
        $mt = 1 - $t;
        $x = ($mt ** 3) * $p0[0] + 3 * ($mt ** 2) * $t * $p1[0] +
            3 * $mt * ($t ** 2) * $p2[0] + ($t ** 3) * $p3[0];
        $y = ($mt ** 3) * $p0[1] + 3 * ($mt ** 2) * $t * $p1[1] +
            3 * $mt * ($t ** 2) * $p2[1] + ($t ** 3) * $p3[1];
        $out[] = [$x, $y];
    }
    return $out;
}

function tbpdf_vector_distance(array $a, array $b): float
{
    return sqrt((($a[0] - $b[0]) ** 2) + (($a[1] - $b[1]) ** 2));
}

function tbpdf_vector_scan_content(
    array &$doc,
    string $content,
    ?array $resources,
    array $pageBox,
    array $state,
    array $path,
    array $options,
    int $pageNumber,
    string $pageDir,
    array &$vectors,
    array &$diagnostics,
    array &$counter,
    int $depth,
    array $formStack
): void {
    $pos = 0;
    $len = strlen($content);
    $operands = [];
    $stateStack = [];
    $tokens = 0;

    while ($pos < $len) {
        $tokens++;
        if ($tokens > 2000000) {
            tbpdf_vector_diag($diagnostics, 'vector_token_limit', 'Vector content exceeded the token limit on page ' . $pageNumber . '.', $pageNumber);
            break;
        }

        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (!is_array($token) || ($token['t'] ?? '') !== 'kw') {
            $operands[] = $token;
            if (count($operands) > 32) {
                array_shift($operands);
            }
            continue;
        }

        $operator = (string) $token['v'];

        switch ($operator) {
            case 'BI':
                tbpdf_vector_skip_inline($content, $pos);
                $operands = [];
                continue 2;

            case 'q':
                $stateStack[] = $state;
                break;

            case 'Q':
                if (count($stateStack) > 0) {
                    $state = array_pop($stateStack);
                }
                break;

            case 'cm':
                $matrix = tbpdf_last_numbers($operands, 6);
                if ($matrix !== null) {
                    $state['ctm'] = tbpdf_matrix_mult($matrix, $state['ctm']);
                }
                break;

            case 'w':
                $values = tbpdf_last_numbers($operands, 1);
                if ($values !== null) {
                    $state['line_width'] = $values[0];
                }
                break;

            case 'J':
                $value = tbpdf_last_int($operands, 1);
                if ($value !== null) {
                    $state['line_cap'] = $value;
                }
                break;

            case 'j':
                $value = tbpdf_last_int($operands, 1);
                if ($value !== null) {
                    $state['line_join'] = $value;
                }
                break;

            case 'M':
                $values = tbpdf_last_numbers($operands, 1);
                if ($values !== null) {
                    $state['miter'] = $values[0];
                }
                break;

            case 'd':
                $dashOperand = $operands[count($operands) - 2] ?? null;
                $array = tbpdf_array_values(tbpdf_resolve($doc, $dashOperand));
                if ($array !== null) {
                    $state['dash'] = $array;
                }
                break;

            case 'gs':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    tbpdf_vector_apply_gs($doc, $state, $name, $diagnostics, $pageNumber);
                }
                break;

            case 'rg':
                $values = tbpdf_last_numbers($operands, 3);
                if ($values !== null) {
                    $state['fill'] = tbpdf_vector_rgb_bytes($values[0], $values[1], $values[2]);
                    $state['fill_cs'] = ['type' => 'rgb', 'components' => 3];
                    $state['fill_pattern'] = false;
                }
                break;

            case 'RG':
                $values = tbpdf_last_numbers($operands, 3);
                if ($values !== null) {
                    $state['stroke'] = tbpdf_vector_rgb_bytes($values[0], $values[1], $values[2]);
                    $state['stroke_cs'] = ['type' => 'rgb', 'components' => 3];
                    $state['stroke_pattern'] = false;
                }
                break;

            case 'g':
                $values = tbpdf_last_numbers($operands, 1);
                if ($values !== null) {
                    $state['fill'] = tbpdf_vector_gray_byte($values[0]);
                    $state['fill_cs'] = ['type' => 'gray', 'components' => 1];
                    $state['fill_pattern'] = false;
                }
                break;

            case 'G':
                $values = tbpdf_last_numbers($operands, 1);
                if ($values !== null) {
                    $state['stroke'] = tbpdf_vector_gray_byte($values[0]);
                    $state['stroke_cs'] = ['type' => 'gray', 'components' => 1];
                    $state['stroke_pattern'] = false;
                }
                break;

            case 'k':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    $state['fill'] = tbpdf_cmyk_to_rgb(
                        tbpdf_vector_byte($values[0]),
                        tbpdf_vector_byte($values[1]),
                        tbpdf_vector_byte($values[2]),
                        tbpdf_vector_byte($values[3])
                    );
                    $state['fill_cs'] = ['type' => 'cmyk', 'components' => 4];
                    $state['fill_pattern'] = false;
                }
                break;

            case 'K':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    $state['stroke'] = tbpdf_cmyk_to_rgb(
                        tbpdf_vector_byte($values[0]),
                        tbpdf_vector_byte($values[1]),
                        tbpdf_vector_byte($values[2]),
                        tbpdf_vector_byte($values[3])
                    );
                    $state['stroke_cs'] = ['type' => 'cmyk', 'components' => 4];
                    $state['stroke_pattern'] = false;
                }
                break;

            case 'cs':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    $state['fill_cs'] = tbpdf_vector_resolve_cs($doc, $state['resources'], $name);
                    $state['fill_pattern'] = false;
                }
                break;

            case 'CS':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    $state['stroke_cs'] = tbpdf_vector_resolve_cs($doc, $state['resources'], $name);
                    $state['stroke_pattern'] = false;
                }
                break;

            case 'sc':
            case 'scn':
                $result = tbpdf_vector_components($operands);
                if ($result['pattern']) {
                    $state['fill_pattern'] = true;
                } else {
                    $state['fill'] = tbpdf_vector_color($state['fill_cs'], $result['numbers']);
                    $state['fill_pattern'] = false;
                }
                break;

            case 'SC':
            case 'SCN':
                $result = tbpdf_vector_components($operands);
                if ($result['pattern']) {
                    $state['stroke_pattern'] = true;
                } else {
                    $state['stroke'] = tbpdf_vector_color($state['stroke_cs'], $result['numbers']);
                    $state['stroke_pattern'] = false;
                }
                break;

            case 'm':
                $values = tbpdf_last_numbers($operands, 2);
                if ($values !== null) {
                    tbpdf_vector_path_move($path, $state, $values[0], $values[1]);
                }
                break;

            case 'l':
                $values = tbpdf_last_numbers($operands, 2);
                if ($values !== null) {
                    tbpdf_vector_path_line($path, $state, $values[0], $values[1]);
                }
                break;

            case 'c':
                $values = tbpdf_last_numbers($operands, 6);
                if ($values !== null) {
                    tbpdf_vector_path_curve($path, $state, $values[0], $values[1], $values[2], $values[3], $values[4], $values[5], 'c');
                }
                break;

            case 'v':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    tbpdf_vector_path_curve($path, $state, $values[0], $values[1], $values[2], $values[3], 0.0, 0.0, 'v');
                }
                break;

            case 'y':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    tbpdf_vector_path_curve($path, $state, $values[0], $values[1], $values[2], $values[3], 0.0, 0.0, 'y');
                }
                break;

            case 're':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    tbpdf_vector_path_rect($path, $state, $values[0], $values[1], $values[2], $values[3]);
                }
                break;

            case 'h':
                tbpdf_vector_path_close($path);
                break;

            case 'W':
            case 'W*':
                if (count($path['subpaths']) > 0) {
                    $state['pending_clip'] = [
                        'subpaths' => $path['subpaths'],
                        'rule' => $operator === 'W*' ? 'evenodd' : 'nonzero',
                    ];
                }
                break;

            case 'n':
                if ($state['pending_clip'] !== null) {
                    tbpdf_vector_add_clip($state, $state['pending_clip']);
                    $state['pending_clip'] = null;
                }
                $path = tbpdf_vector_path_init();
                break;

            case 'f':
            case 'F':
            case 'f*':
            case 'S':
            case 's':
            case 'B':
            case 'B*':
            case 'b':
            case 'b*':
                $fill = in_array($operator, ['f', 'F', 'f*', 'B', 'B*', 'b', 'b*'], true);
                $stroke = in_array($operator, ['S', 's', 'B', 'B*', 'b', 'b*'], true);
                $close = in_array($operator, ['s', 'b', 'b*'], true);
                $rule = in_array($operator, ['f*', 'B*', 'b*'], true) ? 'evenodd' : 'nonzero';

                if ($close) {
                    tbpdf_vector_path_close($path);
                }
                if ($state['pending_clip'] !== null) {
                    tbpdf_vector_add_clip($state, $state['pending_clip']);
                    $state['pending_clip'] = null;
                }

                tbpdf_vector_paint(
                    $state,
                    $path,
                    $fill,
                    $stroke,
                    $rule,
                    $pageBox,
                    $options,
                    $pageNumber,
                    $pageDir,
                    $vectors,
                    $diagnostics,
                    $counter,
                    $pos
                );
                $path = tbpdf_vector_path_init();
                break;

            case 'sh':
                tbpdf_vector_diag($diagnostics, 'vector_shading_skipped', 'A gradient/shading fill on page ' . $pageNumber . ' was skipped; only solid vector fills are supported.', $pageNumber);
                break;

            case 'Do':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    tbpdf_vector_scan_xobject(
                        $doc,
                        $state,
                        $name,
                        $pageBox,
                        $options,
                        $pageNumber,
                        $pageDir,
                        $vectors,
                        $diagnostics,
                        $counter,
                        $depth,
                        $formStack
                    );
                }
                break;

            default:
                break;
        }

        $operands = [];
    }
}

function tbpdf_vector_skip_inline(string $content, int &$pos): void
{
    $id = strpos($content, 'ID', $pos);
    if ($id === false) {
        $pos = strlen($content);
        return;
    }
    if (!preg_match('/\sEI(?=[\s]|$)/', $content, $match, PREG_OFFSET_CAPTURE, $id + 2)) {
        $pos = strlen($content);
        return;
    }
    $pos = $match[0][1] + strlen($match[0][0]);
}

function tbpdf_vector_apply_gs(
    array &$doc,
    array &$state,
    string $name,
    array &$diagnostics,
    int $pageNumber
): void {
    if ($state['resources'] === null) {
        return;
    }
    $gsDictionary = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($state['resources'], 'ExtGState')));
    if ($gsDictionary === null || !isset($gsDictionary['v'][$name])) {
        return;
    }
    $gs = tbpdf_as_dict(tbpdf_resolve($doc, $gsDictionary['v'][$name]));
    if ($gs === null) {
        return;
    }

    $ca = tbpdf_resolve_num($doc, tbpdf_dict_get($gs, 'ca'));
    if ($ca !== null) {
        $state['fill_alpha'] = max(0.0, min(1.0, (float) $ca));
    }
    $ca = tbpdf_resolve_num($doc, tbpdf_dict_get($gs, 'CA'));
    if ($ca !== null) {
        $state['stroke_alpha'] = max(0.0, min(1.0, (float) $ca));
    }
    $lw = tbpdf_resolve_num($doc, tbpdf_dict_get($gs, 'LW'));
    if ($lw !== null) {
        $state['line_width'] = (float) $lw;
    }
    $lc = tbpdf_resolve_int($doc, tbpdf_dict_get($gs, 'LC'));
    if ($lc !== null) {
        $state['line_cap'] = $lc;
    }
    $lj = tbpdf_resolve_int($doc, tbpdf_dict_get($gs, 'LJ'));
    if ($lj !== null) {
        $state['line_join'] = $lj;
    }
    $dash = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($gs, 'D')));
    if ($dash !== null) {
        $state['dash'] = $dash;
    }
    if (tbpdf_dict_get($gs, 'BM') !== null) {
        $blend = tbpdf_resolve_name($doc, tbpdf_dict_get($gs, 'BM'));
        if ($blend !== null && strtolower($blend) !== 'normal') {
            tbpdf_vector_diag($diagnostics, 'vector_blend_mode_ignored', 'Blend mode "' . $blend . '" on page ' . $pageNumber . ' was ignored.', $pageNumber);
        }
    }
    if (tbpdf_dict_get($gs, 'SMask') !== null) {
        tbpdf_vector_diag($diagnostics, 'vector_soft_mask_ignored', 'A soft mask on page ' . $pageNumber . ' was ignored.', $pageNumber);
    }
}

function tbpdf_vector_resolve_cs(array &$doc, ?array $resources, string $name): array
{
    $lower = strtolower($name);
    if (in_array($lower, ['devicergb', 'devicegray', 'devicecmyk', 'calrgb', 'calgray', 'rgb', 'g', 'cmyk'], true)) {
        return tbpdf_colorspace_from_name($name);
    }
    if ($resources !== null) {
        $colorSpaces = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'ColorSpace')));
        if ($colorSpaces !== null && isset($colorSpaces['v'][$name])) {
            return tbpdf_image_colorspace($doc, $colorSpaces['v'][$name]);
        }
    }
    return ['type' => 'unknown', 'components' => 3];
}

function tbpdf_vector_components(array $operands): array
{
    $numbers = [];
    $pattern = false;
    foreach ($operands as $operand) {
        $number = tbpdf_num($operand);
        if ($number !== null) {
            $numbers[] = (float) $number;
        } elseif (tbpdf_name_value($operand) !== null) {
            $pattern = true;
        }
    }
    return ['numbers' => $numbers, 'pattern' => $pattern];
}

function tbpdf_vector_color(array $colorSpace, array $numbers): array
{
    $type = $colorSpace['type'] ?? 'gray';
    if ($type === 'indexed') {
        return tbpdf_palette_entry($colorSpace, (int) ($numbers[0] ?? 0));
    }
    if ($type === 'gray') {
        return tbpdf_vector_gray_byte($numbers[0] ?? 0.0);
    }
    if ($type === 'cmyk') {
        return tbpdf_cmyk_to_rgb(
            tbpdf_vector_byte($numbers[0] ?? 0.0),
            tbpdf_vector_byte($numbers[1] ?? 0.0),
            tbpdf_vector_byte($numbers[2] ?? 0.0),
            tbpdf_vector_byte($numbers[3] ?? 0.0)
        );
    }
    if ($type === 'rgb') {
        return tbpdf_vector_rgb_bytes(
            $numbers[0] ?? 0.0,
            $numbers[1] ?? 0.0,
            $numbers[2] ?? 0.0
        );
    }
    return [0, 0, 0];
}

function tbpdf_vector_byte(float $value): int
{
    $value = max(0.0, min(1.0, $value));
    return (int) round($value * 255);
}

function tbpdf_vector_rgb_bytes(float $red, float $green, float $blue): array
{
    return [tbpdf_vector_byte($red), tbpdf_vector_byte($green), tbpdf_vector_byte($blue)];
}

function tbpdf_vector_gray_byte(float $gray): array
{
    $value = tbpdf_vector_byte($gray);
    return [$value, $value, $value];
}

function tbpdf_vector_scan_xobject(
    array &$doc,
    array $state,
    string $name,
    array $pageBox,
    array $options,
    int $pageNumber,
    string $pageDir,
    array &$vectors,
    array &$diagnostics,
    array &$counter,
    int $depth,
    array $formStack
): void {
    if ($state['resources'] === null || $depth > 8) {
        return;
    }
    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($state['resources'], 'XObject')));
    if ($xObjects === null || !isset($xObjects['v'][$name])) {
        return;
    }

    $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
    if (!is_array($xObject) || ($xObject['t'] ?? '') !== 'stream') {
        return;
    }
    $dict = ['t' => 'dict', 'v' => $xObject['v']];
    $subtype = tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype'));

    if ($subtype === 'Image') {
        return;
    }
    if ($subtype !== 'Form') {
        return;
    }

    $objectNumber = $xObject['num'] ?? null;
    if ($objectNumber !== null && isset($formStack[$objectNumber])) {
        tbpdf_vector_diag($diagnostics, 'vector_form_cycle', 'A Form XObject cycle was found on page ' . $pageNumber . '.', $pageNumber);
        return;
    }
    if ($objectNumber !== null) {
        $formStack[$objectNumber] = true;
    }

    $formState = $state;

    // The alpha in effect when a Form XObject is painted applies to the form
    // result as a whole. Inside the form the local graphics state may reset
    // ca/CA (often to 1), so remember the parent alpha and multiply it in
    // when the form content is actually painted.
    $formState['parent_fill_alpha'] = max(0.0, min(1.0,
        (float) ($state['parent_fill_alpha'] ?? 1.0) * (float) $state['fill_alpha']
    ));
    $formState['parent_stroke_alpha'] = max(0.0, min(1.0,
        (float) ($state['parent_stroke_alpha'] ?? 1.0) * (float) $state['stroke_alpha']
    ));

    $matrix = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Matrix')));
    if ($matrix !== null && count($matrix) >= 6) {
        $numbers = [];
        $valid = true;
        foreach (array_slice($matrix, 0, 6) as $item) {
            $number = tbpdf_num(tbpdf_resolve($doc, $item));
            if ($number === null) {
                $valid = false;
                break;
            }
            $numbers[] = (float) $number;
        }
        if ($valid) {
            $formState['ctm'] = tbpdf_matrix_mult($numbers, $state['ctm']);
        }
    }

    $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources'))) ?? $state['resources'];
    $formState['resources'] = $formResources;

    $bboxValues = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'BBox')));
    if ($bboxValues !== null && count($bboxValues) >= 4) {
        $numbers = [];
        $valid = true;
        foreach (array_slice($bboxValues, 0, 4) as $item) {
            $number = tbpdf_num(tbpdf_resolve($doc, $item));
            if ($number === null) {
                $valid = false;
                break;
            }
            $numbers[] = (float) $number;
        }
        if ($valid) {
            $corners = [
                [$numbers[0], $numbers[1]],
                [$numbers[2], $numbers[1]],
                [$numbers[2], $numbers[3]],
                [$numbers[0], $numbers[3]],
            ];
            $points = [];
            foreach ($corners as [$cx, $cy]) {
                $points[] = tbpdf_apply_matrix($formState['ctm'], $cx, $cy);
            }
            tbpdf_vector_add_clip($formState, ['subpaths' => [['points' => $points, 'closed' => true]], 'rule' => 'nonzero']);
        }
    }

    $data = tbpdf_decode_stream($doc, $xObject);
    if ($data === null) {
        tbpdf_vector_diag($diagnostics, 'vector_form_undecodable', 'A Form XObject on page ' . $pageNumber . ' could not be decoded.', $pageNumber);
        return;
    }

    $emptyPath = tbpdf_vector_path_init();
    tbpdf_vector_scan_content(
        $doc,
        $data,
        $formResources,
        $pageBox,
        $formState,
        $emptyPath,
        $options,
        $pageNumber,
        $pageDir,
        $vectors,
        $diagnostics,
        $counter,
        $depth + 1,
        $formStack
    );
}

function tbpdf_vector_add_clip(array &$state, array $clip): void
{
    $bbox = tbpdf_vector_path_bbox($clip['subpaths']);
    if ($bbox === null) {
        return;
    }
    $state['clip'][] = [
        'subpaths' => $clip['subpaths'],
        'rule' => $clip['rule'],
        'bbox' => $bbox,
    ];
    if ($state['clip_bbox'] === null) {
        $state['clip_bbox'] = $bbox;
    } else {
        $state['clip_bbox'] = tbpdf_vector_intersect_boxes($state['clip_bbox'], $bbox);
    }
}

function tbpdf_vector_paint(
    array &$state,
    array $path,
    bool $fill,
    bool $stroke,
    string $rule,
    array $pageBox,
    array $options,
    int $pageNumber,
    string $pageDir,
    array &$vectors,
    array &$diagnostics,
    array &$counter,
    int $contentPos = 0
): void {
    if ($fill && $state['fill_pattern']) {
        tbpdf_vector_diag($diagnostics, 'vector_pattern_skipped', 'A pattern fill on page ' . $pageNumber . ' was skipped.', $pageNumber);
        $fill = false;
    }
    if ($stroke && $state['stroke_pattern']) {
        tbpdf_vector_diag($diagnostics, 'vector_pattern_skipped', 'A pattern stroke on page ' . $pageNumber . ' was skipped.', $pageNumber);
        $stroke = false;
    }
    if (!$fill && !$stroke) {
        return;
    }

    // Effective alpha combines the local graphics state with the alpha that
    // was in effect when an outer Form XObject was painted.
    $parentFillAlpha = max(0.0, min(1.0, (float) ($state['parent_fill_alpha'] ?? 1.0)));
    $parentStrokeAlpha = max(0.0, min(1.0, (float) ($state['parent_stroke_alpha'] ?? 1.0)));
    $effectiveFillAlpha = max(0.0, min(1.0, (float) $state['fill_alpha'])) * $parentFillAlpha;
    $effectiveStrokeAlpha = max(0.0, min(1.0, (float) $state['stroke_alpha'])) * $parentStrokeAlpha;

    if ($stroke && $state['dash'] !== null) {
        tbpdf_vector_diag($diagnostics, 'vector_dash_ignored', 'A dashed stroke on page ' . $pageNumber . ' was rendered as solid.', $pageNumber);
    }

    $subpaths = [];
    foreach ($path['subpaths'] as $subpath) {
        if (count($subpath['points']) >= 2) {
            $subpaths[] = $subpath;
        }
    }
    if (count($subpaths) === 0) {
        return;
    }

    $bbox = tbpdf_vector_path_bbox($subpaths);
    if ($bbox === null) {
        return;
    }

    if ($stroke) {
        $width = $state['line_width'] * tbpdf_matrix_scale($state['ctm']);
        $expand = max(1.0, $width * 0.5 + 1.0);
        $bbox = tbpdf_vector_expand_box($bbox, $expand);
    }

    $bbox = tbpdf_vector_intersect_boxes($bbox, $pageBox);
    if ($state['clip_bbox'] !== null) {
        $bbox = tbpdf_vector_intersect_boxes($bbox, $state['clip_bbox']);
    }
    if ($bbox['width'] <= 0.01 || $bbox['height'] <= 0.01) {
        return;
    }

    // The movie background is already white. A first, opaque, full-page
    // white fill adds no visual information and would create a large
    // unnecessary PNG on every page.
    if (
        $fill && !$stroke &&
        $counter['count'] === 0 &&
        $effectiveFillAlpha >= 0.999 &&
        tbpdf_vector_is_white($state['fill']) &&
        tbpdf_vector_covers_page($bbox, $pageBox)
    ) {
        tbpdf_vector_diag(
            $diagnostics,
            'vector_white_background_skipped',
            'A white full-page background on page ' . $pageNumber . ' was skipped because the movie background is already white.',
            $pageNumber,
            'info'
        );
        return;
    }

    // A scene keyframe has a single alpha value for the whole image. For
    // fill-only and stroke-only paints (and for matching fill/stroke alphas),
    // render the PNG fully opaque and let the scene alpha carry the
    // transparency. Mixed unequal alphas stay baked into the PNG.
    $elementAlpha = 1.0;
    $renderState = $state;
    if ($fill && !$stroke && $effectiveFillAlpha > 0.0 && $effectiveFillAlpha < 1.0) {
        $elementAlpha = $effectiveFillAlpha;
        $renderState['fill_alpha'] = 1.0;
    } elseif (!$fill && $stroke && $effectiveStrokeAlpha > 0.0 && $effectiveStrokeAlpha < 1.0) {
        $elementAlpha = $effectiveStrokeAlpha;
        $renderState['stroke_alpha'] = 1.0;
    } elseif (
        $fill && $stroke &&
        $effectiveFillAlpha > 0.0 && $effectiveFillAlpha < 1.0 &&
        abs($effectiveFillAlpha - $effectiveStrokeAlpha) < 0.0001
    ) {
        $elementAlpha = $effectiveFillAlpha;
        $renderState['fill_alpha'] = 1.0;
        $renderState['stroke_alpha'] = 1.0;
    } elseif (
        $fill && $stroke &&
        ($effectiveFillAlpha < 0.999 || $effectiveStrokeAlpha < 0.999) &&
        abs($effectiveFillAlpha - $effectiveStrokeAlpha) >= 0.0001
    ) {
        tbpdf_vector_diag(
            $diagnostics,
            'vector_mixed_alpha_baked',
            'A vector with different fill and stroke alpha on page ' . $pageNumber . ' kept its transparency in the PNG.',
            $pageNumber,
            'info'
        );
    }

    // Rotated rectangles are rendered in their local unrotated frame and the
    // angle is stored in the scene keyframe, so TilBuci applies the rotation.
    $strokeWidth = $state['line_width'] * tbpdf_matrix_scale($state['ctm']);
    $renderStateBase = $renderState;
    $renderSubpaths = $subpaths;
    $renderBbox = $bbox;
    $sceneCenter = [($bbox['llx'] + $bbox['urx']) / 2, ($bbox['lly'] + $bbox['ury']) / 2];
    $sceneWidth = $bbox['width'];
    $sceneHeight = $bbox['height'];
    $sceneRotation = 0.0;
    $rotationInfo = tbpdf_vector_rotation_info($subpaths);
    if ($rotationInfo !== null) {
        $localSubpaths = tbpdf_vector_rotation_local_path($subpaths, $rotationInfo);
        $localState = tbpdf_vector_rotation_local_state($renderStateBase, $rotationInfo);
        $localBbox = tbpdf_vector_path_bbox($localSubpaths);
        if ($localBbox !== null) {
            if ($stroke) {
                $expand = max(1.0, $strokeWidth * 0.5 + 1.0);
                $localBbox = tbpdf_vector_expand_box($localBbox, $expand);
            }
            if ($localState['clip_bbox'] !== null) {
                $localBbox = tbpdf_vector_intersect_boxes($localBbox, $localState['clip_bbox']);
            }
            if ($localBbox['width'] > 0.01 && $localBbox['height'] > 0.01) {
                $renderSubpaths = $localSubpaths;
                $renderState = $localState;
                $renderBbox = $localBbox;
                $sceneCenter = $rotationInfo['center'];
                $sceneWidth = $localBbox['width'];
                $sceneHeight = $localBbox['height'];
                $sceneRotation = $rotationInfo['rotation'];
            }
        }
    }

    $maxObjects = max(1, (int) $options['vector_max_objects']);
    if ($counter['count'] >= $maxObjects) {
        if ($counter['count'] === $maxObjects) {
            $vectors[] = [
                'ok' => false,
                'code' => 'vector_object_limit',
                'message' => 'The vector object limit for page ' . $pageNumber . ' was reached.',
                'page' => $pageNumber,
                'bbox' => $bbox,
            ];
        }
        $counter['count']++;
        return;
    }

    if (!empty($options['vector_dry_run'])) {
        $counter['count']++;
        $index = $counter['count'];
        $scale = max(36, (int) ($options['vector_dpi'] ?? 96)) / 72;
        $vectors[] = [
            'ok' => true,
            'kind' => 'vector',
            'file' => $pageDir . DIRECTORY_SEPARATOR . 'vector-' . str_pad((string) $index, 2, '0', STR_PAD_LEFT) . '.png',
            'format' => 'png',
            'page' => $pageNumber,
            'order' => $index,
            'bbox' => [
                'llx' => round($bbox['llx'], 2),
                'lly' => round($bbox['lly'], 2),
                'urx' => round($bbox['urx'], 2),
                'ury' => round($bbox['ury'], 2),
            ],
            'width' => max(1, (int) ceil($sceneWidth * $scale)),
            'height' => max(1, (int) ceil($sceneHeight * $scale)),
            'scale' => round($scale, 4),
            'fill' => $fill,
            'stroke' => $stroke,
            'fill_rule' => $rule,
            'page_rotation' => (int) ($options['page_rotation'] ?? 0),
            'fill_color' => $fill ? tbpdf_vector_color_hex($state['fill']) : null,
            'stroke_color' => $stroke ? tbpdf_vector_color_hex($state['stroke']) : null,
            'alpha' => round($elementAlpha, 4),
            'center' => [round($sceneCenter[0], 2), round($sceneCenter[1], 2)],
            'local_width' => round($sceneWidth, 2),
            'local_height' => round($sceneHeight, 2),
            'rotation' => round($sceneRotation, 2),
            'content_pos' => $contentPos,
        ];
        return;
    }

    $render = tbpdf_vector_render($renderSubpaths, $renderState, $renderBbox, $fill, $stroke, $rule, $options);
    if ($render === null) {
        return;
    }

    $counter['count']++;
    $index = $counter['count'];
    $file = $pageDir . DIRECTORY_SEPARATOR . 'vector-' . str_pad((string) $index, 2, '0', STR_PAD_LEFT) . '.png';

    if (!tbpdf_write_png_rgba($file, $render['width'], $render['height'], $render['pixels'])) {
        $vectors[] = [
            'ok' => false,
            'code' => 'vector_write_failed',
            'message' => 'The vector image could not be written: ' . $file,
            'page' => $pageNumber,
            'bbox' => $bbox,
        ];
        $counter['skipped']++;
        return;
    }

    $vectors[] = [
        'ok' => true,
        'kind' => 'vector',
        'file' => $file,
        'format' => 'png',
        'page' => $pageNumber,
        'order' => $index,
        'bbox' => [
            'llx' => round($bbox['llx'], 2),
            'lly' => round($bbox['lly'], 2),
            'urx' => round($bbox['urx'], 2),
            'ury' => round($bbox['ury'], 2),
        ],
        'width' => $render['width'],
        'height' => $render['height'],
        'scale' => round($render['scale'], 4),
        'samples' => $render['samples'],
        'fill' => $fill,
        'stroke' => $stroke,
        'fill_rule' => $rule,
        'page_rotation' => (int) ($options['page_rotation'] ?? 0),
        'fill_color' => $fill ? tbpdf_vector_color_hex($state['fill']) : null,
        'stroke_color' => $stroke ? tbpdf_vector_color_hex($state['stroke']) : null,
        'alpha' => round($elementAlpha, 4),
        'center' => [round($sceneCenter[0], 2), round($sceneCenter[1], 2)],
        'local_width' => round($sceneWidth, 2),
        'local_height' => round($sceneHeight, 2),
        'rotation' => round($sceneRotation, 2),
        'content_pos' => $contentPos,
    ];
}

function tbpdf_vector_render(
    array $subpaths,
    array $state,
    array $bbox,
    bool $fill,
    bool $stroke,
    string $rule,
    array $options
): ?array {
    $dpi = max(36, (int) ($options['vector_dpi'] ?? 96));
    $scale = $dpi / 72;
    $width = max(1, (int) ceil($bbox['width'] * $scale));
    $height = max(1, (int) ceil($bbox['height'] * $scale));
    $maxPixels = max(10000, (int) ($options['vector_max_pixels'] ?? 4000000));

    if ($width * $height > $maxPixels) {
        $factor = sqrt($maxPixels / ($width * $height));
        $scale *= $factor;
        $width = max(1, (int) ceil($bbox['width'] * $scale));
        $height = max(1, (int) ceil($bbox['height'] * $scale));
    }
    if ($width > 4096 || $height > 4096) {
        $factor = min(4096 / $width, 4096 / $height);
        $scale *= $factor;
        $width = max(1, (int) ceil($bbox['width'] * $scale));
        $height = max(1, (int) ceil($bbox['height'] * $scale));
    }

    $samples = max(1, (int) ($options['vector_aa'] ?? 2));
    if ($width * $height > 1000000) {
        $samples = 1;
    }
    $sampleCount = $samples * $samples;

    $fillColor = $state['fill'];
    $strokeColor = $state['stroke'];
    $fillAlpha = $fill ? max(0.0, min(1.0, (float) $state['fill_alpha'])) : 0.0;
    $strokeAlpha = $stroke ? max(0.0, min(1.0, (float) $state['stroke_alpha'])) : 0.0;
    $strokeWidth = $state['line_width'] * tbpdf_matrix_scale($state['ctm']);
    if ($stroke && $strokeWidth <= 0.0) {
        $strokeWidth = 1.0 / max(0.0001, $scale);
    }
    $lineCap = (int) $state['line_cap'];

    $clips = $state['clip'];
    $rect = null;
    if ($fill && !$stroke && count($clips) === 0) {
        $rect = tbpdf_vector_axis_aligned_rect($subpaths);
    }
    if ($rect !== null) {
        $alpha = (int) round($fillAlpha * 255);
        if ($alpha <= 0) {
            return null;
        }
        $pixel = chr($fillColor[0]) . chr($fillColor[1]) . chr($fillColor[2]) . chr($alpha);
        return [
            'pixels' => str_repeat($pixel, $width * $height),
            'width' => $width,
            'height' => $height,
            'scale' => $scale,
            'samples' => 1,
        ];
    }

    $pixels = '';
    $hasVisible = false;

    for ($row = 0; $row < $height; $row++) {
        $line = '';
        for ($col = 0; $col < $width; $col++) {
            $fillCount = 0;
            $strokeCount = 0;

            for ($sy = 0; $sy < $samples; $sy++) {
                $y = $bbox['ury'] - (($row + (($sy + 0.5) / $samples)) / $scale);
                for ($sx = 0; $sx < $samples; $sx++) {
                    $x = $bbox['llx'] + (($col + (($sx + 0.5) / $samples)) / $scale);
                    if (!tbpdf_vector_point_in_clips($x, $y, $clips)) {
                        continue;
                    }
                    if ($fill && tbpdf_point_in_path($x, $y, $subpaths, $rule)) {
                        $fillCount++;
                    }
                    if ($stroke && tbpdf_point_in_stroke($x, $y, $subpaths, $strokeWidth, $lineCap)) {
                        $strokeCount++;
                    }
                }
            }

            $fa = $fillAlpha * ($fillCount / $sampleCount);
            $sa = $strokeAlpha * ($strokeCount / $sampleCount);
            $alpha = $fa + $sa * (1 - $fa);
            if ($alpha <= 0.0001) {
                $line .= "\x00\x00\x00\x00";
                continue;
            }

            $red = (($fillColor[0] * $fa) + ($strokeColor[0] * $sa * (1 - $fa))) / $alpha;
            $green = (($fillColor[1] * $fa) + ($strokeColor[1] * $sa * (1 - $fa))) / $alpha;
            $blue = (($fillColor[2] * $fa) + ($strokeColor[2] * $sa * (1 - $fa))) / $alpha;

            $line .= chr(max(0, min(255, (int) round($red)))) .
                chr(max(0, min(255, (int) round($green)))) .
                chr(max(0, min(255, (int) round($blue)))) .
                chr(max(0, min(255, (int) round($alpha * 255))));
            $hasVisible = true;
        }
        $pixels .= $line;
    }

    if (!$hasVisible) {
        return null;
    }

    return [
        'pixels' => $pixels,
        'width' => $width,
        'height' => $height,
        'scale' => $scale,
        'samples' => $samples,
    ];
}

function tbpdf_point_in_path(float $x, float $y, array $subpaths, string $rule): bool
{
    if ($rule === 'nonzero') {
        $winding = 0;
        foreach ($subpaths as $subpath) {
            $points = $subpath['points'];
            $count = count($points);
            if ($count < 2) {
                continue;
            }
            for ($i = 0; $i < $count; $i++) {
                $j = ($i + 1) % $count;
                $x1 = $points[$i][0];
                $y1 = $points[$i][1];
                $x2 = $points[$j][0];
                $y2 = $points[$j][1];
                if ($y1 <= $y) {
                    if ($y2 > $y && (($x2 - $x1) * ($y - $y1) - ($x - $x1) * ($y2 - $y1)) > 0) {
                        $winding++;
                    }
                } else {
                    if ($y2 <= $y && (($x2 - $x1) * ($y - $y1) - ($x - $x1) * ($y2 - $y1)) < 0) {
                        $winding--;
                    }
                }
            }
        }
        return $winding !== 0;
    }

    $inside = false;
    foreach ($subpaths as $subpath) {
        $points = $subpath['points'];
        $count = count($points);
        if ($count < 2) {
            continue;
        }
        for ($i = 0; $i < $count; $i++) {
            $j = ($i + 1) % $count;
            $x1 = $points[$i][0];
            $y1 = $points[$i][1];
            $x2 = $points[$j][0];
            $y2 = $points[$j][1];
            if ((($y1 <= $y) && ($y2 > $y)) || (($y2 <= $y) && ($y1 > $y))) {
                $intersection = $x1 + (($y - $y1) * ($x2 - $x1) / ($y2 - $y1));
                if ($x < $intersection) {
                    $inside = !$inside;
                }
            }
        }
    }
    return $inside;
}

function tbpdf_point_in_stroke(float $x, float $y, array $subpaths, float $width, int $lineCap): bool
{
    $half = $width / 2;
    $halfSquared = $half * $half;

    foreach ($subpaths as $subpath) {
        $points = $subpath['points'];
        $count = count($points);
        if ($count < 2) {
            continue;
        }

        for ($i = 0; $i < $count - 1; $i++) {
            if (tbpdf_point_segment_distance_squared($x, $y, $points[$i], $points[$i + 1]) <= $halfSquared) {
                return true;
            }
        }
        if (!empty($subpath['closed'])) {
            if (tbpdf_point_segment_distance_squared($x, $y, $points[$count - 1], $points[0]) <= $halfSquared) {
                return true;
            }
        } elseif ($lineCap === 1) {
            if (tbpdf_point_segment_distance_squared($x, $y, $points[0], $points[0]) <= $halfSquared ||
                tbpdf_point_segment_distance_squared($x, $y, $points[$count - 1], $points[$count - 1]) <= $halfSquared) {
                return true;
            }
        }

        $lastVertex = !empty($subpath['closed']) ? $count - 1 : $count - 2;
        for ($i = 1; $i <= $lastVertex; $i++) {
            if (tbpdf_point_segment_distance_squared($x, $y, $points[$i], $points[$i]) <= $halfSquared) {
                return true;
            }
        }
    }

    return false;
}

function tbpdf_point_segment_distance_squared(float $px, float $py, array $a, array $b): float
{
    $dx = $b[0] - $a[0];
    $dy = $b[1] - $a[1];
    if ($dx === 0.0 && $dy === 0.0) {
        return (($px - $a[0]) ** 2) + (($py - $a[1]) ** 2);
    }
    $t = (($px - $a[0]) * $dx + ($py - $a[1]) * $dy) / ($dx * $dx + $dy * $dy);
    $t = max(0.0, min(1.0, $t));
    $qx = $a[0] + $t * $dx;
    $qy = $a[1] + $t * $dy;
    return (($px - $qx) ** 2) + (($py - $qy) ** 2);
}

function tbpdf_vector_point_in_clips(float $x, float $y, array $clips): bool
{
    foreach ($clips as $clip) {
        if (!tbpdf_point_in_path($x, $y, $clip['subpaths'], $clip['rule'])) {
            return false;
        }
    }
    return true;
}

function tbpdf_vector_path_bbox(array $subpaths): ?array
{
    $minX = INF;
    $minY = INF;
    $maxX = -INF;
    $maxY = -INF;
    $found = false;

    foreach ($subpaths as $subpath) {
        foreach ($subpath['points'] as $point) {
            $found = true;
            $minX = min($minX, $point[0]);
            $minY = min($minY, $point[1]);
            $maxX = max($maxX, $point[0]);
            $maxY = max($maxY, $point[1]);
        }
    }

    if (!$found) {
        return null;
    }

    return [
        'llx' => $minX,
        'lly' => $minY,
        'urx' => $maxX,
        'ury' => $maxY,
        'width' => $maxX - $minX,
        'height' => $maxY - $minY,
    ];
}

/**
 * Detects a rotated rectangle from a single closed four-sided subpath.
 *
 * Returns the local axes (PDF space), the unrotated size, the page-space
 * center and the clockwise screen rotation in degrees. Axis-aligned
 * rectangles return null, since no rotation needs to be recorded.
 */
function tbpdf_vector_rotation_info(array $subpaths): ?array
{
    if (count($subpaths) !== 1) {
        return null;
    }
    $subpath = $subpaths[0];
    $points = $subpath['points'] ?? [];
    if (empty($subpath['closed']) || count($points) < 4) {
        return null;
    }
    if (count($points) === 5) {
        $first = $points[0];
        $last = $points[4];
        if (abs($first[0] - $last[0]) < 0.01 && abs($first[1] - $last[1]) < 0.01) {
            array_pop($points);
        }
    }
    if (count($points) !== 4) {
        return null;
    }

    $edges = [];
    for ($i = 0; $i < 4; $i++) {
        $j = ($i + 1) % 4;
        $dx = $points[$j][0] - $points[$i][0];
        $dy = $points[$j][1] - $points[$i][1];
        $length = sqrt($dx * $dx + $dy * $dy);
        if ($length < 0.01) {
            return null;
        }
        $edges[] = [
            'dx' => $dx,
            'dy' => $dy,
            'length' => $length,
            'angle' => atan2($dy, $dx),
        ];
    }

    // Opposite edges must be parallel, equal and point in opposite directions.
    for ($i = 0; $i < 2; $i++) {
        $a = $edges[$i];
        $b = $edges[$i + 2];
        if (abs($a['length'] - $b['length']) > max(0.75, $a['length'] * 0.03)) {
            return null;
        }
        $cross = $a['dx'] * $b['dy'] - $a['dy'] * $b['dx'];
        if (abs($cross) > $a['length'] * $b['length'] * 0.03) {
            return null;
        }
        if (($a['dx'] * $b['dx'] + $a['dy'] * $b['dy']) > 0) {
            return null;
        }
    }
    // Adjacent edges must be perpendicular.
    for ($i = 0; $i < 4; $i++) {
        $a = $edges[$i];
        $b = $edges[($i + 1) % 4];
        $dot = abs($a['dx'] * $b['dx'] + $a['dy'] * $b['dy']);
        if ($dot > $a['length'] * $b['length'] * 0.05) {
            return null;
        }
    }

    // Pick the edge closest to horizontal as the local x axis.
    $bestAngle = null;
    foreach ($edges as $edge) {
        $angle = $edge['angle'];
        while ($angle >= M_PI / 2) {
            $angle -= M_PI;
        }
        while ($angle < -M_PI / 2) {
            $angle += M_PI;
        }
        if ($bestAngle === null || abs($angle) < abs($bestAngle)) {
            $bestAngle = $angle;
        }
    }
    if ($bestAngle === null) {
        return null;
    }
    $degrees = rad2deg($bestAngle);
    if (abs($degrees) < 0.75) {
        return null;
    }

    $cos = cos($bestAngle);
    $sin = sin($bestAngle);
    $e1 = [$cos, $sin];
    // Local y points down on screen (PDF y is inverted), so the rendered PNG
    // has the same orientation as a TilBuci image.
    $e2 = [$sin, -$cos];

    $minU = INF;
    $maxU = -INF;
    $minV = INF;
    $maxV = -INF;
    foreach ($points as $point) {
        $u = $point[0] * $e1[0] + $point[1] * $e1[1];
        $v = $point[0] * $e2[0] + $point[1] * $e2[1];
        $minU = min($minU, $u);
        $maxU = max($maxU, $u);
        $minV = min($minV, $v);
        $maxV = max($maxV, $v);
    }
    $width = $maxU - $minU;
    $height = $maxV - $minV;
    if ($width < 0.5 || $height < 0.5) {
        return null;
    }

    $centerU = ($minU + $maxU) / 2;
    $centerV = ($minV + $maxV) / 2;
    $centerX = $centerU * $e1[0] + $centerV * $e2[0];
    $centerY = $centerU * $e1[1] + $centerV * $e2[1];

    $rotation = fmod(-$degrees, 360.0);
    if ($rotation < 0) {
        $rotation += 360.0;
    }

    return [
        'e1' => $e1,
        'e2' => $e2,
        'min_u' => $minU,
        'min_v' => $minV,
        'width' => $width,
        'height' => $height,
        'center' => [$centerX, $centerY],
        'rotation' => $rotation,
    ];
}

/**
 * Maps page-space subpaths into the unrotated local box of a detected
 * rotated rectangle. The resulting coordinates are 0..width, 0..height,
 * with y up, ready for the PNG renderer.
 */
function tbpdf_vector_rotation_local_path(array $subpaths, array $info): array
{
    $local = [];
    foreach ($subpaths as $subpath) {
        $points = [];
        foreach ($subpath['points'] as $point) {
            $u = $point[0] * $info['e1'][0] + $point[1] * $info['e1'][1];
            $v = $point[0] * $info['e2'][0] + $point[1] * $info['e2'][1];
            $points[] = [
                $u - $info['min_u'],
                $info['height'] - ($v - $info['min_v']),
            ];
        }
        $local[] = ['points' => $points, 'closed' => $subpath['closed'] ?? false];
    }
    return $local;
}

/**
 * Transforms clipping paths into the same unrotated local space.
 */
function tbpdf_vector_rotation_local_state(array $state, array $info): array
{
    $localPoint = static function (array $point) use ($info): array {
        $u = $point[0] * $info['e1'][0] + $point[1] * $info['e1'][1];
        $v = $point[0] * $info['e2'][0] + $point[1] * $info['e2'][1];
        return [$u - $info['min_u'], $info['height'] - ($v - $info['min_v'])];
    };

    $clips = [];
    foreach (($state['clip'] ?? []) as $clip) {
        $clipSubpaths = [];
        foreach (($clip['subpaths'] ?? []) as $subpath) {
            $points = [];
            foreach (($subpath['points'] ?? []) as $point) {
                $points[] = $localPoint($point);
            }
            if (count($points) >= 2) {
                $clipSubpaths[] = ['points' => $points, 'closed' => $subpath['closed'] ?? false];
            }
        }
        if (count($clipSubpaths) === 0) {
            continue;
        }
        $clipBbox = tbpdf_vector_path_bbox($clipSubpaths);
        if ($clipBbox === null) {
            continue;
        }
        $clips[] = [
            'subpaths' => $clipSubpaths,
            'rule' => $clip['rule'] ?? 'nonzero',
            'bbox' => $clipBbox,
        ];
    }

    $state['clip'] = $clips;
    $state['clip_bbox'] = null;
    foreach ($clips as $clip) {
        $state['clip_bbox'] = $state['clip_bbox'] === null
            ? $clip['bbox']
            : tbpdf_vector_intersect_boxes($state['clip_bbox'], $clip['bbox']);
    }
    $state['pending_clip'] = null;
    return $state;
}

function tbpdf_vector_expand_box(array $box, float $amount): array
{
    return [
        'llx' => $box['llx'] - $amount,
        'lly' => $box['lly'] - $amount,
        'urx' => $box['urx'] + $amount,
        'ury' => $box['ury'] + $amount,
        'width' => $box['width'] + 2 * $amount,
        'height' => $box['height'] + 2 * $amount,
    ];
}

function tbpdf_vector_intersect_boxes(array $a, array $b): array
{
    $llx = max($a['llx'], $b['llx']);
    $lly = max($a['lly'], $b['lly']);
    $urx = min($a['urx'], $b['urx']);
    $ury = min($a['ury'], $b['ury']);
    return [
        'llx' => $llx,
        'lly' => $lly,
        'urx' => $urx,
        'ury' => $ury,
        'width' => max(0.0, $urx - $llx),
        'height' => max(0.0, $ury - $lly),
    ];
}

function tbpdf_vector_axis_aligned_rect(array $subpaths): ?array
{
    if (count($subpaths) !== 1) {
        return null;
    }
    $points = $subpaths[0]['points'];
    if (count($points) !== 4) {
        return null;
    }
    $xs = [];
    $ys = [];
    foreach ($points as $point) {
        $xs[] = $point[0];
        $ys[] = $point[1];
    }
    $x0 = min($xs);
    $x1 = max($xs);
    $y0 = min($ys);
    $y1 = max($ys);
    if (($x1 - $x0) <= 0.01 || ($y1 - $y0) <= 0.01) {
        return null;
    }
    $corners = [];
    foreach ($points as $point) {
        $key = ($point[0] === $x0 ? 'l' : 'r') . ($point[1] === $y0 ? 'b' : 't');
        $corners[$key] = true;
    }
    if (count($corners) !== 4) {
        return null;
    }
    return [
        'llx' => $x0,
        'lly' => $y0,
        'urx' => $x1,
        'ury' => $y1,
        'width' => $x1 - $x0,
        'height' => $y1 - $y0,
    ];
}

function tbpdf_vector_color_hex(array $color): string
{
    return sprintf('0x%02X%02X%02X', $color[0], $color[1], $color[2]);
}

function tbpdf_vector_is_white(array $color): bool
{
    return $color[0] >= 250 && $color[1] >= 250 && $color[2] >= 250;
}

function tbpdf_vector_covers_page(array $bbox, array $pageBox): bool
{
    $tolerance = max(1.0, 0.001 * max($pageBox['width'], $pageBox['height']));
    return $bbox['llx'] <= $pageBox['llx'] + $tolerance
        && $bbox['lly'] <= $pageBox['lly'] + $tolerance
        && $bbox['urx'] >= $pageBox['urx'] - $tolerance
        && $bbox['ury'] >= $pageBox['ury'] - $tolerance;
}

function tbpdf_matrix_scale(array $matrix): float
{
    $sx = sqrt($matrix[0] * $matrix[0] + $matrix[1] * $matrix[1]);
    $sy = sqrt($matrix[2] * $matrix[2] + $matrix[3] * $matrix[3]);
    return max(0.0001, $sx, $sy);
}

function tbpdf_vector_diag(
    array &$diagnostics,
    string $code,
    string $message,
    int $pageNumber,
    string $level = 'warning'
): void {
    foreach ($diagnostics as $diagnostic) {
        if (($diagnostic['code'] ?? '') === $code && ($diagnostic['page'] ?? null) === $pageNumber) {
            return;
        }
    }
    $diagnostics[] = [
        'level' => $level,
        'code' => $code,
        'message' => $message,
        'page' => $pageNumber,
    ];
}

function tbpdf_write_png_rgba(string $path, int $width, int $height, string $pixels): bool
{
    if (!function_exists('gzcompress') || $width <= 0 || $height <= 0) {
        return false;
    }
    $stride = $width * 4;
    if (strlen($pixels) < $stride * $height) {
        return false;
    }

    $raw = '';
    for ($row = 0; $row < $height; $row++) {
        $raw .= "\x00" . substr($pixels, $row * $stride, $stride);
    }

    $png = "\x89PNG\r\n\x1a\n";
    $png .= tbpdf_png_chunk('IHDR', pack('NN', $width, $height) . chr(8) . chr(6) . chr(0) . chr(0) . chr(0));
    $png .= tbpdf_png_chunk('IDAT', gzcompress($raw, 9));
    $png .= tbpdf_png_chunk('IEND', '');
    return tbpdf_write_bytes($path, $png);
}

/* -------------------------------------------------------------------------
 * Stage 3: movie.json creation
 * ---------------------------------------------------------------------- */

/**
 * Creates "[ID].movie/movie.json" from movie-base.json.
 *
 * The definitive stage 1 JSON supplies the title and page dimensions.
 * Only [ID], [TITLE], [BIG], [SMALL], [TYPE] and [CREATED] are replaced.
 * Markers intended for later stages, such as [AUTHOR], [STARTSCENE] and
 * [UPDATED], are preserved and reported in "unresolved_markers".
 */
function tbpdf_create_movie(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null
): array {
    $result = [
        'movie' => null,
        'movie_json' => null,
        'id' => $movieId,
        'title' => null,
        'screen' => null,
        'created' => null,
        'replacements' => [],
        'unresolved_markers' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_movie_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }

    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_movie_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }

    $width = isset($data['width']) && is_numeric($data['width']) ? (int) $data['width'] : 0;
    $height = isset($data['height']) && is_numeric($data['height']) ? (int) $data['height'] : 0;
    if ($width <= 0 || $height <= 0) {
        return tbpdf_movie_fail($result, 'invalid_dimensions', 'The analysis JSON must contain positive width and height values.');
    }

    $title = $data['title'] ?? $movieId;
    if (!is_string($title) || trim($title) === '') {
        $title = $movieId;
    }
    $title = trim($title);

    if ($baseDir === null) {
        $file = $data['file'] ?? null;
        if (!is_string($file) || $file === '' || !is_file($file)) {
            return tbpdf_movie_fail($result, 'base_dir_missing', 'The base directory could not be derived from the analysis JSON; provide it explicitly.');
        }
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_movie_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_movie_fail($result, 'movie_folder_missing', 'The movie folder does not exist; run media extraction first.');
    }
    if (!is_writable($moviePath)) {
        return tbpdf_movie_fail($result, 'movie_folder_not_writable', 'The movie folder is not writable.');
    }
    $result['movie'] = $moviePath;

    $templatePath = $templatePath ?? __DIR__ . DIRECTORY_SEPARATOR . 'movie-base.json';
    if (!is_string($templatePath) || $templatePath === '' || !is_file($templatePath) || !is_readable($templatePath)) {
        return tbpdf_movie_fail($result, 'template_missing', 'The movie-base.json template was not found or is not readable.');
    }

    $templateText = @file_get_contents($templatePath);
    if ($templateText === false) {
        return tbpdf_movie_fail($result, 'template_read_failed', 'The movie-base.json template could not be read.');
    }

    // The template uses unquoted placeholders. Give them temporary values so
    // the template can be decoded as JSON first. [FONTS] expands to the font
    // descriptor list in stage 7, so it starts as an empty array here.
    $templateText = str_replace(
        ['[BIG]', '[SMALL]', '"[BIG]"', '"[SMALL]"', '[[FONTS]]', '"[FONTS]"'],
        ['0', '0', '0', '0', '[]', '""'],
        $templateText
    );
    $movie = json_decode($templateText, true);
    if (!is_array($movie)) {
        return tbpdf_movie_fail($result, 'template_invalid', 'The movie-base.json template is not valid JSON: ' . json_last_error_msg());
    }

    // Font descriptors are written by stage 7; stage 3 always starts empty.
    $movie['fonts'] = [];

    $type = $height > $width ? 'portrait' : 'landscape';
    $big = max($width, $height);
    $small = min($width, $height);
    $created = date('Y-m-d H:i:s');

    $replacements = [
        '[ID]' => $movieId,
        '[TITLE]' => $title,
        '[BIG]' => (string) $big,
        '[SMALL]' => (string) $small,
        '[TYPE]' => $type,
        '[CREATED]' => $created,
    ];

    $movie = tbpdf_replace_markers($movie, $replacements);

    if (!isset($movie['screen']) || !is_array($movie['screen'])) {
        $movie['screen'] = [];
    }
    $movie['screen']['big'] = $big;
    $movie['screen']['small'] = $small;
    $movie['screen']['type'] = $type;
    if (!isset($movie['screen']['bgcolor'])) {
        $movie['screen']['bgcolor'] = '0xffffff';
    }

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($movie, $flags);
    if ($json === false) {
        return tbpdf_movie_fail($result, 'json_encode_failed', 'The movie.json structure could not be encoded: ' . json_last_error_msg());
    }
    $json .= PHP_EOL;

    $movieJsonPath = $moviePath . DIRECTORY_SEPARATOR . 'movie.json';
    if (is_file($movieJsonPath)) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'movie_json_overwritten',
            'message' => 'An existing movie.json was overwritten.',
            'page' => null,
        ];
    }
    if (!tbpdf_write_bytes($movieJsonPath, $json)) {
        return tbpdf_movie_fail($result, 'movie_json_write_failed', 'movie.json could not be written: ' . $movieJsonPath);
    }

    $unresolved = [];
    if (preg_match_all('/\[[A-Z0-9_]+\]/', $json, $matches)) {
        $unresolved = array_values(array_unique($matches[0]));
    }

    $result['movie_json'] = $movieJsonPath;
    $result['title'] = $title;
    $result['screen'] = ['big' => $big, 'small' => $small, 'type' => $type];
    $result['created'] = $created;
    $result['replacements'] = $replacements;
    $result['unresolved_markers'] = $unresolved;
    return $result;
}

/**
 * Convenience wrapper that returns the stage 3 result as JSON.
 */
function tbpdf_create_movie_to_json(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null
): string {
    return tbpdf_json_encode(tbpdf_create_movie($analysisJson, $movieId, $baseDir, $templatePath));
}

function tbpdf_movie_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

function tbpdf_replace_markers($value, array $replacements)
{
    if (is_string($value)) {
        return strtr($value, $replacements);
    }
    if (is_array($value)) {
        foreach ($value as $key => $item) {
            $value[$key] = tbpdf_replace_markers($item, $replacements);
        }
    }
    return $value;
}

/**
 * Applies caller-supplied metadata to an existing movie.json.
 *
 * This helper is used after tbpdf_create_movie() when the movie settings
 * (author and scene transition time) come from the application rather than
 * from the PDF. The [AUTHOR] marker is resolved and the "author" and "time"
 * fields are written back to movie.json.
 *
 * @param string      $movieId  the movie ID
 * @param string|null $baseDir  directory containing "[ID].movie"
 * @param string|null $author   movie author name
 * @param mixed       $interval scene transition time, in seconds
 * @param string|null $user     fallback author when $author is empty
 * @return array
 */
function tbpdf_apply_movie_metadata(
    string $movieId,
    ?string $baseDir,
    ?string $author,
    $interval,
    ?string $user = null
): array {
    $result = [
        'movie' => null,
        'movie_json' => null,
        'author' => null,
        'time' => null,
        'diagnostics' => [],
    ];

    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_movie_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }

    if ($baseDir === null || trim($baseDir) === '') {
        return tbpdf_movie_fail($result, 'base_dir_missing', 'The output base directory is required.');
    }
    $baseDir = rtrim($baseDir, '/\\');
    if (!is_dir($baseDir)) {
        return tbpdf_movie_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_movie_fail($result, 'movie_folder_missing', 'The movie folder does not exist; run movie creation first.');
    }
    $result['movie'] = $moviePath;

    $movieJsonPath = $moviePath . DIRECTORY_SEPARATOR . 'movie.json';
    if (!is_file($movieJsonPath) || !is_readable($movieJsonPath)) {
        return tbpdf_movie_fail($result, 'movie_json_missing', 'movie.json was not found; run movie creation first.');
    }
    $movie = json_decode((string) @file_get_contents($movieJsonPath), true);
    if (!is_array($movie)) {
        return tbpdf_movie_fail($result, 'movie_json_invalid', 'movie.json is not valid JSON.');
    }
    $result['movie_json'] = $movieJsonPath;

    $author = is_string($author) ? trim($author) : '';
    if ($author === '') {
        $author = is_string($user) ? trim($user) : '';
    }
    $interval = is_numeric($interval) ? (float) $interval : 0.0;
    if ($interval < 0) {
        $interval = 0.0;
    }

    $movie = tbpdf_replace_markers($movie, ['[AUTHOR]' => $author]);
    $movie['author'] = $author;
    $movie['time'] = $interval;

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($movie, $flags);
    if ($json === false) {
        return tbpdf_movie_fail($result, 'json_encode_failed', 'movie.json could not be encoded: ' . json_last_error_msg());
    }
    $json .= PHP_EOL;
    if (!tbpdf_write_bytes($movieJsonPath, $json)) {
        return tbpdf_movie_fail($result, 'movie_json_write_failed', 'movie.json could not be written.');
    }

    $result['author'] = $author;
    $result['time'] = $interval;
    return $result;
}

/* -------------------------------------------------------------------------
 * Stage 4: collection descriptions
 * ---------------------------------------------------------------------- */

/**
 * Creates one "[COLID].json" collection descriptor per PDF page.
 *
 * COLID is md5(page number). Each descriptor starts from collection-base.json
 * and receives one "picture" asset for every picture file in the page folder,
 * including extracted raster images and vector PNGs. Assets are ordered
 * sequentially by sorted file name.
 */
function tbpdf_extract_page_texts(array &$doc, array $pageEntry, int $pageNumber): array
{
    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];
    $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));

    $content = tbpdf_page_content($doc, $dict);
    $diagnostics = [];
    if ($content['failed'] > 0) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'text_content_undecodable',
            'message' => 'Page ' . $pageNumber . ' has content streams that could not be decoded; text extraction may be incomplete.',
            'page' => $pageNumber,
        ];
    }

    $texts = [];
    if ($content['content'] !== '') {
        tbpdf_text_scan_content(
            $doc,
            $content['content'],
            $resources,
            $texts,
            $diagnostics,
            $pageNumber,
            0,
            []
        );
    }

    return ['texts' => $texts, 'diagnostics' => $diagnostics];
}

function tbpdf_text_scan_content(
    array &$doc,
    string $content,
    ?array $resources,
    array &$texts,
    array &$diagnostics,
    int $pageNumber,
    int $depth,
    array $formStack
): void {
    $fonts = tbpdf_text_font_map($doc, $resources);
    $currentFont = null;
    $buffer = '';
    $operands = [];
    $pos = 0;
    $len = strlen($content);
    $tokens = 0;

    $flush = static function () use (&$buffer, &$texts): void {
        $text = trim($buffer);
        if ($text !== '') {
            $texts[] = $text;
        }
        $buffer = '';
    };

    while ($pos < $len) {
        $tokens++;
        if ($tokens > 2000000) {
            $diagnostics[] = [
                'level' => 'warning',
                'code' => 'text_token_limit',
                'message' => 'Page ' . $pageNumber . ' text content exceeded the token limit.',
                'page' => $pageNumber,
            ];
            break;
        }

        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (!is_array($token) || ($token['t'] ?? '') !== 'kw') {
            $operands[] = $token;
            if (count($operands) > 32) {
                array_shift($operands);
            }
            continue;
        }

        $operator = (string) $token['v'];

        switch ($operator) {
            case 'BI':
                tbpdf_vector_skip_inline($content, $pos);
                $operands = [];
                continue 2;

            case 'Tf':
                $name = tbpdf_last_name($operands, 2);
                if ($name !== null) {
                    $currentFont = $name;
                }
                break;

            case 'Tj':
                $string = tbpdf_last_string($operands, 1);
                if ($string !== null) {
                    $buffer .= tbpdf_text_decode_string($doc, $fonts, $currentFont, $string);
                }
                break;

            case 'TJ':
                $array = tbpdf_array_values(tbpdf_resolve($doc, $operands[count($operands) - 1] ?? null));
                if ($array !== null) {
                    foreach ($array as $item) {
                        if (is_array($item) && ($item['t'] ?? '') === 'str') {
                            $buffer .= tbpdf_text_decode_string($doc, $fonts, $currentFont, $item['v']);
                        } else {
                            $number = tbpdf_num($item);
                            if ($number !== null && $number <= -100 && $buffer !== '' && substr($buffer, -1) !== ' ') {
                                $buffer .= ' ';
                            }
                        }
                    }
                }
                break;

            case "'":
                $string = tbpdf_last_string($operands, 1);
                if ($string !== null) {
                    $flush();
                    $buffer .= tbpdf_text_decode_string($doc, $fonts, $currentFont, $string);
                }
                break;

            case '"':
                $string = tbpdf_last_string($operands, 1);
                if ($string !== null) {
                    $flush();
                    $buffer .= tbpdf_text_decode_string($doc, $fonts, $currentFont, $string);
                }
                break;

            case 'Td':
            case 'TD':
            case 'T*':
            case 'Tm':
            case 'BT':
            case 'ET':
                $flush();
                break;

            case 'Do':
                $flush();
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    tbpdf_text_scan_xobject(
                        $doc,
                        $resources,
                        $name,
                        $texts,
                        $diagnostics,
                        $pageNumber,
                        $depth,
                        $formStack
                    );
                }
                break;

            default:
                break;
        }

        $operands = [];
    }

    $flush();
}

function tbpdf_text_scan_xobject(
    array &$doc,
    ?array $resources,
    string $name,
    array &$texts,
    array &$diagnostics,
    int $pageNumber,
    int $depth,
    array $formStack
): void {
    if ($resources === null || $depth > 8) {
        return;
    }
    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
    if ($xObjects === null || !isset($xObjects['v'][$name])) {
        return;
    }

    $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
    if (!is_array($xObject) || ($xObject['t'] ?? '') !== 'stream') {
        return;
    }
    $dict = ['t' => 'dict', 'v' => $xObject['v']];
    if (tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype')) !== 'Form') {
        return;
    }

    $objectNumber = $xObject['num'] ?? null;
    if ($objectNumber !== null && isset($formStack[$objectNumber])) {
        return;
    }
    if ($objectNumber !== null) {
        $formStack[$objectNumber] = true;
    }

    $data = tbpdf_decode_stream($doc, $xObject);
    if ($data === null) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'text_form_undecodable',
            'message' => 'A Form XObject on page ' . $pageNumber . ' could not be decoded for text extraction.',
            'page' => $pageNumber,
        ];
        return;
    }

    $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources'))) ?? $resources;
    tbpdf_text_scan_content(
        $doc,
        $data,
        $formResources,
        $texts,
        $diagnostics,
        $pageNumber,
        $depth + 1,
        $formStack
    );
}

function tbpdf_text_font_map(array &$doc, ?array $resources): array
{
    if ($resources === null) {
        return [];
    }
    $fonts = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'Font')));
    if ($fonts === null) {
        return [];
    }

    $map = [];
    foreach ($fonts['v'] as $name => $reference) {
        $font = tbpdf_as_dict(tbpdf_resolve($doc, $reference));
        if ($font === null) {
            continue;
        }
        $subtype = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'Subtype')) ?? 'unknown';
        $codeLength = $subtype === 'Type0' ? 2 : 1;
        $toUnicodeMap = [];
        $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'BaseFont'));
        $descriptor = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($font, 'FontDescriptor')));
        $cidFont = null;

        if ($subtype === 'Type0') {
            $descendants = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($font, 'DescendantFonts')));
            if ($descendants !== null && isset($descendants[0])) {
                $cidFont = tbpdf_as_dict(tbpdf_resolve($doc, $descendants[0]));
                if ($cidFont !== null) {
                    if ($baseFont === null) {
                        $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($cidFont, 'BaseFont'));
                    }
                    if ($descriptor === null) {
                        $descriptor = tbpdf_as_dict(
                            tbpdf_resolve($doc, tbpdf_dict_get($cidFont, 'FontDescriptor'))
                        );
                    }
                }
            }
        }

        // Glyph widths are needed to advance text positions and to measure
        // text boxes. Simple fonts expose /Widths + /FirstChar; composite
        // fonts expose a /W array plus /DW on the descendant CIDFont.
        $widths = [];
        $defaultWidth = $subtype === 'Type0' ? 1.0 : 0.5;
        if ($subtype === 'Type0' && $cidFont !== null) {
            $defaultWidthValue = tbpdf_num(tbpdf_dict_get($cidFont, 'DW'));
            if ($defaultWidthValue !== null) {
                $defaultWidth = (float) $defaultWidthValue / 1000;
            }
            $cidWidths = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($cidFont, 'W')));
            if ($cidWidths !== null) {
                $cidCount = count($cidWidths);
                $cidIndex = 0;
                while ($cidIndex < $cidCount) {
                    $firstCid = tbpdf_num($cidWidths[$cidIndex]);
                    if ($firstCid === null) {
                        $cidIndex++;
                        continue;
                    }
                    $widthList = tbpdf_array_values($cidWidths[$cidIndex + 1] ?? null);
                    if ($widthList !== null) {
                        foreach ($widthList as $offset => $widthValue) {
                            $widthNumber = tbpdf_num($widthValue);
                            if ($widthNumber !== null) {
                                $widths[(int) $firstCid + $offset] = (float) $widthNumber / 1000;
                            }
                        }
                        $cidIndex += 2;
                        continue;
                    }
                    $lastCid = tbpdf_num($cidWidths[$cidIndex + 1] ?? null);
                    $widthNumber = tbpdf_num($cidWidths[$cidIndex + 2] ?? null);
                    if ($lastCid === null || $widthNumber === null) {
                        break;
                    }
                    for ($cid = (int) $firstCid; $cid <= (int) $lastCid; $cid++) {
                        $widths[$cid] = (float) $widthNumber / 1000;
                    }
                    $cidIndex += 3;
                }
            }
        } else {
            $missingWidth = $descriptor !== null ? tbpdf_num(tbpdf_dict_get($descriptor, 'MissingWidth')) : null;
            if ($missingWidth !== null) {
                $defaultWidth = (float) $missingWidth / 1000;
            }
            $simpleWidths = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($font, 'Widths')));
            if ($simpleWidths !== null) {
                $firstChar = tbpdf_resolve_int($doc, tbpdf_dict_get($font, 'FirstChar'));
                $firstChar = $firstChar === null ? 0 : $firstChar;
                foreach ($simpleWidths as $offset => $widthValue) {
                    $widthNumber = tbpdf_num($widthValue);
                    if ($widthNumber !== null) {
                        $widths[$firstChar + $offset] = (float) $widthNumber / 1000;
                    }
                }
            }
        }

        $toUnicode = tbpdf_resolve($doc, tbpdf_dict_get($font, 'ToUnicode'));
        if (is_array($toUnicode) && ($toUnicode['t'] ?? '') === 'stream') {
            $cmap = tbpdf_decode_stream($doc, $toUnicode);
            if ($cmap !== null) {
                $toUnicodeMap = tbpdf_parse_tounicode_cmap($cmap);
            }
        }

        if (count($toUnicodeMap) > 0) {
            $lengthCounts = [];
            foreach (array_keys($toUnicodeMap) as $key) {
                $length = (int) (strlen($key) / 2);
                $lengthCounts[$length] = ($lengthCounts[$length] ?? 0) + 1;
            }
            arsort($lengthCounts);
            $codeLength = (int) array_key_first($lengthCounts);
            if ($codeLength < 1) {
                $codeLength = 1;
            }
        }

        $cleanName = tbpdf_font_name_clean($baseFont) ?? (string) $name;
        $italicAngle = 0.0;
        if ($descriptor !== null) {
            $angle = tbpdf_num($descriptor['v']['ItalicAngle'] ?? null);
            $italicAngle = $angle === null ? 0.0 : (float) $angle;
        }
        $style = tbpdf_font_style($cleanName, $italicAngle);

        $map[$name] = [
            'code_length' => max(1, min(4, $codeLength)),
            'map' => $toUnicodeMap,
            'subtype' => $subtype,
            'name' => $cleanName,
            'bold' => $style['bold'],
            'italic' => $style['italic'],
            'type0' => $subtype === 'Type0',
            'widths' => $widths,
            'default_width' => $defaultWidth,
        ];
    }

    return $map;
}

function tbpdf_parse_tounicode_cmap(string $cmap): array
{
    $map = [];

    if (preg_match_all('/beginbfchar(.*?)endbfchar/s', $cmap, $sections)) {
        foreach ($sections[1] as $section) {
            if (preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]*)>/', $section, $pairs, PREG_SET_ORDER)) {
                foreach ($pairs as $pair) {
                    $map[strtolower($pair[1])] = tbpdf_utf16be_hex_to_utf8($pair[2]);
                }
            }
        }
    }

    if (preg_match_all('/beginbfrange(.*?)endbfrange/s', $cmap, $sections)) {
        foreach ($sections[1] as $section) {
            if (preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*\[(.*?)\]/s', $section, $arrays, PREG_SET_ORDER)) {
                foreach ($arrays as $array) {
                    $low = hexdec($array[1]);
                    $high = hexdec($array[2]);
                    $byteLength = (int) (strlen($array[1]) / 2);
                    if ($high < $low || ($high - $low) > 100000) {
                        continue;
                    }
                    if (preg_match_all('/<([0-9A-Fa-f]+)>/', $array[3], $destinations)) {
                        $values = $destinations[1];
                        for ($code = $low; $code <= $high; $code++) {
                            $index = $code - $low;
                            if (!isset($values[$index])) {
                                break;
                            }
                            $key = str_pad(dechex($code), $byteLength * 2, '0', STR_PAD_LEFT);
                            $map[strtolower($key)] = tbpdf_utf16be_hex_to_utf8($values[$index]);
                        }
                    }
                }
            }

            if (preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/', $section, $ranges, PREG_SET_ORDER)) {
                foreach ($ranges as $range) {
                    $low = hexdec($range[1]);
                    $high = hexdec($range[2]);
                    $byteLength = (int) (strlen($range[1]) / 2);
                    if ($high < $low || ($high - $low) > 100000) {
                        continue;
                    }
                    $destination = hex2bin($range[3]);
                    if ($destination === false) {
                        continue;
                    }
                    for ($code = $low; $code <= $high; $code++) {
                        $offset = $code - $low;
                        $value = $destination;
                        if ($offset > 0) {
                            if (strlen($value) >= 2) {
                                $prefix = substr($value, 0, -2);
                                $last = unpack('n', substr($value, -2))[1];
                                $value = $prefix . pack('n', ($last + $offset) & 0xFFFF);
                            } else {
                                $value = chr((ord($value) + $offset) & 0xFF);
                            }
                        }
                        $key = str_pad(dechex($code), $byteLength * 2, '0', STR_PAD_LEFT);
                        $map[strtolower($key)] = tbpdf_utf16be_binary_to_utf8($value);
                    }
                }
            }
        }
    }

    return $map;
}

function tbpdf_utf16be_hex_to_utf8(string $hex): string
{
    if ($hex === '') {
        return '';
    }
    $binary = hex2bin($hex);
    if ($binary === false) {
        return '';
    }
    return tbpdf_utf16be_binary_to_utf8($binary);
}

function tbpdf_utf16be_binary_to_utf8(string $binary): string
{
    if ($binary === '') {
        return '';
    }
    if (strlen($binary) === 1) {
        return $binary;
    }
    if (str_starts_with($binary, "\xFE\xFF")) {
        $binary = substr($binary, 2);
    }
    return tbpdf_to_utf8($binary, 'UTF-16BE');
}

function tbpdf_text_decode_string(
    array &$doc,
    array $fonts,
    ?string $fontName,
    $value
): string {
    $resolved = tbpdf_resolve($doc, $value);
    if (is_array($resolved) && ($resolved['t'] ?? '') === 'str') {
        $bytes = $resolved['v'];
    } elseif (is_string($resolved)) {
        $bytes = $resolved;
    } else {
        return '';
    }
    $font = $fontName !== null ? ($fonts[$fontName] ?? null) : null;
    $codeLength = $font !== null ? (int) $font['code_length'] : 1;
    $map = $font !== null ? (array) $font['map'] : [];

    $out = '';
    $length = strlen($bytes);
    if ($codeLength <= 1) {
        for ($i = 0; $i < $length; $i++) {
            $key = bin2hex($bytes[$i]);
            $out .= array_key_exists($key, $map)
                ? $map[$key]
                : tbpdf_to_utf8($bytes[$i], 'Windows-1252');
        }
        return $out;
    }

    $step = max(1, $codeLength);
    if ($step > 1 && count($map) === 0) {
        // Composite fonts without ToUnicode cannot be mapped reliably.
        return '';
    }
    for ($i = 0; $i + $step <= $length; $i += $step) {
        $key = bin2hex(substr($bytes, $i, $step));
        $out .= $map[$key] ?? '?';
    }
    return $out;
}

function tbpdf_last_string(array $operands, int $offsetFromEnd): ?string
{
    $index = count($operands) - $offsetFromEnd;
    if ($index < 0) {
        return null;
    }
    $value = $operands[$index];
    return is_array($value) && ($value['t'] ?? '') === 'str' ? $value['v'] : null;
}

/**
 * Splits a PDF string into glyphs, returning the decoded text, the encoded
 * character code and the glyph width expressed in text space units (1 = 1 em).
 */
function tbpdf_text_glyphs(array &$doc, array $fonts, ?string $fontName, $value): array
{
    $resolved = tbpdf_resolve($doc, $value);
    if (is_array($resolved) && ($resolved['t'] ?? '') === 'str') {
        $bytes = $resolved['v'];
    } elseif (is_string($resolved)) {
        $bytes = $resolved;
    } else {
        return [];
    }

    $font = $fontName !== null ? ($fonts[$fontName] ?? null) : null;
    $codeLength = $font !== null ? (int) ($font['code_length'] ?? 1) : 1;
    $codeLength = max(1, min(4, $codeLength));
    $map = $font !== null ? (array) ($font['map'] ?? []) : [];
    $widths = $font !== null ? (array) ($font['widths'] ?? []) : [];
    $defaultWidth = $font !== null ? (float) ($font['default_width'] ?? 0.5) : 0.5;
    $type0 = (bool) ($font['type0'] ?? false);

    $glyphs = [];
    $length = strlen($bytes);
    if ($codeLength === 1) {
        for ($i = 0; $i < $length; $i++) {
            $code = ord($bytes[$i]);
            $key = bin2hex($bytes[$i]);
            $glyphs[] = [
                'code' => $code,
                'text' => array_key_exists($key, $map) ? $map[$key] : tbpdf_to_utf8($bytes[$i], 'Windows-1252'),
                'width' => (float) ($widths[$code] ?? $defaultWidth),
                'word' => !$type0 && $code === 32,
            ];
        }
        return $glyphs;
    }

    if (count($map) === 0) {
        // Composite fonts without ToUnicode cannot be mapped reliably.
        return [];
    }

    for ($i = 0; $i + $codeLength <= $length; $i += $codeLength) {
        $key = bin2hex(substr($bytes, $i, $codeLength));
        $code = (int) hexdec($key);
        $glyphs[] = [
            'code' => $code,
            'text' => $map[$key] ?? '?',
            'width' => (float) ($widths[$code] ?? $defaultWidth),
            'word' => false,
        ];
    }
    return $glyphs;
}

function tbpdf_create_collections(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null,
    array $options = []
): array {
    $result = [
        'movie' => null,
        'collection_dir' => null,
        'page_from' => 1,
        'page_to' => 0,
        'page_count' => 0,
        'collection_count' => 0,
        'asset_count' => 0,
        'paragraph_count' => 0,
        'collections' => [],
        'unresolved_markers' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_collections_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }

    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_collections_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }

    $pages = isset($data['pages']) && is_numeric($data['pages']) ? (int) $data['pages'] : 0;
    if ($pages <= 0) {
        return tbpdf_collections_fail($result, 'invalid_pages', 'The analysis JSON must contain a positive page count.');
    }
    $selection = tbpdf_page_selection($data, $options);
    if ($selection['error'] !== null) {
        return tbpdf_collections_fail($result, $selection['error']['code'], $selection['error']['message']);
    }
    $result['page_from'] = $selection['from'];
    $result['page_to'] = $selection['to'];
    $result['page_count'] = $selection['count'];

    if ($baseDir === null) {
        $file = $data['file'] ?? null;
        if (!is_string($file) || $file === '' || !is_file($file)) {
            return tbpdf_collections_fail($result, 'base_dir_missing', 'The base directory could not be derived from the analysis JSON; provide it explicitly.');
        }
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_collections_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_collections_fail($result, 'movie_folder_missing', 'The movie folder does not exist; run media extraction first.');
    }
    $result['movie'] = $moviePath;

    $pictureDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'picture';
    if (!is_dir($pictureDir)) {
        return tbpdf_collections_fail($result, 'picture_folder_missing', 'The media/picture folder does not exist; run media extraction first.');
    }

    $collectionDir = $moviePath . DIRECTORY_SEPARATOR . 'collection';
    if (!is_dir($collectionDir) && !mkdir($collectionDir, 0777, true) && !is_dir($collectionDir)) {
        return tbpdf_collections_fail($result, 'collection_dir_create_failed', 'The collection folder could not be created: ' . $collectionDir);
    }
    if (!is_writable($collectionDir)) {
        return tbpdf_collections_fail($result, 'collection_dir_not_writable', 'The collection folder is not writable.');
    }
    $result['collection_dir'] = $collectionDir;

    $templatePath = $templatePath ?? __DIR__ . DIRECTORY_SEPARATOR . 'collection-base.json';
    if (!is_string($templatePath) || $templatePath === '' || !is_file($templatePath) || !is_readable($templatePath)) {
        return tbpdf_collections_fail($result, 'template_missing', 'The collection-base.json template was not found or is not readable.');
    }

    $templateText = @file_get_contents($templatePath);
    if ($templateText === false) {
        return tbpdf_collections_fail($result, 'template_read_failed', 'The collection-base.json template could not be read.');
    }

    // [ASSETS] lives inside an object literal and is replaced by the
    // structured assets below. Remove it before decoding the template.
    $templateText = str_replace('[ASSETS]', '', $templateText);
    $collectionTemplate = json_decode($templateText, true);
    if (!is_array($collectionTemplate)) {
        return tbpdf_collections_fail($result, 'template_invalid', 'The collection-base.json template is not valid JSON: ' . json_last_error_msg());
    }

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }

    // Text assets come from the PDF content. Re-open the source document
    // because the definitive analysis JSON does not carry text runs.
    $pdfDoc = null;
    $pdfPages = [];
    $pdfFile = $data['file'] ?? null;
    if (is_string($pdfFile) && $pdfFile !== '' && is_file($pdfFile) && is_readable($pdfFile)) {
        $pdfRaw = @file_get_contents($pdfFile);
        if ($pdfRaw !== false) {
            $pdfDoc = tbpdf_doc($pdfFile, $pdfRaw, tbpdf_options([]));
            $pdfPages = tbpdf_parse_document($pdfDoc);
            foreach ($pdfDoc['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            if ($pdfDoc['encrypted']) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'text_extraction_unavailable',
                    'message' => 'The PDF is encrypted; text assets were not extracted.',
                    'page' => null,
                ];
                $pdfDoc = null;
                $pdfPages = [];
            } elseif (count($pdfPages) !== $pages) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'page_count_mismatch',
                    'message' => 'The analysis JSON declares ' . $pages . ' page(s), but the PDF has ' . count($pdfPages) . '.',
                    'page' => null,
                ];
            }
        } else {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'text_extraction_unavailable',
                'message' => 'The PDF file could not be read; text assets were not extracted.',
                'page' => null,
            ];
        }
    } else {
        $result['diagnostics'][] = [
            'level' => 'warning',
            'code' => 'text_extraction_unavailable',
            'message' => 'The source PDF is not readable; text assets were not extracted.',
            'page' => null,
        ];
    }

    $unresolved = [];
    $overwritten = false;
    $pictureExtensions = ['png', 'jpg', 'jpeg', 'gif'];

    for ($pageNumber = 1; $pageNumber <= $selection['count']; $pageNumber++) {
        $pdfPageNumber = $selection['from'] + $pageNumber - 1;
        $pageFolder = $pictureDir . DIRECTORY_SEPARATOR . $pageNumber;
        $files = [];
        if (!is_dir($pageFolder)) {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'page_folder_missing',
                'message' => 'The picture folder for page ' . $pageNumber . ' does not exist; the collection will have no assets.',
                'page' => $pageNumber,
            ];
        } else {
            foreach (scandir($pageFolder) ?: [] as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                $path = $pageFolder . DIRECTORY_SEPARATOR . $entry;
                if (!is_file($path)) {
                    continue;
                }
                $extension = strtolower((string) pathinfo($entry, PATHINFO_EXTENSION));
                if (!in_array($extension, $pictureExtensions, true)) {
                    continue;
                }
                $files[] = $entry;
            }
        }
        sort($files, SORT_NATURAL | SORT_FLAG_CASE);

        $assets = [];
        $order = 0;
        foreach ($files as $filename) {
            $assetKey = substr(md5($filename), 0, 12);
            $assetPath = $pageNumber . '/' . $filename;
            $assets[$assetKey] = [
                'order' => $order,
                'name' => $filename,
                'type' => 'picture',
                'time' => 5,
                'action' => '',
                'frames' => 1,
                'frtime' => 100,
                'file' => [
                    '@1' => $assetPath,
                    '@2' => $assetPath,
                    '@3' => $assetPath,
                    '@4' => $assetPath,
                    '@5' => $assetPath,
                ],
            ];
            $order++;
        }

        $texts = [];
        if ($pdfDoc !== null && isset($pdfPages[$pdfPageNumber - 1])) {
            $textResult = tbpdf_extract_page_texts($pdfDoc, $pdfPages[$pdfPageNumber - 1], $pageNumber);
            foreach ($textResult['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            $texts = $textResult['texts'];
        }

        $paragraphTexts = [];
        $paragraphs = 0;
        $paragraphCounter = 1;
        foreach ($texts as $textValue) {
            $textValue = trim((string) $textValue);
            if ($textValue === '') {
                continue;
            }

            $baseKey = substr(md5($textValue), 0, 12);
            $assetKey = $baseKey;
            $suffix = 2;
            while (isset($assets[$assetKey])) {
                $assetKey = $baseKey . '-' . $suffix;
                $suffix++;
            }

            $assets[$assetKey] = [
                'order' => $order,
                'name' => 'Paragraph' . $paragraphCounter,
                'type' => 'paragraph',
                'time' => 5,
                'action' => '',
                'frames' => 1,
                'frtime' => 100,
                'file' => [
                    '@1' => $textValue,
                    '@2' => $textValue,
                    '@3' => $textValue,
                    '@4' => $textValue,
                    '@5' => $textValue,
                ],
            ];
            $order++;
            $paragraphCounter++;
            $paragraphs++;
            $paragraphTexts[] = $textValue;
        }

        $colid = md5((string) $pageNumber);
        $collection = tbpdf_replace_markers($collectionTemplate, [
            '[COLID]' => $colid,
            '[ID]' => $movieId,
            '[COLNAME]' => (string) $pageNumber,
        ]);
        $collection['id'] = $colid;
        $collection['movie'] = $movieId;
        $collection['name'] = (string) $pageNumber;
        $collection['assets'] = count($assets) > 0 ? $assets : new stdClass();

        $json = json_encode($collection, $flags);
        if ($json === false) {
            return tbpdf_collections_fail($result, 'json_encode_failed', 'A collection descriptor could not be encoded: ' . json_last_error_msg());
        }
        $json .= PHP_EOL;

        $collectionFile = $collectionDir . DIRECTORY_SEPARATOR . $colid . '.json';
        if (is_file($collectionFile)) {
            $overwritten = true;
        }
        if (!tbpdf_write_bytes($collectionFile, $json)) {
            return tbpdf_collections_fail($result, 'collection_write_failed', 'The collection descriptor could not be written: ' . $collectionFile);
        }

        // Only inspect non-asset fields: text content may legitimately
        // contain bracket patterns that are not template markers.
        $markerData = $collection;
        unset($markerData['assets']);
        $markerJson = json_encode($markerData, $flags);
        if (is_string($markerJson) && preg_match_all('/\[[A-Z0-9_]+\]/', $markerJson, $matches)) {
            foreach ($matches[0] as $marker) {
                $unresolved[$marker] = true;
            }
        }

        $result['collections'][] = [
            'page' => $pageNumber,
            'colid' => $colid,
            'file' => $collectionFile,
            'assets' => count($assets),
            'filenames' => $files,
            'paragraphs' => $paragraphs,
            'texts' => $paragraphTexts,
        ];
        $result['collection_count']++;
        $result['asset_count'] += count($assets);
        $result['paragraph_count'] += $paragraphs;
    }

    if ($overwritten) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'collection_files_overwritten',
            'message' => 'One or more existing collection descriptors were overwritten.',
            'page' => null,
        ];
    }

    $result['unresolved_markers'] = array_keys($unresolved);
    return $result;
}

/**
 * Convenience wrapper that returns the stage 4 result as JSON.
 */
function tbpdf_create_collections_to_json(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null
): string {
    return tbpdf_json_encode(tbpdf_create_collections($analysisJson, $movieId, $baseDir, $templatePath));
}

function tbpdf_collections_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/* -------------------------------------------------------------------------
 * Stage 5: scene descriptions
 * ---------------------------------------------------------------------- */

function tbpdf_layout_page_images(array &$doc, array $pageEntry, int $pageNumber): array
{
    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];
    $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));

    $collected = tbpdf_collect_page_images($doc, $pageEntry, $pageNumber);
    $objectMap = [];
    $inlineFiles = [];
    foreach ($collected['images'] as $index => $image) {
        $stream = $image['stream'];
        $imageDict = ['t' => 'dict', 'v' => $stream['v']];
        [$filters] = tbpdf_image_filters_and_parms($doc, $imageDict);
        $extension = 'png';
        if (in_array('DCTDecode', $filters, true) || in_array('DCT', $filters, true)) {
            $extension = 'jpg';
        } elseif (in_array('JPXDecode', $filters, true)) {
            $extension = 'jp2';
        }
        $filename = 'image-' . str_pad((string) ($index + 1), 2, '0', STR_PAD_LEFT) . '.' . $extension;
        $objectNumber = $image['object'] ?? null;
        if ($objectNumber !== null) {
            if (!isset($objectMap[$objectNumber])) {
                $objectMap[$objectNumber] = $filename;
            }
        } else {
            $inlineFiles[] = $filename;
        }
    }

    $content = tbpdf_page_content($doc, $dict);
    $diagnostics = [];
    if ($content['failed'] > 0) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'image_layout_content_undecodable',
            'message' => 'Page ' . $pageNumber . ' has content streams that could not be decoded; image layout may be incomplete.',
            'page' => $pageNumber,
        ];
    }

    $items = [];
    if ($content['content'] !== '') {
        $state = [
            'ctm' => [1.0, 0.0, 0.0, 1.0, 0.0, 0.0],
            'resources' => $resources,
        ];
        $seen = [];
        $inlineIndex = 0;
        tbpdf_layout_image_scan_content(
            $doc,
            $content['content'],
            $resources,
            $state,
            $objectMap,
            $inlineFiles,
            $seen,
            $inlineIndex,
            $items,
            $diagnostics,
            $pageNumber,
            0,
            []
        );
    }

    return ['images' => $items, 'diagnostics' => $diagnostics];
}

function tbpdf_layout_image_scan_content(
    array &$doc,
    string $content,
    ?array $resources,
    array $state,
    array $objectMap,
    array $inlineFiles,
    array &$seen,
    int &$inlineIndex,
    array &$items,
    array &$diagnostics,
    int $pageNumber,
    int $depth,
    array $formStack
): void {
    $ctm = $state['ctm'];
    $stack = [];
    $operands = [];
    $pos = 0;
    $len = strlen($content);
    $tokens = 0;

    while ($pos < $len) {
        $tokens++;
        if ($tokens > 2000000) {
            break;
        }
        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (!is_array($token) || ($token['t'] ?? '') !== 'kw') {
            $operands[] = $token;
            if (count($operands) > 32) {
                array_shift($operands);
            }
            continue;
        }

        $operator = (string) $token['v'];
        switch ($operator) {
            case 'q':
                $stack[] = $ctm;
                break;
            case 'Q':
                if (count($stack) > 0) {
                    $ctm = array_pop($stack);
                }
                break;
            case 'cm':
                $matrix = tbpdf_last_numbers($operands, 6);
                if ($matrix !== null) {
                    $ctm = tbpdf_matrix_mult($matrix, $ctm);
                }
                break;
            case 'BI':
                tbpdf_vector_skip_inline($content, $pos);
                if (isset($inlineFiles[$inlineIndex])) {
                    $bbox = tbpdf_layout_unit_bbox($ctm);
                    $items[] = [
                        'kind' => 'image',
                        'filename' => $inlineFiles[$inlineIndex],
                        'bbox' => $bbox,
                        'content_pos' => $pos,
                        'seq' => count($items),
                    ];
                }
                $inlineIndex++;
                $operands = [];
                continue 2;
            case 'Do':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null && $resources !== null) {
                    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
                    if ($xObjects !== null && isset($xObjects['v'][$name])) {
                        $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
                        if (is_array($xObject) && ($xObject['t'] ?? '') === 'stream') {
                            $dict = ['t' => 'dict', 'v' => $xObject['v']];
                            $subtype = tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype'));
                            if ($subtype === 'Image') {
                                $objectNumber = $xObject['num'] ?? null;
                                if ($objectNumber !== null && isset($objectMap[$objectNumber]) && !isset($seen[$objectNumber])) {
                                    $seen[$objectNumber] = true;
                                    $items[] = [
                                        'kind' => 'image',
                                        'filename' => $objectMap[$objectNumber],
                                        'bbox' => tbpdf_layout_unit_bbox($ctm),
                                        'content_pos' => $pos,
                                        'seq' => count($items),
                                    ];
                                }
                            } elseif ($subtype === 'Form' && $depth < 8) {
                                $objectNumber = $xObject['num'] ?? null;
                                if ($objectNumber !== null && isset($formStack[$objectNumber])) {
                                    break;
                                }
                                if ($objectNumber !== null) {
                                    $formStack[$objectNumber] = true;
                                }
                                $formState = $state;
                                $formState['ctm'] = $ctm;
                                $matrix = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Matrix')));
                                if ($matrix !== null && count($matrix) >= 6) {
                                    $numbers = [];
                                    $valid = true;
                                    foreach (array_slice($matrix, 0, 6) as $item) {
                                        $number = tbpdf_num(tbpdf_resolve($doc, $item));
                                        if ($number === null) {
                                            $valid = false;
                                            break;
                                        }
                                        $numbers[] = (float) $number;
                                    }
                                    if ($valid) {
                                        $formState['ctm'] = tbpdf_matrix_mult($numbers, $ctm);
                                    }
                                }
                                $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources'))) ?? $resources;
                                $formState['resources'] = $formResources;
                                $data = tbpdf_decode_stream($doc, $xObject);
                                if ($data !== null) {
                                    tbpdf_layout_image_scan_content(
                                        $doc,
                                        $data,
                                        $formResources,
                                        $formState,
                                        $objectMap,
                                        $inlineFiles,
                                        $seen,
                                        $inlineIndex,
                                        $items,
                                        $diagnostics,
                                        $pageNumber,
                                        $depth + 1,
                                        $formStack
                                    );
                                }
                            }
                        }
                    }
                }
                break;
            default:
                break;
        }

        $operands = [];
    }
}

function tbpdf_layout_unit_bbox(array $ctm): array
{
    $corners = [
        [0.0, 0.0],
        [1.0, 0.0],
        [1.0, 1.0],
        [0.0, 1.0],
    ];
    $points = [];
    foreach ($corners as [$x, $y]) {
        $points[] = tbpdf_apply_matrix($ctm, $x, $y);
    }
    $xs = array_column($points, 0);
    $ys = array_column($points, 1);
    $minX = min($xs);
    $minY = min($ys);
    $maxX = max($xs);
    $maxY = max($ys);
    return [
        'llx' => $minX,
        'lly' => $minY,
        'urx' => $maxX,
        'ury' => $maxY,
        'width' => $maxX - $minX,
        'height' => $maxY - $minY,
    ];
}

function tbpdf_layout_page_texts(array &$doc, array $pageEntry, int $pageNumber): array
{
    $dict = $pageEntry['dict'];
    $inherited = $pageEntry['inherited'];
    $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));

    $content = tbpdf_page_content($doc, $dict);
    $diagnostics = [];
    if ($content['failed'] > 0) {
        $diagnostics[] = [
            'level' => 'warning',
            'code' => 'text_layout_content_undecodable',
            'message' => 'Page ' . $pageNumber . ' has content streams that could not be decoded; text layout may be incomplete.',
            'page' => $pageNumber,
        ];
    }

    $items = [];
    if ($content['content'] !== '') {
        tbpdf_layout_text_scan_content(
            $doc,
            $content['content'],
            $resources,
            $items,
            $diagnostics,
            $pageNumber,
            0,
            []
        );
    }

    return ['texts' => $items, 'diagnostics' => $diagnostics];
}

function tbpdf_layout_text_scan_content(
    array &$doc,
    string $content,
    ?array $resources,
    array &$items,
    array &$diagnostics,
    int $pageNumber,
    int $depth,
    array $formStack
): void {
    $fonts = tbpdf_text_font_map($doc, $resources);
    $x = 0.0;
    $y = 0.0;
    $lineMatrixX = 0.0;
    $lineMatrixY = 0.0;
    $leading = 0.0;
    $tmA = 1.0;
    $tmB = 0.0;
    $tmC = 0.0;
    $tmD = 1.0;
    $currentFont = null;
    $fontSize = 12.0;
    $fill = [0, 0, 0];
    $fillCs = ['type' => 'gray', 'components' => 1];
    $buffer = '';
    $lineActive = false;
    $lineX = 0.0;
    $lineY = 0.0;
    $linePos = 0;
    $lineFont = 'sans';
    $lineSize = 12.0;
    $lineColor = '0x000000';
    $lineBold = false;
    $lineItalic = false;
    $lineWidth = 0.0;
    $lineTrail = 0.0;
    $lineSeen = false;
    $charSpacing = 0.0;
    $wordSpacing = 0.0;
    $horizontalScale = 100.0;
    $ctm = [1.0, 0.0, 0.0, 1.0, 0.0, 0.0];
    $ctmStack = [];
    $operands = [];
    $pos = 0;
    $len = strlen($content);
    $tokens = 0;

    $flush = static function () use (
        &$buffer,
        &$lineActive,
        &$items,
        &$lineX,
        &$lineY,
        &$linePos,
        &$lineFont,
        &$lineSize,
        &$lineColor,
        &$lineBold,
        &$lineItalic,
        &$lineWidth,
        &$lineTrail,
        &$lineSeen
    ): void {
        $text = trim($buffer);
        if ($text !== '') {
            $width = $lineWidth - $lineTrail;
            $items[] = [
                'text' => $text,
                'x' => $lineX,
                'y' => $lineY,
                'size' => $lineSize,
                'font' => $lineFont,
                'color' => $lineColor,
                'bold' => $lineBold,
                'italic' => $lineItalic,
                'width' => $width > 0.0 ? $width : 0.0,
                'content_pos' => $linePos,
                'seq' => count($items),
            ];
        }
        $buffer = '';
        $lineActive = false;
        $lineWidth = 0.0;
        $lineTrail = 0.0;
        $lineSeen = false;
    };

    // Effective size of one text-space unit after the text matrix and the
    // current transformation matrix are applied.
    $textScale = static function () use (&$tmA, &$tmB, &$ctm): float {
        $vx = $tmA * $ctm[0] + $tmB * $ctm[2];
        $vy = $tmA * $ctm[1] + $tmB * $ctm[3];
        $scale = sqrt($vx * $vx + $vy * $vy);
        return $scale < 0.0001 ? 1.0 : $scale;
    };

    $ensureLine = static function () use (
        &$lineActive,
        &$lineX,
        &$lineY,
        &$linePos,
        &$lineFont,
        &$lineSize,
        &$lineColor,
        &$lineBold,
        &$lineItalic,
        &$x,
        &$y,
        &$pos,
        &$fontSize,
        &$tmA,
        &$tmB,
        &$currentFont,
        $fonts,
        &$fill,
        &$ctm,
        $textScale
    ): void {
        if ($lineActive) {
            return;
        }
        $lineActive = true;
        $point = tbpdf_apply_matrix($ctm, $x, $y);
        $lineX = $point[0];
        $lineY = $point[1];
        $linePos = $pos;
        $lineSize = $fontSize * $textScale();
        $fontInfo = $currentFont !== null ? ($fonts[$currentFont] ?? null) : null;
        $lineFont = $fontInfo['name'] ?? 'sans';
        $lineBold = (bool) ($fontInfo['bold'] ?? false);
        $lineItalic = (bool) ($fontInfo['italic'] ?? false);
        $lineColor = tbpdf_vector_color_hex($fill);
    };

    $appendString = static function ($value) use (
        &$doc,
        $fonts,
        &$currentFont,
        &$x,
        &$y,
        &$fontSize,
        &$tmA,
        &$tmB,
        &$charSpacing,
        &$wordSpacing,
        &$horizontalScale,
        &$buffer,
        &$lineX,
        &$lineY,
        &$lineWidth,
        &$lineTrail,
        &$lineSeen,
        &$ctm,
        $textScale
    ): void {
        $glyphs = tbpdf_text_glyphs($doc, $fonts, $currentFont, $value);
        if (count($glyphs) === 0) {
            return;
        }
        $scale = $textScale();
        $th = $horizontalScale / 100;
        foreach ($glyphs as $glyph) {
            // Per PDF 32000-1 9.4.4, glyph displacement in unscaled text
            // space is ((w0 * Tfs) + Tc + Tw) * Th.
            $advanceText = ((float) $glyph['width'] * $fontSize + $charSpacing + ($glyph['word'] ? $wordSpacing : 0.0)) * $th;
            $advancePoints = $advanceText * $scale;
            $glyphText = (string) $glyph['text'];
            $isSpace = $glyphText === '' || trim($glyphText) === '';
            if ($isSpace) {
                if ($lineSeen) {
                    $lineWidth += $advancePoints;
                    $lineTrail += $advancePoints;
                }
            } else {
                if (!$lineSeen) {
                    $lineSeen = true;
                    // Anchor the text box at the first visible glyph, not at
                    // leading spaces belonging to the same text run, and
                    // convert it to page space through the CTM.
                    $point = tbpdf_apply_matrix($ctm, $x, $y);
                    $lineX = $point[0];
                    $lineY = $point[1];
                } else {
                    $lineWidth += $lineTrail;
                    $lineTrail = 0.0;
                }
                $lineWidth += $advancePoints;
            }
            $buffer .= $glyphText;
            $x += $advanceText * $tmA;
            $y += $advanceText * $tmB;
        }
    };

    while ($pos < $len) {
        $tokens++;
        if ($tokens > 2000000) {
            $diagnostics[] = [
                'level' => 'warning',
                'code' => 'text_layout_token_limit',
                'message' => 'Page ' . $pageNumber . ' text layout exceeded the token limit.',
                'page' => $pageNumber,
            ];
            break;
        }

        $token = tbpdf_parse_value($content, $pos);
        if ($token === null) {
            if ($pos < $len) {
                $pos++;
            }
            continue;
        }

        if (!is_array($token) || ($token['t'] ?? '') !== 'kw') {
            $operands[] = $token;
            if (count($operands) > 32) {
                array_shift($operands);
            }
            continue;
        }

        $operator = (string) $token['v'];

        switch ($operator) {
            case 'q':
                $flush();
                $ctmStack[] = $ctm;
                break;

            case 'Q':
                $flush();
                if (count($ctmStack) > 0) {
                    $ctm = array_pop($ctmStack);
                }
                break;

            case 'cm':
                $flush();
                $matrix = tbpdf_last_numbers($operands, 6);
                if ($matrix !== null) {
                    $ctm = tbpdf_matrix_mult($matrix, $ctm);
                }
                break;

            case 'BI':
                tbpdf_vector_skip_inline($content, $pos);
                $operands = [];
                continue 2;

            case 'BT':
                $flush();
                $x = 0.0;
                $y = 0.0;
                $lineMatrixX = 0.0;
                $lineMatrixY = 0.0;
                $tmA = 1.0;
                $tmB = 0.0;
                $tmC = 0.0;
                $tmD = 1.0;
                break;

            case 'ET':
                $flush();
                break;

            case 'Tf':
                $name = tbpdf_last_name($operands, 2);
                $size = tbpdf_last_numbers($operands, 1);
                if ($name !== null) {
                    $currentFont = $name;
                }
                if ($size !== null) {
                    $fontSize = max(0.1, (float) $size[0]);
                }
                break;

            case 'Tm':
                $matrix = tbpdf_last_numbers($operands, 6);
                $flush();
                if ($matrix !== null) {
                    $tmA = $matrix[0];
                    $tmB = $matrix[1];
                    $tmC = $matrix[2];
                    $tmD = $matrix[3];
                    $x = $matrix[4];
                    $y = $matrix[5];
                    $lineMatrixX = $x;
                    $lineMatrixY = $y;
                }
                break;

            case 'Td':
                $translation = tbpdf_last_numbers($operands, 2);
                $flush();
                if ($translation !== null) {
                    $lineMatrixX += $translation[0] * $tmA + $translation[1] * $tmC;
                    $lineMatrixY += $translation[0] * $tmB + $translation[1] * $tmD;
                    $x = $lineMatrixX;
                    $y = $lineMatrixY;
                }
                break;

            case 'TD':
                $translation = tbpdf_last_numbers($operands, 2);
                $flush();
                if ($translation !== null) {
                    $lineMatrixX += $translation[0] * $tmA + $translation[1] * $tmC;
                    $lineMatrixY += $translation[0] * $tmB + $translation[1] * $tmD;
                    $x = $lineMatrixX;
                    $y = $lineMatrixY;
                    $leading = -$translation[1];
                }
                break;

            case 'T*':
                $flush();
                $lineMatrixX -= $leading * $tmC;
                $lineMatrixY -= $leading * $tmD;
                $x = $lineMatrixX;
                $y = $lineMatrixY;
                break;

            case 'TL':
                $leadingValues = tbpdf_last_numbers($operands, 1);
                if ($leadingValues !== null) {
                    $leading = $leadingValues[0];
                }
                break;

            case 'Tc':
                $spacingValues = tbpdf_last_numbers($operands, 1);
                if ($spacingValues !== null) {
                    $charSpacing = (float) $spacingValues[0];
                }
                break;

            case 'Tw':
                $spacingValues = tbpdf_last_numbers($operands, 1);
                if ($spacingValues !== null) {
                    $wordSpacing = (float) $spacingValues[0];
                }
                break;

            case 'Tz':
                $scaleValues = tbpdf_last_numbers($operands, 1);
                if ($scaleValues !== null) {
                    $horizontalScale = (float) $scaleValues[0];
                }
                break;

            case 'Tj':
                $string = tbpdf_last_string($operands, 1);
                if ($string !== null) {
                    $ensureLine();
                    $appendString($string);
                }
                break;

            case 'TJ':
                $array = tbpdf_array_values(tbpdf_resolve($doc, $operands[count($operands) - 1] ?? null));
                if ($array !== null) {
                    foreach ($array as $item) {
                        if (is_array($item) && ($item['t'] ?? '') === 'str') {
                            $ensureLine();
                            $appendString($item['v']);
                        } else {
                            $number = tbpdf_num($item);
                            if ($number !== null) {
                                $scale = $textScale();
                                $th = $horizontalScale / 100;
                                $advanceUser = -$number * $fontSize * $th / 1000;
                                $x += $advanceUser * $tmA;
                                $y += $advanceUser * $tmB;
                                if ($lineSeen) {
                                    $lineWidth += $advanceUser * $scale;
                                }
                                if ($number <= -100 && $buffer !== '' && substr($buffer, -1) !== ' ') {
                                    $buffer .= ' ';
                                }
                            }
                        }
                    }
                }
                break;

            case "'":
                $string = tbpdf_last_string($operands, 1);
                $flush();
                $lineMatrixX -= $leading * $tmC;
                $lineMatrixY -= $leading * $tmD;
                $x = $lineMatrixX;
                $y = $lineMatrixY;
                if ($string !== null) {
                    $ensureLine();
                    $appendString($string);
                }
                break;

            case '"':
                $string = tbpdf_last_string($operands, 1);
                $flush();
                $lineMatrixX -= $leading * $tmC;
                $lineMatrixY -= $leading * $tmD;
                $x = $lineMatrixX;
                $y = $lineMatrixY;
                if ($string !== null) {
                    $ensureLine();
                    $appendString($string);
                }
                break;

            case 'g':
                $values = tbpdf_last_numbers($operands, 1);
                if ($values !== null) {
                    $fill = tbpdf_vector_gray_byte($values[0]);
                    $fillCs = ['type' => 'gray', 'components' => 1];
                }
                break;

            case 'rg':
                $values = tbpdf_last_numbers($operands, 3);
                if ($values !== null) {
                    $fill = tbpdf_vector_rgb_bytes($values[0], $values[1], $values[2]);
                    $fillCs = ['type' => 'rgb', 'components' => 3];
                }
                break;

            case 'k':
                $values = tbpdf_last_numbers($operands, 4);
                if ($values !== null) {
                    $fill = tbpdf_cmyk_to_rgb(
                        tbpdf_vector_byte($values[0]),
                        tbpdf_vector_byte($values[1]),
                        tbpdf_vector_byte($values[2]),
                        tbpdf_vector_byte($values[3])
                    );
                    $fillCs = ['type' => 'cmyk', 'components' => 4];
                }
                break;

            case 'cs':
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null) {
                    $fillCs = tbpdf_vector_resolve_cs($doc, $resources, $name);
                }
                break;

            case 'sc':
            case 'scn':
                $components = tbpdf_vector_components($operands);
                if (!$components['pattern']) {
                    $fill = tbpdf_vector_color($fillCs, $components['numbers']);
                }
                break;

            case 'Do':
                $flush();
                $name = tbpdf_last_name($operands, 1);
                if ($name !== null && $resources !== null) {
                    $xObjects = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'XObject')));
                    if ($xObjects !== null && isset($xObjects['v'][$name])) {
                        $xObject = tbpdf_resolve($doc, $xObjects['v'][$name]);
                        if (is_array($xObject) && ($xObject['t'] ?? '') === 'stream') {
                            $dict = ['t' => 'dict', 'v' => $xObject['v']];
                            if (tbpdf_name_value(tbpdf_dict_get($dict, 'Subtype')) === 'Form' && $depth < 8) {
                                $objectNumber = $xObject['num'] ?? null;
                                if ($objectNumber === null || !isset($formStack[$objectNumber])) {
                                    if ($objectNumber !== null) {
                                        $formStack[$objectNumber] = true;
                                    }
                                    $data = tbpdf_decode_stream($doc, $xObject);
                                    if ($data !== null) {
                                        $formResources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($dict, 'Resources'))) ?? $resources;
                                        $formItems = [];
                                        $formDiagnostics = [];
                                        tbpdf_layout_text_scan_content(
                                            $doc,
                                            $data,
                                            $formResources,
                                            $formItems,
                                            $formDiagnostics,
                                            $pageNumber,
                                            $depth + 1,
                                            $formStack
                                        );
                                        foreach ($formItems as $formItem) {
                                            $items[] = $formItem;
                                        }
                                        foreach ($formDiagnostics as $diagnostic) {
                                            $diagnostics[] = $diagnostic;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                break;

            default:
                break;
        }

        $operands = [];
    }

    $flush();
}

function tbpdf_layout_text_estimated_width(string $text, float $fontSize): float
{
    if ($text === '') {
        return 0.0;
    }
    $length = function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
    return $length * $fontSize * 0.6;
}

function tbpdf_create_scenes(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null,
    array $options = []
): array {
    $result = [
        'movie' => null,
        'scene_dir' => null,
        'page_from' => 1,
        'page_to' => 0,
        'page_count' => 0,
        'scene_count' => 0,
        'keyframe_count' => 0,
        'scenes' => [],
        'unresolved_markers' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_scenes_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_scenes_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }
    $pages = isset($data['pages']) && is_numeric($data['pages']) ? (int) $data['pages'] : 0;
    if ($pages <= 0) {
        return tbpdf_scenes_fail($result, 'invalid_pages', 'The analysis JSON must contain a positive page count.');
    }
    $selection = tbpdf_page_selection($data, $options);
    if ($selection['error'] !== null) {
        return tbpdf_scenes_fail($result, $selection['error']['code'], $selection['error']['message']);
    }
    $result['page_from'] = $selection['from'];
    $result['page_to'] = $selection['to'];
    $result['page_count'] = $selection['count'];

    if ($baseDir === null) {
        $file = $data['file'] ?? null;
        if (!is_string($file) || $file === '' || !is_file($file)) {
            return tbpdf_scenes_fail($result, 'base_dir_missing', 'The base directory could not be derived from the analysis JSON; provide it explicitly.');
        }
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_scenes_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_scenes_fail($result, 'movie_folder_missing', 'The movie folder does not exist; run media extraction first.');
    }
    $result['movie'] = $moviePath;

    $collectionDir = $moviePath . DIRECTORY_SEPARATOR . 'collection';
    if (!is_dir($collectionDir)) {
        return tbpdf_scenes_fail($result, 'collection_folder_missing', 'The collection folder does not exist; run collection creation first.');
    }

    $sceneDir = $moviePath . DIRECTORY_SEPARATOR . 'scene';
    if (!is_dir($sceneDir) && !mkdir($sceneDir, 0777, true) && !is_dir($sceneDir)) {
        return tbpdf_scenes_fail($result, 'scene_dir_create_failed', 'The scene folder could not be created: ' . $sceneDir);
    }
    if (!is_writable($sceneDir)) {
        return tbpdf_scenes_fail($result, 'scene_dir_not_writable', 'The scene folder is not writable.');
    }
    $result['scene_dir'] = $sceneDir;

    $templatePath = $templatePath ?? __DIR__ . DIRECTORY_SEPARATOR . 'scene-base.json';
    if (!is_string($templatePath) || $templatePath === '' || !is_file($templatePath) || !is_readable($templatePath)) {
        return tbpdf_scenes_fail($result, 'template_missing', 'The scene-base.json template was not found or is not readable.');
    }
    $templateText = @file_get_contents($templatePath);
    if ($templateText === false) {
        return tbpdf_scenes_fail($result, 'template_read_failed', 'The scene-base.json template could not be read.');
    }
    $templateText = str_replace('[KEYFRAMES]', '', $templateText);
    $sceneTemplate = json_decode($templateText, true);
    if (!is_array($sceneTemplate)) {
        return tbpdf_scenes_fail($result, 'template_invalid', 'The scene-base.json template is not valid JSON: ' . json_last_error_msg());
    }

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }

    // The PDF is reopened for layout: image placements, text positions and
    // vector bounding boxes are not part of the stage 1 summary.
    $pdfDoc = null;
    $pdfPages = [];
    $pdfFile = $data['file'] ?? null;
    if (is_string($pdfFile) && $pdfFile !== '' && is_file($pdfFile) && is_readable($pdfFile)) {
        $pdfRaw = @file_get_contents($pdfFile);
        if ($pdfRaw !== false) {
            $pdfDoc = tbpdf_doc($pdfFile, $pdfRaw, tbpdf_options([]));
            $pdfPages = tbpdf_parse_document($pdfDoc);
            foreach ($pdfDoc['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            if ($pdfDoc['encrypted']) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'scene_layout_unavailable',
                    'message' => 'The PDF is encrypted; scene layout was not extracted.',
                    'page' => null,
                ];
                $pdfDoc = null;
                $pdfPages = [];
            }
        }
    }
    if ($pdfDoc === null) {
        $result['diagnostics'][] = [
            'level' => 'warning',
            'code' => 'scene_layout_unavailable',
            'message' => 'The PDF could not be read for layout; scene elements were placed at 0,0.',
            'page' => null,
        ];
    }

    $factor = 96 / 72;
    $unresolved = [];
    $overwritten = false;

    for ($pageNumber = 1; $pageNumber <= $selection['count']; $pageNumber++) {
        $pdfPageNumber = $selection['from'] + $pageNumber - 1;
        $sceneId = md5((string) $pageNumber);
        $prevId = md5((string) ($pageNumber > 1 ? $pageNumber - 1 : $selection['count']));
        $nextId = md5((string) ($pageNumber < $selection['count'] ? $pageNumber + 1 : 1));

        $collectionFile = $collectionDir . DIRECTORY_SEPARATOR . $sceneId . '.json';
        $collection = is_file($collectionFile) ? json_decode((string) @file_get_contents($collectionFile), true) : null;
        if (!is_array($collection)) {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'collection_missing',
                'message' => 'The collection for page ' . $pageNumber . ' was not found.',
                'page' => $pageNumber,
            ];
            $collection = [];
        }
        $assets = is_array($collection['assets'] ?? null) ? $collection['assets'] : [];

        $byName = [];
        foreach ($assets as $assetKey => $asset) {
            if (is_array($asset) && isset($asset['name'])) {
                $byName[(string) $asset['name']] = [
                    'key' => (string) $assetKey,
                    'type' => (string) ($asset['type'] ?? 'picture'),
                ];
            }
        }

        $pageEntry = $pdfPages[$pdfPageNumber - 1] ?? null;
        $pageBox = null;
        if ($pageEntry !== null) {
            $mediaBox = tbpdf_box($pdfDoc, tbpdf_page_attr($pageEntry['dict'], $pageEntry['inherited'], 'MediaBox'));
            $cropBox = tbpdf_box($pdfDoc, tbpdf_page_attr($pageEntry['dict'], $pageEntry['inherited'], 'CropBox')) ?? $mediaBox;
            $pageBox = $cropBox;
        }
        if ($pageBox === null) {
            $pageBox = [
                'llx' => 0.0,
                'lly' => 0.0,
                'urx' => 612.0,
                'ury' => 792.0,
                'width' => 612.0,
                'height' => 792.0,
            ];
        }

        $elements = [];
        $seq = 0;

        if ($pdfDoc !== null && $pageEntry !== null) {
            $imageLayout = tbpdf_layout_page_images($pdfDoc, $pageEntry, $pageNumber);
            foreach ($imageLayout['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            foreach ($imageLayout['images'] as $image) {
                $elements[] = [
                    'kind' => 'image',
                    'name' => $image['filename'],
                    'bbox' => $image['bbox'],
                    'content_pos' => $image['content_pos'] ?? 0,
                    'seq' => $seq++,
                ];
            }

            $textLayout = tbpdf_layout_page_texts($pdfDoc, $pageEntry, $pageNumber);
            foreach ($textLayout['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            $paragraphIndex = 1;
            foreach ($textLayout['texts'] as $text) {
                $elements[] = [
                    'kind' => 'text',
                    'name' => 'Paragraph' . $paragraphIndex,
                    'text' => $text['text'],
                    'x' => (float) $text['x'],
                    'y' => (float) $text['y'],
                    'size' => (float) $text['size'],
                    'width' => isset($text['width'])
                        ? (float) $text['width']
                        : tbpdf_layout_text_estimated_width((string) $text['text'], (float) $text['size']),
                    'font' => (string) ($text['font'] ?? 'sans'),
                    'color' => (string) ($text['color'] ?? '0x000000'),
                    'bold' => (bool) ($text['bold'] ?? false),
                    'italic' => (bool) ($text['italic'] ?? false),
                    'content_pos' => $text['content_pos'] ?? 0,
                    'seq' => $seq++,
                ];
                $paragraphIndex++;
            }

            $pageDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'picture' . DIRECTORY_SEPARATOR . $pageNumber;
            $vectorLayout = tbpdf_extract_page_vectors(
                $pdfDoc,
                $pageEntry,
                $pageNumber,
                $pageDir,
                [
                    'vector_dry_run' => true,
                    'vector_dpi' => 96,
                    'vector_max_pixels' => 4000000,
                    'vector_max_objects' => 250,
                    'vector_aa' => 2,
                ]
            );
            foreach ($vectorLayout['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            foreach ($vectorLayout['vectors'] as $vector) {
                if (empty($vector['ok'])) {
                    continue;
                }
                $elements[] = [
                    'kind' => 'vector',
                    'name' => basename((string) $vector['file']),
                    'bbox' => $vector['bbox'],
                    'alpha' => isset($vector['alpha']) ? (float) $vector['alpha'] : 1.0,
                    'center' => $vector['center'] ?? null,
                    'local_width' => isset($vector['local_width']) ? (float) $vector['local_width'] : null,
                    'local_height' => isset($vector['local_height']) ? (float) $vector['local_height'] : null,
                    'rotation' => isset($vector['rotation']) ? (float) $vector['rotation'] : 0.0,
                    'content_pos' => $vector['content_pos'] ?? 0,
                    'seq' => $seq++,
                ];
            }
        }

        usort($elements, static function (array $a, array $b): int {
            $posA = $a['content_pos'] ?? PHP_INT_MAX;
            $posB = $b['content_pos'] ?? PHP_INT_MAX;
            if ($posA === $posB) {
                return ($a['seq'] ?? 0) <=> ($b['seq'] ?? 0);
            }
            return $posA <=> $posB;
        });

        $keyframes = [];
        $order = 0;
        $usedAssets = [];

        foreach ($elements as $element) {
            $asset = $byName[$element['name']] ?? null;
            if ($asset === null) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'layout_asset_missing',
                    'message' => 'The layout element ' . $element['name'] . ' has no corresponding collection asset.',
                    'page' => $pageNumber,
                ];
                continue;
            }
            $assetKey = $asset['key'];
            if (isset($usedAssets[$assetKey])) {
                continue;
            }
            $usedAssets[$assetKey] = true;

            if ($element['kind'] === 'text') {
                $x = ($element['x'] - $pageBox['llx']) * $factor;
                $y = ($pageBox['ury'] - ($element['y'] + $element['size'])) * $factor;
                $measured = isset($element['width'])
                    ? (float) $element['width']
                    : tbpdf_layout_text_estimated_width($element['text'], $element['size']);
                // Text boxes get extra room to avoid clipping the rendered
                // glyphs: 1.5x the measured width and 2x the font height.
                $width = max(1.0, $measured * $factor * 1.5);
                $height = max(1.0, $element['size'] * $factor * 2.0);
                $font = $element['font'] !== '' ? $element['font'] : 'sans';
                $fontSize = $element['size'] * $factor;
                $color = $element['color'] !== '' ? $element['color'] : '0x000000';
                $bold = $element['bold'];
                $italic = $element['italic'];
                $alpha = 1.0;
                $rotation = 0.0;
            } else {
                $bbox = $element['bbox'];
                $bboxWidth = $bbox['width'] ?? (($bbox['urx'] ?? 0) - ($bbox['llx'] ?? 0));
                $bboxHeight = $bbox['height'] ?? (($bbox['ury'] ?? 0) - ($bbox['lly'] ?? 0));
                $rotation = 0.0;
                if (
                    $element['kind'] === 'vector' &&
                    isset($element['center']) && is_array($element['center']) &&
                    isset($element['local_width'], $element['local_height'])
                ) {
                    // Place the unrotated local box so that, after TilBuci
                    // rotates it around its origin, its center matches the
                    // center of the source shape.
                    $angleDegrees = (float) ($element['rotation'] ?? 0.0);
                    $angle = deg2rad($angleDegrees);
                    $localWidth = (float) $element['local_width'];
                    $localHeight = (float) $element['local_height'];
                    $centerX = (float) $element['center'][0];
                    $centerY = (float) $element['center'][1];
                    $tx = ($centerX - $pageBox['llx']) -
                        ($localWidth / 2 * cos($angle) - $localHeight / 2 * sin($angle));
                    $ty = ($pageBox['ury'] - $centerY) -
                        ($localWidth / 2 * sin($angle) + $localHeight / 2 * cos($angle));
                    $x = $tx * $factor;
                    $y = $ty * $factor;
                    $width = max(1.0, $localWidth * $factor);
                    $height = max(1.0, $localHeight * $factor);
                    $rotation = fmod($angleDegrees, 360.0);
                    if ($rotation < 0) {
                        $rotation += 360.0;
                    }
                } else {
                    $x = ($bbox['llx'] - $pageBox['llx']) * $factor;
                    $y = ($pageBox['ury'] - $bbox['ury']) * $factor;
                    $width = max(1.0, $bboxWidth * $factor);
                    $height = max(1.0, $bboxHeight * $factor);
                }
                $font = 'sans';
                $fontSize = 20.0;
                $color = '0x000000';
                $bold = false;
                $italic = false;
                $alpha = isset($element['alpha']) ? (float) $element['alpha'] : 1.0;
            }

            $key = $pageNumber . '_' . $assetKey;
            $keyframes[$key] = tbpdf_scene_instance(
                $sceneId,
                $assetKey,
                $order,
                $x,
                $y,
                $width,
                $height,
                $font,
                $fontSize,
                $color,
                $bold,
                $italic,
                $alpha,
                $rotation
            );
            $order++;
        }

        // Ensure every collection asset appears in the scene, even when it
        // had no layout metadata.
        foreach ($assets as $assetKey => $asset) {
            if (isset($usedAssets[$assetKey])) {
                continue;
            }
            $key = $pageNumber . '_' . $assetKey;
            $keyframes[$key] = tbpdf_scene_instance(
                $sceneId,
                $assetKey,
                $order,
                0,
                0,
                0,
                0,
                'sans',
                20,
                '0x000000',
                false,
                false,
                1.0,
                0.0
            );
            $order++;
            $usedAssets[$assetKey] = true;
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'asset_without_layout',
                'message' => 'The collection asset ' . ($asset['name'] ?? $assetKey) . ' had no layout metadata and was placed at 0,0.',
                'page' => $pageNumber,
            ];
        }

        $replacements = [
            '[SCENEID]' => $sceneId,
            '[SCENENAME]' => (string) $pageNumber,
            '[ID]' => $movieId,
            '[UP]' => $prevId,
            '[DOWN]' => $nextId,
            '[LEFT]' => $prevId,
            '[RIGHT]' => $nextId,
        ];
        $scene = tbpdf_replace_markers($sceneTemplate, $replacements);
        $scene['title'] = (string) $pageNumber;
        $scene['id'] = $sceneId;
        $scene['movie'] = $movieId;
        $scene['navigation'] = [
            'up' => $prevId,
            'down' => $nextId,
            'left' => $prevId,
            'right' => $nextId,
            'nin' => '',
            'nout' => '',
        ];
        $scene['collections'] = [$sceneId];
        $scene['keyframes'] = [count($keyframes) > 0 ? $keyframes : new stdClass()];

        $json = json_encode($scene, $flags);
        if ($json === false) {
            return tbpdf_scenes_fail($result, 'json_encode_failed', 'A scene descriptor could not be encoded: ' . json_last_error_msg());
        }
        $json .= PHP_EOL;

        $sceneFile = $sceneDir . DIRECTORY_SEPARATOR . $sceneId . '.json';
        if (is_file($sceneFile)) {
            $overwritten = true;
        }
        if (!tbpdf_write_bytes($sceneFile, $json)) {
            return tbpdf_scenes_fail($result, 'scene_write_failed', 'The scene descriptor could not be written: ' . $sceneFile);
        }

        $markerData = $scene;
        unset($markerData['keyframes']);
        $markerJson = json_encode($markerData, $flags);
        if (is_string($markerJson) && preg_match_all('/\[[A-Z0-9_]+\]/', $markerJson, $matches)) {
            foreach ($matches[0] as $marker) {
                $unresolved[$marker] = true;
            }
        }

        $result['scenes'][] = [
            'page' => $pageNumber,
            'sceneid' => $sceneId,
            'file' => $sceneFile,
            'keyframes' => count($keyframes),
            'navigation' => ['up' => $prevId, 'down' => $nextId, 'left' => $prevId, 'right' => $nextId],
        ];
        $result['scene_count']++;
        $result['keyframe_count'] += count($keyframes);
    }

    if ($overwritten) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'scene_files_overwritten',
            'message' => 'One or more existing scene descriptors were overwritten.',
            'page' => null,
        ];
    }

    $result['unresolved_markers'] = array_keys($unresolved);
    return $result;
}

function tbpdf_scene_instance(
    string $collection,
    string $asset,
    int $order,
    float $x,
    float $y,
    float $width,
    float $height,
    string $font,
    float $fontSize,
    string $color,
    bool $bold,
    bool $italic,
    float $alpha = 1.0,
    float $rotation = 0.0
): array {
    $alpha = max(0.0, min(1.0, $alpha));
    $rotation = fmod($rotation, 360.0);
    if ($rotation < 0) {
        $rotation += 360.0;
    }
    $layout = [
        'order' => $order,
        'x' => (int) round($x),
        'y' => (int) round($y),
        'alpha' => round($alpha, 3),
        'width' => (int) round($width),
        'height' => (int) round($height),
        'rotation' => ((int) round($rotation)) % 360,
        'visible' => true,
        'color' => '0xFFFFFF',
        'colorAlpha' => 0,
        'volume' => 1,
        'pan' => 0,
        'blur' => '',
        'dropshadow' => '',
        'glow' => '',
        'blend' => 'normal',
        'textFont' => $font,
        'textSize' => (int) round($fontSize),
        'textColor' => $color,
        'textBold' => $bold,
        'textItalic' => $italic,
        'textLeading' => 10,
        'textSpacing' => 0,
        'textBackground' => '',
        'textAlign' => 'left',
    ];

    return [
        'collection' => $collection,
        'asset' => $asset,
        'action' => '',
        'actionover' => '',
        'timedac' => '',
        'play' => true,
        'focus' => true,
        'alttext' => '',
        'horizontal' => $layout,
        'vertical' => $layout,
    ];
}

function tbpdf_create_scenes_to_json(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templatePath = null
): string {
    return tbpdf_json_encode(tbpdf_create_scenes($analysisJson, $movieId, $baseDir, $templatePath));
}

function tbpdf_scenes_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/* -------------------------------------------------------------------------
 * Stage 6: file adjustments
 * ---------------------------------------------------------------------- */

/**
 * Copies the fixed base files into the movie folder and finalizes movie.json.
 *
 * Copies:
 *   contraptions-base.json -> [ID].movie/contraptions.json
 *   strings-base.json      -> [ID].movie/strings.json
 *   narrative-base.json    -> [ID].movie/narrative.json
 *
 * Updates movie.json:
 *   [STARTSCENE] -> md5(1)
 *   [UPDATED]    -> current local date/time (YYYY-MM-DD HH:MM:SS)
 */
function tbpdf_finalize_movie(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templateDir = null
): array {
    $result = [
        'movie' => null,
        'movie_json' => null,
        'files' => [],
        'start' => null,
        'updated' => null,
        'unresolved_markers' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_finalize_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_finalize_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }
    $pages = isset($data['pages']) && is_numeric($data['pages']) ? (int) $data['pages'] : 0;
    if ($pages <= 0) {
        return tbpdf_finalize_fail($result, 'invalid_pages', 'The analysis JSON must contain a positive page count.');
    }

    if ($baseDir === null) {
        $file = $data['file'] ?? null;
        if (!is_string($file) || $file === '' || !is_file($file)) {
            return tbpdf_finalize_fail($result, 'base_dir_missing', 'The base directory could not be derived from the analysis JSON; provide it explicitly.');
        }
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_finalize_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_finalize_fail($result, 'movie_folder_missing', 'The movie folder does not exist.');
    }
    if (!is_writable($moviePath)) {
        return tbpdf_finalize_fail($result, 'movie_folder_not_writable', 'The movie folder is not writable.');
    }
    $result['movie'] = $moviePath;

    $templateDir = $templateDir ?? __DIR__;
    $templateDir = rtrim($templateDir, '/\\');
    if ($templateDir === '' || !is_dir($templateDir)) {
        return tbpdf_finalize_fail($result, 'template_dir_missing', 'The template directory does not exist.');
    }

    $copies = [
        'contraptions-base.json' => 'contraptions.json',
        'strings-base.json' => 'strings.json',
        'narrative-base.json' => 'narrative.json',
    ];
    $overwritten = false;

    foreach ($copies as $sourceName => $destinationName) {
        $source = $templateDir . DIRECTORY_SEPARATOR . $sourceName;
        $destination = $moviePath . DIRECTORY_SEPARATOR . $destinationName;
        if (!is_file($source) || !is_readable($source)) {
            return tbpdf_finalize_fail($result, 'template_missing', 'The template file was not found: ' . $sourceName);
        }
        if (is_file($destination)) {
            $overwritten = true;
        }
        if (!@copy($source, $destination)) {
            return tbpdf_finalize_fail($result, 'file_copy_failed', 'Could not copy ' . $sourceName . ' to ' . $destinationName . '.');
        }
        $result['files'][$destinationName] = $destination;
    }

    $movieJsonPath = $moviePath . DIRECTORY_SEPARATOR . 'movie.json';
    if (!is_file($movieJsonPath) || !is_readable($movieJsonPath)) {
        return tbpdf_finalize_fail($result, 'movie_json_missing', 'movie.json was not found; run movie creation first.');
    }
    $movie = json_decode((string) @file_get_contents($movieJsonPath), true);
    if (!is_array($movie)) {
        return tbpdf_finalize_fail($result, 'movie_json_invalid', 'movie.json is not valid JSON.');
    }
    $result['movie_json'] = $movieJsonPath;

    $startScene = md5('1');
    $updated = date('Y-m-d H:i:s');
    $movie = tbpdf_replace_markers($movie, [
        '[STARTSCENE]' => $startScene,
        '[UPDATED]' => $updated,
    ]);
    $movie['start'] = $startScene;
    $movie['updated'] = $updated;

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($movie, $flags);
    if ($json === false) {
        return tbpdf_finalize_fail($result, 'json_encode_failed', 'movie.json could not be encoded: ' . json_last_error_msg());
    }
    $json .= PHP_EOL;
    if (!tbpdf_write_bytes($movieJsonPath, $json)) {
        return tbpdf_finalize_fail($result, 'movie_json_write_failed', 'movie.json could not be written.');
    }

    if ($overwritten) {
        $result['diagnostics'][] = [
            'level' => 'info',
            'code' => 'files_overwritten',
            'message' => 'One or more base files already existed and were overwritten.',
            'page' => null,
        ];
    }

    $unresolved = [];
    if (preg_match_all('/\[[A-Z0-9_]+\]/', $json, $matches)) {
        $unresolved = array_values(array_unique($matches[0]));
    }

    $result['start'] = $startScene;
    $result['updated'] = $updated;
    $result['unresolved_markers'] = $unresolved;
    return $result;
}

/**
 * Convenience wrapper that returns the stage 6 result as JSON.
 */
function tbpdf_finalize_movie_to_json(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    ?string $templateDir = null
): string {
    return tbpdf_json_encode(tbpdf_finalize_movie($analysisJson, $movieId, $baseDir, $templateDir));
}

function tbpdf_finalize_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/* -------------------------------------------------------------------------
 * Stage 7: embedded fonts
 * ---------------------------------------------------------------------- */

/**
 * Extracts embedded fonts, converts the TrueType/OpenType ones to WOFF and
 * registers the converted files in movie.json.
 *
 * Only SFNT-based programs are converted: /FontFile2 (TrueType) and
 * /FontFile3 with /Subtype /OpenType. Type1 (/FontFile) and bare CFF
 * (/FontFile3 /Type1C or /CIDFontType0C) need a full font converter and are
 * reported as unsupported.
 */
function tbpdf_extract_font_files(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    array $options = []
): array {
    $result = [
        'movie' => null,
        'font_dir' => null,
        'movie_json' => null,
        'page_from' => 1,
        'page_to' => 0,
        'page_count' => 0,
        'font_count' => 0,
        'fonts' => [],
        'converted' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_fonts_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_fonts_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }
    $pages = isset($data['pages']) && is_numeric($data['pages']) ? (int) $data['pages'] : 0;
    if ($pages <= 0) {
        return tbpdf_fonts_fail($result, 'invalid_pages', 'The analysis JSON must contain a positive page count.');
    }
    $selection = tbpdf_page_selection($data, $options);
    if ($selection['error'] !== null) {
        return tbpdf_fonts_fail($result, $selection['error']['code'], $selection['error']['message']);
    }
    $result['page_from'] = $selection['from'];
    $result['page_to'] = $selection['to'];
    $result['page_count'] = $selection['count'];

    if ($baseDir === null) {
        $file = $data['file'] ?? null;
        if (!is_string($file) || $file === '' || !is_file($file)) {
            return tbpdf_fonts_fail($result, 'base_dir_missing', 'The base directory could not be derived from the analysis JSON; provide it explicitly.');
        }
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_fonts_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_fonts_fail($result, 'movie_folder_missing', 'The movie folder does not exist; run media extraction first.');
    }
    $result['movie'] = $moviePath;

    $fontDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'font';
    $fontDirExisted = is_dir($fontDir);
    if (!$fontDirExisted && !mkdir($fontDir, 0777, true) && !is_dir($fontDir)) {
        return tbpdf_fonts_fail($result, 'font_dir_create_failed', 'The font folder could not be created: ' . $fontDir);
    }
    $result['font_dir'] = $fontDir;

    $movieJsonPath = $moviePath . DIRECTORY_SEPARATOR . 'movie.json';
    if (!is_file($movieJsonPath) || !is_readable($movieJsonPath)) {
        return tbpdf_fonts_fail($result, 'movie_json_missing', 'movie.json was not found; run movie creation first.');
    }
    $movie = json_decode((string) @file_get_contents($movieJsonPath), true);
    if (!is_array($movie)) {
        return tbpdf_fonts_fail($result, 'movie_json_invalid', 'movie.json is not valid JSON.');
    }
    $result['movie_json'] = $movieJsonPath;

    $descriptors = [];
    $pdfFile = $data['file'] ?? null;
    if (is_string($pdfFile) && $pdfFile !== '' && is_file($pdfFile) && is_readable($pdfFile)) {
        $raw = @file_get_contents($pdfFile);
        if ($raw !== false) {
            $doc = tbpdf_doc($pdfFile, $raw, tbpdf_options([]));
            $pageList = array_slice(
                tbpdf_parse_document($doc),
                $selection['from'] - 1,
                $selection['count']
            );
            foreach ($doc['diagnostics'] as $diagnostic) {
                $result['diagnostics'][] = $diagnostic;
            }
            if ($doc['encrypted']) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'font_extraction_encrypted',
                    'message' => 'The PDF is encrypted; embedded fonts were not extracted.',
                    'page' => null,
                ];
            } else {
                $candidates = tbpdf_collect_embedded_fonts($doc, $pageList);
                $usedFiles = [];
                $overwritten = false;
                foreach ($candidates as $candidate) {
                    $name = (string) $candidate['name'];
                    $pageNumber = (int) $candidate['page'];
                    if (!$candidate['embedded']) {
                        $result['fonts'][] = ['name' => $name, 'status' => 'not_embedded'];
                        $result['diagnostics'][] = [
                            'level' => 'info',
                            'code' => 'font_not_embedded',
                            'message' => 'The font ' . $name . ' has no embedded font program.',
                            'page' => $pageNumber,
                        ];
                        continue;
                    }
                    $kind = (string) $candidate['kind'];
                    if ($kind !== 'truetype' && $kind !== 'opentype') {
                        $result['fonts'][] = ['name' => $name, 'status' => 'unsupported', 'format' => $kind];
                        $result['diagnostics'][] = [
                            'level' => 'warning',
                            'code' => 'font_not_convertible',
                            'message' => 'The embedded font ' . $name . ' is ' . $kind . ' and cannot be converted to WOFF without a font converter.',
                            'page' => $pageNumber,
                        ];
                        continue;
                    }
                    $bytes = tbpdf_decode_stream($doc, $candidate['font_file']);
                    if ($bytes === null) {
                        $result['fonts'][] = ['name' => $name, 'status' => 'undecodable'];
                        $result['diagnostics'][] = [
                            'level' => 'warning',
                            'code' => 'font_file_undecodable',
                            'message' => 'The embedded font program for ' . $name . ' could not be decoded.',
                            'page' => $pageNumber,
                        ];
                        continue;
                    }
                    $woff = tbpdf_font_sfnt_to_woff($bytes);
                    if ($woff === null) {
                        $result['fonts'][] = ['name' => $name, 'status' => 'woff_failed'];
                        $result['diagnostics'][] = [
                            'level' => 'warning',
                            'code' => 'font_woff_failed',
                            'message' => 'The embedded font program for ' . $name . ' is not a supported single SFNT font.',
                            'page' => $pageNumber,
                        ];
                        continue;
                    }
                    $fileName = tbpdf_font_unique_file($name, $usedFiles);
                    $fontPath = $fontDir . DIRECTORY_SEPARATOR . $fileName;
                    if (is_file($fontPath)) {
                        $overwritten = true;
                    }
                    if (!tbpdf_write_bytes($fontPath, $woff)) {
                        $result['fonts'][] = ['name' => $name, 'status' => 'write_failed'];
                        $result['diagnostics'][] = [
                            'level' => 'error',
                            'code' => 'font_write_failed',
                            'message' => 'The WOFF file for ' . $name . ' could not be written: ' . $fontPath,
                            'page' => $pageNumber,
                        ];
                        continue;
                    }
                    $descriptors[] = ['name' => $name, 'file' => $fileName];
                    $result['fonts'][] = [
                        'name' => $name,
                        'file' => $fileName,
                        'status' => 'converted',
                        'bytes' => strlen($woff),
                    ];
                    $result['font_count']++;
                }
                if ($overwritten) {
                    $result['diagnostics'][] = [
                        'level' => 'info',
                        'code' => 'font_files_overwritten',
                        'message' => 'One or more existing WOFF files were overwritten.',
                        'page' => null,
                    ];
                }
            }
        } else {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'font_extraction_unreadable',
                'message' => 'The PDF could not be read; embedded fonts were not extracted.',
                'page' => null,
            ];
        }
    } else {
        $result['diagnostics'][] = [
            'level' => 'warning',
            'code' => 'font_extraction_unavailable',
            'message' => 'The PDF file is not available; embedded fonts were not extracted.',
            'page' => null,
        ];
    }

    $movie['fonts'] = array_values($descriptors);
    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }
    $json = json_encode($movie, $flags);
    if ($json === false) {
        return tbpdf_fonts_fail($result, 'json_encode_failed', 'movie.json could not be encoded: ' . json_last_error_msg());
    }
    if (!tbpdf_write_bytes($movieJsonPath, $json . PHP_EOL)) {
        return tbpdf_fonts_fail($result, 'movie_json_write_failed', 'movie.json could not be written.');
    }

    $result['converted'] = $descriptors;
    return $result;
}

/**
 * Convenience wrapper that returns the stage 7 result as JSON.
 */
function tbpdf_extract_font_files_to_json(
    string $analysisJson,
    string $movieId,
    ?string $baseDir = null,
    array $options = []
): string {
    return tbpdf_json_encode(tbpdf_extract_font_files($analysisJson, $movieId, $baseDir, $options));
}

function tbpdf_fonts_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/**
 * Walks the page resources and returns one entry per unique font name.
 */
function tbpdf_collect_embedded_fonts(array &$doc, array $pages): array
{
    $fonts = [];
    $seen = [];
    foreach ($pages as $index => $pageEntry) {
        $pageNumber = $index + 1;
        $dict = $pageEntry['dict'];
        $inherited = $pageEntry['inherited'];
        $resources = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_page_attr($dict, $inherited, 'Resources')));
        if ($resources === null) {
            continue;
        }
        $fontMap = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($resources, 'Font')));
        if ($fontMap === null) {
            continue;
        }
        foreach ($fontMap['v'] as $resourceName => $reference) {
            $font = tbpdf_as_dict(tbpdf_resolve($doc, $reference));
            if ($font === null) {
                continue;
            }
            $subtype = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'Subtype')) ?? 'unknown';
            $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($font, 'BaseFont'));
            $descriptor = tbpdf_as_dict(tbpdf_resolve($doc, tbpdf_dict_get($font, 'FontDescriptor')));
            if ($subtype === 'Type0') {
                $descendants = tbpdf_array_values(tbpdf_resolve($doc, tbpdf_dict_get($font, 'DescendantFonts')));
                if ($descendants !== null && isset($descendants[0])) {
                    $cidFont = tbpdf_as_dict(tbpdf_resolve($doc, $descendants[0]));
                    if ($cidFont !== null) {
                        if ($baseFont === null) {
                            $baseFont = tbpdf_resolve_name($doc, tbpdf_dict_get($cidFont, 'BaseFont'));
                        }
                        if ($descriptor === null) {
                            $descriptor = tbpdf_as_dict(
                                tbpdf_resolve($doc, tbpdf_dict_get($cidFont, 'FontDescriptor'))
                            );
                        }
                    }
                }
            }
            $name = tbpdf_font_name_clean($baseFont) ?? (string) $resourceName;
            if (isset($seen[$name])) {
                continue;
            }
            $seen[$name] = true;

            $entry = [
                'name' => $name,
                'page' => $pageNumber,
                'resource' => (string) $resourceName,
                'subtype' => $subtype,
                'embedded' => false,
                'kind' => null,
                'font_file' => null,
            ];

            if ($descriptor !== null) {
                $fontFile = tbpdf_resolve($doc, tbpdf_dict_get($descriptor, 'FontFile'));
                $fontFile2 = tbpdf_resolve($doc, tbpdf_dict_get($descriptor, 'FontFile2'));
                $fontFile3 = tbpdf_resolve($doc, tbpdf_dict_get($descriptor, 'FontFile3'));
                if (is_array($fontFile2) && ($fontFile2['t'] ?? '') === 'stream') {
                    $entry['embedded'] = true;
                    $entry['kind'] = 'truetype';
                    $entry['font_file'] = $fontFile2;
                } elseif (is_array($fontFile3) && ($fontFile3['t'] ?? '') === 'stream') {
                    $file3Subtype = tbpdf_name_value(
                        tbpdf_dict_get(tbpdf_object_dict($fontFile3), 'Subtype')
                    );
                    $entry['embedded'] = true;
                    $entry['kind'] = in_array($file3Subtype, ['OpenType', 'TrueType'], true)
                        ? 'opentype'
                        : 'cff';
                    $entry['font_file'] = $fontFile3;
                } elseif (is_array($fontFile) && ($fontFile['t'] ?? '') === 'stream') {
                    $entry['embedded'] = true;
                    $entry['kind'] = 'type1';
                    $entry['font_file'] = $fontFile;
                }
            }

            $fonts[] = $entry;
        }
    }
    return $fonts;
}

/**
 * Builds a WOFF 1.0 file from a single SFNT (TrueType/OpenType) program.
 * Each table is compressed independently with zlib, as required by the spec.
 */
function tbpdf_font_sfnt_to_woff(string $sfnt): ?string
{
    $length = strlen($sfnt);
    if ($length < 12) {
        return null;
    }
    $flavor = substr($sfnt, 0, 4);
    if (!in_array($flavor, ["\x00\x01\x00\x00", 'OTTO', 'true', 'typ1'], true)) {
        return null;
    }
    $numTables = (int) (unpack('n', substr($sfnt, 4, 2))[1] ?? 0);
    if ($numTables < 1 || $numTables > 4096) {
        return null;
    }
    $directoryLength = 12 + 16 * $numTables;
    if ($length < $directoryLength) {
        return null;
    }

    $tables = [];
    $totalSfntSize = 12 + 16 * $numTables;
    for ($i = 0; $i < $numTables; $i++) {
        $entryOffset = 12 + $i * 16;
        $tag = substr($sfnt, $entryOffset, 4);
        $checksum = (int) (unpack('N', substr($sfnt, $entryOffset + 4, 4))[1] ?? 0);
        $tableOffset = (int) (unpack('N', substr($sfnt, $entryOffset + 8, 4))[1] ?? 0);
        $tableLength = (int) (unpack('N', substr($sfnt, $entryOffset + 12, 4))[1] ?? 0);
        if ($tableOffset < 0 || $tableLength < 0 || $tableOffset + $tableLength > $length) {
            return null;
        }
        $tableData = substr($sfnt, $tableOffset, $tableLength);
        if (strlen($tableData) !== $tableLength) {
            return null;
        }
        $paddedLength = ($tableLength + 3) & ~3;
        $tables[] = [
            'tag' => $tag,
            'checksum' => $checksum,
            'data' => $tableData,
            'length' => $tableLength,
        ];
        $totalSfntSize += $paddedLength;
    }

    usort($tables, static function (array $a, array $b): int {
        return strcmp($a['tag'], $b['tag']);
    });

    $dataOffset = 44 + 20 * $numTables;
    $directory = '';
    $body = '';
    $offset = $dataOffset;
    foreach ($tables as $table) {
        $compressed = @gzcompress($table['data'], 9);
        if ($compressed === false || strlen($compressed) >= $table['length']) {
            $stored = $table['data'];
        } else {
            $stored = $compressed;
        }
        $directory .= $table['tag']
            . pack('N', $offset)
            . pack('N', strlen($stored))
            . pack('N', $table['length'])
            . pack('N', $table['checksum']);
        $body .= $stored;
        $padding = (4 - (strlen($stored) % 4)) % 4;
        if ($padding > 0) {
            $body .= str_repeat("\0", $padding);
        }
        $offset += strlen($stored) + $padding;
    }

    $totalLength = $dataOffset + strlen($body);
    $header = 'wOFF'
        . $flavor
        . pack('N', $totalLength)
        . pack('n', $numTables)
        . pack('n', 0)
        . pack('N', $totalSfntSize)
        . pack('n', 1)
        . pack('n', 0)
        . pack('N', 0)
        . pack('N', 0)
        . pack('N', 0)
        . pack('N', 0)
        . pack('N', 0);

    return $header . $directory . $body;
}

function tbpdf_font_file_name(string $name): string
{
    $clean = preg_replace('/[^A-Za-z0-9._-]+/', '_', $name);
    $clean = trim((string) $clean, '._-');
    if ($clean === '') {
        $clean = 'Font';
    }
    if (strlen($clean) > 96) {
        $clean = substr($clean, 0, 96);
    }
    return $clean;
}

function tbpdf_font_unique_file(string $name, array &$used): string
{
    $base = tbpdf_font_file_name($name);
    $candidate = $base . '.woff';
    $index = 2;
    while (isset($used[strtolower($candidate)])) {
        $candidate = $base . '-' . $index . '.woff';
        $index++;
    }
    $used[strtolower($candidate)] = true;
    return $candidate;
}

/* -------------------------------------------------------------------------
 * Single-page import
 * ---------------------------------------------------------------------- */

/**
 * Recursively removes a directory and its contents.
 */
function tbpdf_remove_directory(string $path): void
{
    if ($path === '' || !is_dir($path)) {
        return;
    }
    $items = scandir($path);
    if ($items === false) {
        return;
    }
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $itemPath = $path . DIRECTORY_SEPARATOR . $item;
        if (is_dir($itemPath) && !is_link($itemPath)) {
            tbpdf_remove_directory($itemPath);
        } else {
            @unlink($itemPath);
        }
    }
    @rmdir($path);
}

/**
 * Imports one PDF page as a self-contained scene inside "temp.movie".
 *
 * Unlike stages 2 to 7, this function does not create a complete movie: it
 * only creates "temp.movie/media/picture", "temp.movie/media/font",
 * "temp.movie/scene" and "temp.movie/collection". The page identifier used
 * for the scene title, picture folder, collection/scene ids and keyframe keys
 * is "<page>_<YYYYMMDDHHMM>".
 */
function tbpdf_import_page_internal(
    string $analysisJson,
    int $pageNumber,
    ?string $baseDir = null,
    array $options = []
): array {
    $result = [
        'movie' => null,
        'page' => $pageNumber,
        'page_number' => null,
        'scene' => null,
        'collection' => null,
        'picture_dir' => null,
        'font_dir' => null,
        'scene_id' => null,
        'collection_id' => null,
        'images_extracted' => 0,
        'vectors_extracted' => 0,
        'paragraph_count' => 0,
        'keyframe_count' => 0,
        'font_count' => 0,
        'fonts' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_import_page_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }
    if ($pageNumber < 1) {
        return tbpdf_import_page_fail($result, 'invalid_page', 'The page number must be at least 1.');
    }

    $file = $data['file'] ?? null;
    if (!is_string($file) || $file === '' || !is_file($file) || !is_readable($file)) {
        return tbpdf_import_page_fail($result, 'file_not_readable', 'The PDF path in the analysis JSON is not a readable file.');
    }
    if ($baseDir === null) {
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_import_page_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }

    $raw = @file_get_contents($file);
    if ($raw === false) {
        return tbpdf_import_page_fail($result, 'file_read_failed', 'The PDF file could not be loaded into memory.');
    }
    $doc = tbpdf_doc($file, $raw, tbpdf_options([]));
    $pages = tbpdf_parse_document($doc);
    foreach ($doc['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    if ($doc['encrypted']) {
        return tbpdf_import_page_fail($result, 'encrypted_pdf', 'Encrypted PDF streams cannot be imported by the single-page importer.');
    }
    if (count($pages) === 0) {
        return tbpdf_import_page_fail($result, 'no_pages', 'The PDF contains no pages.');
    }
    if ($pageNumber > count($pages)) {
        return tbpdf_import_page_fail($result, 'invalid_page', 'The page ' . $pageNumber . ' does not exist in the PDF.');
    }
    $pageEntry = $pages[$pageNumber - 1];

    $stamp = isset($options['datetime']) && is_string($options['datetime'])
        ? preg_replace('/[^0-9]/', '', $options['datetime'])
        : date('YmdHi');
    if (!is_string($stamp) || $stamp === '') {
        $stamp = date('YmdHi');
    }
    $pageId = $pageNumber . '_' . $stamp;
    $result['page_number'] = $pageId;

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . 'temp.movie';
    $pictureDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'picture';
    $pageDir = $pictureDir . DIRECTORY_SEPARATOR . $pageId;
    $fontDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'font';
    $sceneDir = $moviePath . DIRECTORY_SEPARATOR . 'scene';
    $collectionDir = $moviePath . DIRECTORY_SEPARATOR . 'collection';
    foreach ([$moviePath, dirname($pictureDir), $pictureDir, $pageDir, $fontDir, $sceneDir, $collectionDir] as $directory) {
        if (!is_dir($directory) && !mkdir($directory, 0777, true) && !is_dir($directory)) {
            return tbpdf_import_page_fail($result, 'folder_create_failed', 'The folder could not be created: ' . $directory);
        }
    }
    $result['movie'] = $moviePath;
    $result['picture_dir'] = $pageDir;
    $result['font_dir'] = $fontDir;

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }

    // Raster and vector media for the selected page.
    $collected = tbpdf_collect_page_images($doc, $pageEntry, $pageNumber);
    foreach ($collected['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    foreach ($collected['images'] as $imageIndex => $image) {
        $targetBase = $pageDir . DIRECTORY_SEPARATOR .
            'image-' . str_pad((string) ($imageIndex + 1), 2, '0', STR_PAD_LEFT);
        $extracted = tbpdf_extract_image($doc, $image, $targetBase);
        if (!empty($extracted['ok'])) {
            $result['images_extracted']++;
        } else {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => (string) ($extracted['code'] ?? 'image_skipped'),
                'message' => (string) ($extracted['message'] ?? 'An image could not be extracted.'),
                'page' => $pageNumber,
            ];
        }
    }

    $vectorOptions = array_merge([
        'vector' => true,
        'vector_dpi' => 96,
        'vector_max_pixels' => 4000000,
        'vector_max_objects' => 250,
        'vector_aa' => 2,
    ], $options);
    if (!empty($vectorOptions['vector'])) {
        $vectorResult = tbpdf_extract_page_vectors($doc, $pageEntry, $pageNumber, $pageDir, $vectorOptions);
        foreach ($vectorResult['diagnostics'] as $diagnostic) {
            $result['diagnostics'][] = $diagnostic;
        }
        foreach ($vectorResult['vectors'] as $vector) {
            if (!empty($vector['ok'])) {
                $result['vectors_extracted']++;
            }
        }
    }

    // Collection assets: pictures already written to the page folder plus the
    // text paragraphs extracted from the page content.
    $pictureExtensions = ['png', 'jpg', 'jpeg', 'gif'];
    $files = [];
    foreach (scandir($pageDir) ?: [] as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $path = $pageDir . DIRECTORY_SEPARATOR . $entry;
        if (!is_file($path)) {
            continue;
        }
        if (in_array(strtolower((string) pathinfo($entry, PATHINFO_EXTENSION)), $pictureExtensions, true)) {
            $files[] = $entry;
        }
    }
    sort($files, SORT_NATURAL | SORT_FLAG_CASE);

    $assets = [];
    $order = 0;
    foreach ($files as $filename) {
        $assetKey = substr(md5($filename), 0, 12);
        $assetPath = $pageId . '/' . $filename;
        $assets[$assetKey] = [
            'order' => $order,
            'name' => $filename,
            'type' => 'picture',
            'time' => 5,
            'action' => '',
            'frames' => 1,
            'frtime' => 100,
            'file' => [
                '@1' => $assetPath,
                '@2' => $assetPath,
                '@3' => $assetPath,
                '@4' => $assetPath,
                '@5' => $assetPath,
            ],
        ];
        $order++;
    }

    $textResult = tbpdf_extract_page_texts($doc, $pageEntry, $pageNumber);
    foreach ($textResult['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    $paragraphs = 0;
    $paragraphCounter = 1;
    foreach ($textResult['texts'] as $textValue) {
        $textValue = trim((string) $textValue);
        if ($textValue === '') {
            continue;
        }
        $baseKey = substr(md5($textValue), 0, 12);
        $assetKey = $baseKey;
        $suffix = 2;
        while (isset($assets[$assetKey])) {
            $assetKey = $baseKey . '-' . $suffix;
            $suffix++;
        }
        $assets[$assetKey] = [
            'order' => $order,
            'name' => 'Paragraph' . $paragraphCounter,
            'type' => 'paragraph',
            'time' => 5,
            'action' => '',
            'frames' => 1,
            'frtime' => 100,
            'file' => [
                '@1' => $textValue,
                '@2' => $textValue,
                '@3' => $textValue,
                '@4' => $textValue,
                '@5' => $textValue,
            ],
        ];
        $order++;
        $paragraphCounter++;
        $paragraphs++;
    }
    $result['paragraph_count'] = $paragraphs;

    $collectionTemplatePath = $options['collection_template'] ?? (__DIR__ . DIRECTORY_SEPARATOR . 'collection-base.json');
    if (!is_string($collectionTemplatePath) || !is_file($collectionTemplatePath) || !is_readable($collectionTemplatePath)) {
        return tbpdf_import_page_fail($result, 'template_missing', 'The collection-base.json template was not found or is not readable.');
    }
    $collectionTemplateText = str_replace('[ASSETS]', '', (string) @file_get_contents($collectionTemplatePath));
    $collectionTemplate = json_decode($collectionTemplateText, true);
    if (!is_array($collectionTemplate)) {
        return tbpdf_import_page_fail($result, 'template_invalid', 'The collection-base.json template is not valid JSON: ' . json_last_error_msg());
    }

    $collectionId = md5($pageId);
    $collection = tbpdf_replace_markers($collectionTemplate, [
        '[COLID]' => $collectionId,
        '[ID]' => 'temp',
        '[COLNAME]' => $pageId,
    ]);
    $collection['id'] = $collectionId;
    $collection['movie'] = 'temp';
    $collection['name'] = $pageId;
    $collection['assets'] = count($assets) > 0 ? $assets : new stdClass();
    $collectionJson = json_encode($collection, $flags);
    if ($collectionJson === false) {
        return tbpdf_import_page_fail($result, 'json_encode_failed', 'The collection descriptor could not be encoded: ' . json_last_error_msg());
    }
    $collectionFile = $collectionDir . DIRECTORY_SEPARATOR . $collectionId . '.json';
    if (!tbpdf_write_bytes($collectionFile, $collectionJson . PHP_EOL)) {
        return tbpdf_import_page_fail($result, 'collection_write_failed', 'The collection descriptor could not be written: ' . $collectionFile);
    }
    $result['collection'] = $collectionFile;
    $result['collection_id'] = $collectionId;

    // Scene layout: images, texts and vectors in content-stream order.
    $mediaBox = tbpdf_box($doc, tbpdf_page_attr($pageEntry['dict'], $pageEntry['inherited'], 'MediaBox'));
    $cropBox = tbpdf_box($doc, tbpdf_page_attr($pageEntry['dict'], $pageEntry['inherited'], 'CropBox')) ?? $mediaBox;
    $pageBox = $cropBox ?? [
        'llx' => 0.0,
        'lly' => 0.0,
        'urx' => 612.0,
        'ury' => 792.0,
        'width' => 612.0,
        'height' => 792.0,
    ];

    $elements = [];
    $seq = 0;
    $imageLayout = tbpdf_layout_page_images($doc, $pageEntry, $pageNumber);
    foreach ($imageLayout['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    foreach ($imageLayout['images'] as $image) {
        $elements[] = [
            'kind' => 'image',
            'name' => $image['filename'],
            'bbox' => $image['bbox'],
            'content_pos' => $image['content_pos'] ?? 0,
            'seq' => $seq++,
        ];
    }

    $textLayout = tbpdf_layout_page_texts($doc, $pageEntry, $pageNumber);
    foreach ($textLayout['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    $paragraphIndex = 1;
    foreach ($textLayout['texts'] as $text) {
        $elements[] = [
            'kind' => 'text',
            'name' => 'Paragraph' . $paragraphIndex,
            'text' => $text['text'],
            'x' => (float) $text['x'],
            'y' => (float) $text['y'],
            'size' => (float) $text['size'],
            'width' => isset($text['width'])
                ? (float) $text['width']
                : tbpdf_layout_text_estimated_width((string) $text['text'], (float) $text['size']),
            'font' => (string) ($text['font'] ?? 'sans'),
            'color' => (string) ($text['color'] ?? '0x000000'),
            'bold' => (bool) ($text['bold'] ?? false),
            'italic' => (bool) ($text['italic'] ?? false),
            'content_pos' => $text['content_pos'] ?? 0,
            'seq' => $seq++,
        ];
        $paragraphIndex++;
    }

    $vectorLayout = tbpdf_extract_page_vectors(
        $doc,
        $pageEntry,
        $pageNumber,
        $pageDir,
        [
            'vector_dry_run' => true,
            'vector_dpi' => 96,
            'vector_max_pixels' => 4000000,
            'vector_max_objects' => 250,
            'vector_aa' => 2,
        ]
    );
    foreach ($vectorLayout['diagnostics'] as $diagnostic) {
        $result['diagnostics'][] = $diagnostic;
    }
    foreach ($vectorLayout['vectors'] as $vector) {
        if (empty($vector['ok'])) {
            continue;
        }
        $elements[] = [
            'kind' => 'vector',
            'name' => basename((string) $vector['file']),
            'bbox' => $vector['bbox'],
            'alpha' => isset($vector['alpha']) ? (float) $vector['alpha'] : 1.0,
            'center' => $vector['center'] ?? null,
            'local_width' => isset($vector['local_width']) ? (float) $vector['local_width'] : null,
            'local_height' => isset($vector['local_height']) ? (float) $vector['local_height'] : null,
            'rotation' => isset($vector['rotation']) ? (float) $vector['rotation'] : 0.0,
            'content_pos' => $vector['content_pos'] ?? 0,
            'seq' => $seq++,
        ];
    }

    usort($elements, static function (array $a, array $b): int {
        $posA = $a['content_pos'] ?? PHP_INT_MAX;
        $posB = $b['content_pos'] ?? PHP_INT_MAX;
        if ($posA === $posB) {
            return ($a['seq'] ?? 0) <=> ($b['seq'] ?? 0);
        }
        return $posA <=> $posB;
    });

    $byName = [];
    foreach ($assets as $assetKey => $asset) {
        if (is_array($asset) && isset($asset['name'])) {
            $byName[(string) $asset['name']] = (string) $assetKey;
        }
    }

    $sceneId = md5($pageId);
    $factor = 96 / 72;
    $keyframes = [];
    $kfOrder = 0;
    $usedAssets = [];
    foreach ($elements as $element) {
        $assetKey = $byName[$element['name']] ?? null;
        if ($assetKey === null) {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'layout_asset_missing',
                'message' => 'The layout element ' . $element['name'] . ' has no corresponding collection asset.',
                'page' => $pageNumber,
            ];
            continue;
        }
        if (isset($usedAssets[$assetKey])) {
            continue;
        }
        $usedAssets[$assetKey] = true;

        if ($element['kind'] === 'text') {
            $x = ($element['x'] - $pageBox['llx']) * $factor;
            $y = ($pageBox['ury'] - ($element['y'] + $element['size'])) * $factor;
            $width = max(1.0, $element['width'] * $factor * 1.5);
            $height = max(1.0, $element['size'] * $factor * 2.0);
            $font = $element['font'] !== '' ? $element['font'] : 'sans';
            $fontSize = $element['size'] * $factor;
            $color = $element['color'] !== '' ? $element['color'] : '0x000000';
            $bold = $element['bold'];
            $italic = $element['italic'];
            $alpha = 1.0;
            $rotation = 0.0;
        } else {
            $bbox = $element['bbox'];
            $bboxWidth = $bbox['width'] ?? (($bbox['urx'] ?? 0) - ($bbox['llx'] ?? 0));
            $bboxHeight = $bbox['height'] ?? (($bbox['ury'] ?? 0) - ($bbox['lly'] ?? 0));
            $rotation = 0.0;
            if (
                $element['kind'] === 'vector' &&
                isset($element['center']) && is_array($element['center']) &&
                isset($element['local_width'], $element['local_height'])
            ) {
                $angleDegrees = (float) ($element['rotation'] ?? 0.0);
                $angle = deg2rad($angleDegrees);
                $localWidth = (float) $element['local_width'];
                $localHeight = (float) $element['local_height'];
                $centerX = (float) $element['center'][0];
                $centerY = (float) $element['center'][1];
                $tx = ($centerX - $pageBox['llx']) -
                    ($localWidth / 2 * cos($angle) - $localHeight / 2 * sin($angle));
                $ty = ($pageBox['ury'] - $centerY) -
                    ($localWidth / 2 * sin($angle) + $localHeight / 2 * cos($angle));
                $x = $tx * $factor;
                $y = $ty * $factor;
                $width = max(1.0, $localWidth * $factor);
                $height = max(1.0, $localHeight * $factor);
                $rotation = fmod($angleDegrees, 360.0);
                if ($rotation < 0) {
                    $rotation += 360.0;
                }
            } else {
                $x = ($bbox['llx'] - $pageBox['llx']) * $factor;
                $y = ($pageBox['ury'] - $bbox['ury']) * $factor;
                $width = max(1.0, $bboxWidth * $factor);
                $height = max(1.0, $bboxHeight * $factor);
            }
            $font = 'sans';
            $fontSize = 20.0;
            $color = '0x000000';
            $bold = false;
            $italic = false;
            $alpha = isset($element['alpha']) ? (float) $element['alpha'] : 1.0;
        }

        $key = $pageId . '_' . $assetKey;
        $keyframes[$key] = tbpdf_scene_instance(
            $sceneId,
            $assetKey,
            $kfOrder,
            $x,
            $y,
            $width,
            $height,
            $font,
            $fontSize,
            $color,
            $bold,
            $italic,
            $alpha,
            $rotation
        );
        $kfOrder++;
    }

    foreach ($assets as $assetKey => $asset) {
        if (isset($usedAssets[$assetKey])) {
            continue;
        }
        $key = $pageId . '_' . $assetKey;
        $keyframes[$key] = tbpdf_scene_instance(
            $sceneId,
            $assetKey,
            $kfOrder,
            0,
            0,
            0,
            0,
            'sans',
            20,
            '0x000000',
            false,
            false,
            1.0,
            0.0
        );
        $kfOrder++;
        $result['diagnostics'][] = [
            'level' => 'warning',
            'code' => 'asset_without_layout',
            'message' => 'The collection asset ' . ($asset['name'] ?? $assetKey) . ' had no layout metadata and was placed at 0,0.',
            'page' => $pageNumber,
        ];
    }

    $sceneTemplatePath = $options['scene_template'] ?? (__DIR__ . DIRECTORY_SEPARATOR . 'scene-base.json');
    if (!is_string($sceneTemplatePath) || !is_file($sceneTemplatePath) || !is_readable($sceneTemplatePath)) {
        return tbpdf_import_page_fail($result, 'template_missing', 'The scene-base.json template was not found or is not readable.');
    }
    $sceneTemplateText = str_replace('[KEYFRAMES]', '', (string) @file_get_contents($sceneTemplatePath));
    $sceneTemplate = json_decode($sceneTemplateText, true);
    if (!is_array($sceneTemplate)) {
        return tbpdf_import_page_fail($result, 'template_invalid', 'The scene-base.json template is not valid JSON: ' . json_last_error_msg());
    }

    $scene = tbpdf_replace_markers($sceneTemplate, [
        '[SCENEID]' => $sceneId,
        '[SCENENAME]' => $pageId,
        '[ID]' => 'temp',
        '[UP]' => '',
        '[DOWN]' => '',
        '[LEFT]' => '',
        '[RIGHT]' => '',
    ]);
    $scene['title'] = $pageId;
    $scene['id'] = $sceneId;
    $scene['movie'] = 'temp';
    $scene['navigation'] = [
        'up' => '',
        'down' => '',
        'left' => '',
        'right' => '',
        'nin' => '',
        'nout' => '',
    ];
    $scene['collections'] = [$sceneId];
    $scene['keyframes'] = [count($keyframes) > 0 ? $keyframes : new stdClass()];
    $sceneJson = json_encode($scene, $flags);
    if ($sceneJson === false) {
        return tbpdf_import_page_fail($result, 'json_encode_failed', 'The scene descriptor could not be encoded: ' . json_last_error_msg());
    }
    $sceneFile = $sceneDir . DIRECTORY_SEPARATOR . $sceneId . '.json';
    if (!tbpdf_write_bytes($sceneFile, $sceneJson . PHP_EOL)) {
        return tbpdf_import_page_fail($result, 'scene_write_failed', 'The scene descriptor could not be written: ' . $sceneFile);
    }
    $result['scene'] = $sceneFile;
    $result['scene_id'] = $sceneId;
    $result['keyframe_count'] = count($keyframes);

    // Embedded fonts used by the selected page.
    $candidates = tbpdf_collect_embedded_fonts($doc, [$pageEntry]);
    $usedFontFiles = [];
    foreach ($candidates as $candidate) {
        $name = (string) $candidate['name'];
        if (!$candidate['embedded']) {
            $result['diagnostics'][] = [
                'level' => 'info',
                'code' => 'font_not_embedded',
                'message' => 'The font ' . $name . ' has no embedded font program.',
                'page' => $pageNumber,
            ];
            continue;
        }
        $kind = (string) $candidate['kind'];
        if ($kind !== 'truetype' && $kind !== 'opentype') {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'font_not_convertible',
                'message' => 'The embedded font ' . $name . ' is ' . $kind . ' and cannot be converted to WOFF without a font converter.',
                'page' => $pageNumber,
            ];
            continue;
        }
        $bytes = tbpdf_decode_stream($doc, $candidate['font_file']);
        if ($bytes === null) {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'font_file_undecodable',
                'message' => 'The embedded font program for ' . $name . ' could not be decoded.',
                'page' => $pageNumber,
            ];
            continue;
        }
        $woff = tbpdf_font_sfnt_to_woff($bytes);
        if ($woff === null) {
            $result['diagnostics'][] = [
                'level' => 'warning',
                'code' => 'font_woff_failed',
                'message' => 'The embedded font program for ' . $name . ' is not a supported single SFNT font.',
                'page' => $pageNumber,
            ];
            continue;
        }
        $fileName = tbpdf_font_unique_file($name, $usedFontFiles);
        if (!tbpdf_write_bytes($fontDir . DIRECTORY_SEPARATOR . $fileName, $woff)) {
            $result['diagnostics'][] = [
                'level' => 'error',
                'code' => 'font_write_failed',
                'message' => 'The WOFF file for ' . $name . ' could not be written.',
                'page' => $pageNumber,
            ];
            continue;
        }
        $result['fonts'][] = ['name' => $name, 'file' => $fileName];
        $result['font_count']++;
    }

    return $result;
}

/**
 * Imports one PDF page as a self-contained scene inside "temp.movie".
 *
 * If the import fails and this call created the "temp.movie" folder, the
 * partial folder is removed.
 */
function tbpdf_import_page(
    string $analysisJson,
    int $pageNumber,
    ?string $baseDir = null,
    array $options = []
): array {
    $data = json_decode($analysisJson, true);
    $resolvedBase = $baseDir;

    if (is_array($data)) {
        $file = $data['file'] ?? null;
        if ($resolvedBase === null && is_string($file) && $file !== '') {
            $resolvedBase = dirname($file);
        }
        if (is_string($resolvedBase)) {
            $resolvedBase = rtrim($resolvedBase, '/\\');
            if ($resolvedBase === '' || !is_dir($resolvedBase)) {
                $resolvedBase = null;
            }
        } else {
            $resolvedBase = null;
        }
    } else {
        $resolvedBase = null;
    }

    $moviePath = $resolvedBase !== null
        ? $resolvedBase . DIRECTORY_SEPARATOR . 'temp.movie'
        : null;
    $movieExisted = $moviePath !== null && is_dir($moviePath);

    $result = tbpdf_import_page_internal($analysisJson, $pageNumber, $baseDir, $options);

    if (isset($result['error']) && $moviePath !== null && !$movieExisted && is_dir($moviePath)) {
        tbpdf_remove_directory($moviePath);
    }

    return $result;
}

/**
 * Convenience wrapper that returns the single-page import result as JSON.
 */
function tbpdf_import_page_to_json(
    string $analysisJson,
    int $pageNumber,
    ?string $baseDir = null,
    array $options = []
): string {
    return tbpdf_json_encode(tbpdf_import_page($analysisJson, $pageNumber, $baseDir, $options));
}

function tbpdf_import_page_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/**
 * Imports one PDF page as a new scene in an existing movie.
 *
 * The page is first rendered by tbpdf_import_page() in a temporary folder.
 * Its picture files, collection, scene and fonts are then merged into
 * "[ID].movie". The movie font list is extended and "updated" is refreshed.
 *
 * @param string      $analysisJson stage 1 analysis JSON
 * @param string      $movieId      target movie ID
 * @param string      $title        scene title
 * @param int         $pageNumber   PDF page to import
 * @param string|null $baseDir      directory containing "[ID].movie"
 * @param array       $options      collection_template, scene_template,
 *                                  datetime (optional), vector options
 * @return array
 */
function tbpdf_import_scene_into_movie(
    string $analysisJson,
    string $movieId,
    string $title,
    int $pageNumber,
    ?string $baseDir = null,
    array $options = []
): array {
    $result = [
        'movie' => null,
        'movie_json' => null,
        'page' => $pageNumber,
        'page_number' => null,
        'scene' => null,
        'collection' => null,
        'picture_dir' => null,
        'font_dir' => null,
        'scene_id' => null,
        'collection_id' => null,
        'keyframe_count' => 0,
        'font_count' => 0,
        'fonts' => [],
        'diagnostics' => [],
    ];

    $data = json_decode($analysisJson, true);
    if (!is_array($data)) {
        return tbpdf_import_scene_fail($result, 'invalid_json', 'The analysis JSON could not be decoded: ' . json_last_error_msg());
    }
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/', $movieId)) {
        return tbpdf_import_scene_fail($result, 'invalid_movie_id', 'The movie ID may contain only letters, digits, underscores and hyphens.');
    }
    if ($pageNumber < 1) {
        return tbpdf_import_scene_fail($result, 'invalid_page', 'The page number must be at least 1.');
    }

    $file = $data['file'] ?? null;
    if (!is_string($file) || $file === '' || !is_file($file) || !is_readable($file)) {
        return tbpdf_import_scene_fail($result, 'file_not_readable', 'The PDF path in the analysis JSON is not a readable file.');
    }
    if ($baseDir === null) {
        $baseDir = dirname($file);
    }
    $baseDir = rtrim($baseDir, '/\\');
    if ($baseDir === '' || !is_dir($baseDir)) {
        return tbpdf_import_scene_fail($result, 'base_dir_missing', 'The output base directory does not exist.');
    }
    if (!is_writable($baseDir)) {
        return tbpdf_import_scene_fail($result, 'base_dir_not_writable', 'The output base directory is not writable.');
    }

    $moviePath = $baseDir . DIRECTORY_SEPARATOR . $movieId . '.movie';
    if (!is_dir($moviePath)) {
        return tbpdf_import_scene_fail($result, 'movie_folder_missing', 'The target movie folder does not exist.');
    }
    $movieJsonPath = $moviePath . DIRECTORY_SEPARATOR . 'movie.json';
    if (!is_file($movieJsonPath) || !is_readable($movieJsonPath)) {
        return tbpdf_import_scene_fail($result, 'movie_json_missing', 'movie.json was not found in the target movie.');
    }
    $movie = json_decode((string) @file_get_contents($movieJsonPath), true);
    if (!is_array($movie)) {
        return tbpdf_import_scene_fail($result, 'movie_json_invalid', 'movie.json in the target movie is not valid JSON.');
    }
    $result['movie'] = $moviePath;
    $result['movie_json'] = $movieJsonPath;

    $title = trim($title);
    if ($title === '') {
        $title = (string) $pageNumber;
    }

    $collectionTemplate = $options['collection_template'] ?? (__DIR__ . DIRECTORY_SEPARATOR . 'collection-base.json');
    if (!is_string($collectionTemplate) || $collectionTemplate === '' || !is_file($collectionTemplate) || !is_readable($collectionTemplate)) {
        return tbpdf_import_scene_fail($result, 'template_missing', 'The collection-base.json template was not found or is not readable.');
    }
    $sceneTemplate = $options['scene_template'] ?? (__DIR__ . DIRECTORY_SEPARATOR . 'scene-base.json');
    if (!is_string($sceneTemplate) || $sceneTemplate === '' || !is_file($sceneTemplate) || !is_readable($sceneTemplate)) {
        return tbpdf_import_scene_fail($result, 'template_missing', 'The scene-base.json template was not found or is not readable.');
    }

    $pictureRoot = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'picture';
    $fontDir = $moviePath . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR . 'font';
    $sceneDir = $moviePath . DIRECTORY_SEPARATOR . 'scene';
    $collectionDir = $moviePath . DIRECTORY_SEPARATOR . 'collection';
    foreach ([dirname($pictureRoot), $pictureRoot, $fontDir, $sceneDir, $collectionDir] as $directory) {
        if (!is_dir($directory) && !mkdir($directory, 0777, true) && !is_dir($directory)) {
            return tbpdf_import_scene_fail($result, 'folder_create_failed', 'The folder could not be created: ' . $directory);
        }
    }
    foreach ([$pictureRoot, $fontDir, $sceneDir, $collectionDir] as $directory) {
        if (!is_writable($directory)) {
            return tbpdf_import_scene_fail($result, 'folder_not_writable', 'The folder is not writable: ' . $directory);
        }
    }

    $flags = JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) {
        $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    }

    // Pick a page identifier that does not collide with the target movie.
    $pageId = null;
    $stamp = '';
    for ($attempt = 0; $attempt < 20; $attempt++) {
        $stamp = date('YmdHis') . str_pad((string) random_int(0, 999999999), 9, '0', STR_PAD_LEFT);
        $candidate = $pageNumber . '_' . $stamp;
        $candidateId = md5($candidate);
        if (
            !is_dir($pictureRoot . DIRECTORY_SEPARATOR . $candidate) &&
            !is_file($sceneDir . DIRECTORY_SEPARATOR . $candidateId . '.json') &&
            !is_file($collectionDir . DIRECTORY_SEPARATOR . $candidateId . '.json')
        ) {
            $pageId = $candidate;
            break;
        }
        usleep(1000);
    }
    if ($pageId === null) {
        return tbpdf_import_scene_fail($result, 'scene_id_conflict', 'A unique scene identifier could not be generated.');
    }

    $stagingBase = $baseDir . DIRECTORY_SEPARATOR . '.tbpdf-scene-' . bin2hex(random_bytes(8));
    if (!mkdir($stagingBase, 0777, true) && !is_dir($stagingBase)) {
        return tbpdf_import_scene_fail($result, 'staging_create_failed', 'The temporary import folder could not be created.');
    }

    $removeDirectory = static function (string $path) use (&$removeDirectory): void {
        if ($path === '' || !is_dir($path)) {
            return;
        }
        $items = scandir($path);
        if ($items === false) {
            return;
        }
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            $itemPath = $path . DIRECTORY_SEPARATOR . $item;
            if (is_dir($itemPath) && !is_link($itemPath)) {
                $removeDirectory($itemPath);
            } else {
                @unlink($itemPath);
            }
        }
        @rmdir($path);
    };

    $createdFiles = [];
    $createdDirs = [];
    $committed = false;

    try {
        $importOptions = $options;
        $importOptions['datetime'] = $stamp;
        $importOptions['collection_template'] = $collectionTemplate;
        $importOptions['scene_template'] = $sceneTemplate;
        $imported = tbpdf_import_page($analysisJson, $pageNumber, $stagingBase, $importOptions);
        if (isset($imported['error'])) {
            return tbpdf_import_scene_fail(
                $result,
                (string) ($imported['error']['code'] ?? 'page_import_failed'),
                (string) ($imported['error']['message'] ?? 'The PDF page could not be imported.')
            );
        }

        $pageId = (string) ($imported['page_number'] ?? $pageId);
        $sceneId = (string) ($imported['scene_id'] ?? '');
        $collectionId = (string) ($imported['collection_id'] ?? '');
        if ($sceneId === '' || $collectionId === '') {
            return tbpdf_import_scene_fail($result, 'page_import_incomplete', 'The page import did not return scene and collection identifiers.');
        }
        if (!preg_match('/^[a-f0-9]{32}$/', $sceneId) || !preg_match('/^[a-f0-9]{32}$/', $collectionId)) {
            return tbpdf_import_scene_fail($result, 'invalid_scene_id', 'The page import returned invalid scene or collection identifiers.');
        }

        $stagedPicture = (string) ($imported['picture_dir'] ?? '');
        $stagedScene = (string) ($imported['scene'] ?? '');
        $stagedCollection = (string) ($imported['collection'] ?? '');
        $stagedFontDir = (string) ($imported['font_dir'] ?? '');
        if (!is_dir($stagedPicture) || !is_file($stagedScene) || !is_file($stagedCollection)) {
            return tbpdf_import_scene_fail($result, 'page_import_incomplete', 'The page import did not create all expected files.');
        }

        $targetPicture = $pictureRoot . DIRECTORY_SEPARATOR . $pageId;
        $targetCollection = $collectionDir . DIRECTORY_SEPARATOR . $collectionId . '.json';
        $targetScene = $sceneDir . DIRECTORY_SEPARATOR . $sceneId . '.json';
        if (is_dir($targetPicture) || is_file($targetCollection) || is_file($targetScene)) {
            return tbpdf_import_scene_fail($result, 'scene_id_conflict', 'The generated scene identifier already exists in the target movie.');
        }

        // Copy pictures to the target movie.
        if (!mkdir($targetPicture, 0777, true) && !is_dir($targetPicture)) {
            return tbpdf_import_scene_fail($result, 'picture_dir_create_failed', 'The scene picture folder could not be created: ' . $targetPicture);
        }
        $createdDirs[] = $targetPicture;

        foreach (scandir($stagedPicture) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $source = $stagedPicture . DIRECTORY_SEPARATOR . $entry;
            if (!is_file($source)) {
                continue;
            }
            $target = $targetPicture . DIRECTORY_SEPARATOR . $entry;
            if (!@copy($source, $target)) {
                return tbpdf_import_scene_fail($result, 'picture_copy_failed', 'The picture file could not be copied: ' . $entry);
            }
            $createdFiles[] = $target;
        }

        // Copy fonts and build descriptors.
        $descriptors = [];
        $usedFontFiles = [];
        foreach (scandir($fontDir) ?: [] as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $usedFontFiles[strtolower($entry)] = true;
        }
        foreach ((array) ($imported['fonts'] ?? []) as $font) {
            if (!is_array($font) || !isset($font['name'], $font['file'])) {
                continue;
            }
            $fileName = (string) $font['file'];
            $source = $stagedFontDir . DIRECTORY_SEPARATOR . $fileName;
            if (!is_file($source)) {
                $result['diagnostics'][] = [
                    'level' => 'warning',
                    'code' => 'font_file_missing',
                    'message' => 'The staged font file was not found: ' . $fileName,
                    'page' => $pageNumber,
                ];
                continue;
            }
            $baseName = pathinfo($fileName, PATHINFO_FILENAME);
            $extension = pathinfo($fileName, PATHINFO_EXTENSION);
            if ($extension === '') {
                $extension = 'woff';
            }
            $candidate = $fileName;
            $suffix = 2;
            while (isset($usedFontFiles[strtolower($candidate)])) {
                $candidate = $baseName . '-' . $suffix . '.' . $extension;
                $suffix++;
            }
            $usedFontFiles[strtolower($candidate)] = true;
            $target = $fontDir . DIRECTORY_SEPARATOR . $candidate;
            if (!@copy($source, $target)) {
                return tbpdf_import_scene_fail($result, 'font_copy_failed', 'The font file could not be copied: ' . $fileName);
            }
            $createdFiles[] = $target;
            $descriptors[] = ['name' => (string) $font['name'], 'file' => $candidate];
            $result['fonts'][] = ['name' => (string) $font['name'], 'file' => $candidate];
        }
        $result['font_count'] = count($descriptors);

        // Rewrite and copy the collection descriptor.
        $collectionData = json_decode((string) @file_get_contents($stagedCollection), true);
        if (!is_array($collectionData)) {
            return tbpdf_import_scene_fail($result, 'collection_invalid', 'The staged collection descriptor is not valid JSON.');
        }
        $collectionData['id'] = $collectionId;
        $collectionData['movie'] = $movieId;
        $collectionData['name'] = $title;
        $collectionJson = json_encode($collectionData, $flags);
        if ($collectionJson === false) {
            return tbpdf_import_scene_fail($result, 'json_encode_failed', 'The collection descriptor could not be encoded: ' . json_last_error_msg());
        }
        if (!tbpdf_write_bytes($targetCollection, $collectionJson . PHP_EOL)) {
            return tbpdf_import_scene_fail($result, 'collection_write_failed', 'The collection descriptor could not be written: ' . $targetCollection);
        }
        $createdFiles[] = $targetCollection;

        // Rewrite and copy the scene descriptor.
        $sceneData = json_decode((string) @file_get_contents($stagedScene), true);
        if (!is_array($sceneData)) {
            return tbpdf_import_scene_fail($result, 'scene_invalid', 'The staged scene descriptor is not valid JSON.');
        }
        $sceneData['id'] = $sceneId;
        $sceneData['movie'] = $movieId;
        $sceneData['title'] = $title;
        $sceneData['collections'] = [$collectionId];
        $sceneJson = json_encode($sceneData, $flags);
        if ($sceneJson === false) {
            return tbpdf_import_scene_fail($result, 'json_encode_failed', 'The scene descriptor could not be encoded: ' . json_last_error_msg());
        }
        if (!tbpdf_write_bytes($targetScene, $sceneJson . PHP_EOL)) {
            return tbpdf_import_scene_fail($result, 'scene_write_failed', 'The scene descriptor could not be written: ' . $targetScene);
        }
        $createdFiles[] = $targetScene;

        // Extend the movie font list and refresh the update timestamp.
        if (!isset($movie['fonts']) || !is_array($movie['fonts'])) {
            $movie['fonts'] = [];
        }
        foreach ($descriptors as $descriptor) {
            $movie['fonts'][] = $descriptor;
        }
        $movie['fonts'] = array_values($movie['fonts']);
        $movie['updated'] = date('Y-m-d H:i:s');
        $movieJson = json_encode($movie, $flags);
        if ($movieJson === false) {
            return tbpdf_import_scene_fail($result, 'json_encode_failed', 'movie.json could not be encoded: ' . json_last_error_msg());
        }
        if (!tbpdf_write_bytes($movieJsonPath, $movieJson . PHP_EOL)) {
            return tbpdf_import_scene_fail($result, 'movie_json_write_failed', 'movie.json could not be written: ' . $movieJsonPath);
        }

        $result['page_number'] = $pageId;
        $result['scene'] = $targetScene;
        $result['collection'] = $targetCollection;
        $result['picture_dir'] = $targetPicture;
        $result['font_dir'] = $fontDir;
        $result['scene_id'] = $sceneId;
        $result['collection_id'] = $collectionId;
        $result['keyframe_count'] = (int) ($imported['keyframe_count'] ?? 0);

        $committed = true;
        return $result;
    } finally {
        $removeDirectory($stagingBase);
        if (!$committed) {
            foreach ($createdFiles as $createdFile) {
                @unlink($createdFile);
            }
            foreach (array_reverse($createdDirs) as $createdDir) {
                $removeDirectory($createdDir);
            }
        }
    }
}

function tbpdf_import_scene_fail(array $result, string $code, string $message): array
{
    $result['error'] = ['code' => $code, 'message' => $message];
    $result['diagnostics'][] = [
        'level' => 'error',
        'code' => $code,
        'message' => $message,
        'page' => null,
    ];
    return $result;
}

/* -------------------------------------------------------------------------
 * Command line entry point
 * ---------------------------------------------------------------------- */

$tbpdf_self = realpath(__FILE__);
$tbpdf_argv = isset($argv[0]) && is_string($argv[0]) ? realpath($argv[0]) : false;
$tbpdf_is_direct_cli = PHP_SAPI === 'cli' && $tbpdf_self !== false && $tbpdf_argv !== false &&
    (DIRECTORY_SEPARATOR === '\\' ? strcasecmp($tbpdf_self, $tbpdf_argv) === 0 : $tbpdf_self === $tbpdf_argv);

if ($tbpdf_is_direct_cli) {
    $input = $argv[1] ?? null;
    if ($input === null) {
        fwrite(STDERR, "Usage: php tbpdf.php <file.pdf> [output.json]\n");
        exit(2);
    }

    $json = tbpdf_analyze_to_json($input);
    if (isset($argv[2]) && $argv[2] !== '') {
        $written = @file_put_contents($argv[2], $json . PHP_EOL);
        if ($written === false) {
            fwrite(STDERR, "Could not write the output file: " . $argv[2] . "\n");
            exit(1);
        }
    } else {
        echo $json, PHP_EOL;
    }

    $decoded = json_decode($json, true);
    exit(is_array($decoded) && isset($decoded['error']) ? 1 : 0);
}
