#!/bin/zsh
echo "Testing desktop app..."
npm run start